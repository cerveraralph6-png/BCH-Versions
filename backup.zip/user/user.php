<?php
include_once '../auth_check.php';

// Get the name from the session (we will update login_process.php to provide this)
$displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Employee';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="/Imag3s/baguio-logo-gov.png">
    <link rel="stylesheet" href="/CSS/user.css">
    <title>BCH | User Dashboard</title>
</head>
<body>

    <nav>
        <div class="nav-logo">
            <img src="/Imag3s/baguio-logo-gov.png" alt="logo">
            <h1>Baguio City Database</h1>
        </div>
        <div class="nav-actions">
            <button class="btn-nav">🔔</button>
            <!-- Link this to your logout.php script -->
            <button class="btn-nav logout" onclick="window.location.href='/logout.php'">Logout</button>
        </div>
    </nav>

    <main>
        <!-- Dynamic Greeting using PHP -->
        <div id="greetings"><h1>Welcome, <?php echo htmlspecialchars($displayName); ?>!</h1></div>
        
        <h2>Tools</h2>
        <div class="card-grid">
            <!-- UPDATED LINKS TO .php -->
            <a href="/tools/events.php" class="card-link">
                <div class="db-card">
                    <img src="/Imag3s/events.webp" alt="db">
                    <h1>Events</h1>
                </div>
            </a>
            <a href="/db-table/table.php" class="card-link">
                <div class="db-card">
                    <img src="/Imag3s/database.webp" alt="db">
                    <h1>Database</h1>
                </div>
            </a>
            <a href="/tools/files.php" class="card-link">
                <div class="db-card">
                    <img src="/Imag3s/Files.webp" alt="db">
                    <h1>File</h1>
                </div>
            </a>
        </div>
    </main>

<script src="/scripts/main.js"></script>
</body>
</html>