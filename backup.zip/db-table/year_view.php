<?php
session_start();
include_once '../auth_check.php';
include '../db.php';

$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Fetch the new Detailed Records
$stmt_records = $conn->prepare("SELECT * FROM city_records WHERE YEAR(Date_Received) = ? ORDER BY Date_Received DESC");
$stmt_records->bind_param("i", $selected_year);
$stmt_records->execute();
$records_result = $stmt_records->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>BCH | Detailed Records <?php echo $selected_year; ?></title>
    <style>
        /* Special style for very wide tables */
        .wide-table-container {
            width: 100%;
            overflow-x: auto; /* Enable horizontal scroll */
            border-radius: 12px;
            border: 1.5px solid #e2e8f0;
            background: #fff;
        }
        .wide-table-container table {
            min-width: 2500px; /* Force the table to be wide enough for all columns */
        }
        .wide-table-container th {
            position: sticky;
            top: 0;
            z-index: 10;
            white-space: nowrap;
        }
        .wide-table-container td {
            white-space: nowrap; /* Prevent text wrapping to keep table neat */
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <nav>
        <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
        <h1>Baguio City Database</h1>
        <div class="nav-actions">
            <button class="btn-nav btn-back-archive" onclick="window.location.href='table.php'">← Back to Archive</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main>
        <div id="container1">
            <div class="table-header">
                <h1>Archive Records: <?php echo $selected_year; ?></h1>
            </div>

            <h2 class="section-title">📄 Detailed Records (Scroll horizontally to view all)</h2>
            
            <div class="wide-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Date Received</th>
                            <th>Time Received</th>
                            <th>Type</th>
                            <th>Proponent</th>
                            <th>Subject</th>
                            <th>Description</th>
                            <th>Notation</th>
                            <th>Committee</th>
                            <th>Indorsement 1</th>
                            <th>Date Indorsed 1</th>
                            <th>Com Rep Nr</th>
                            <th>Com Rep</th>
                            <th>Com Rep Date Rec.</th>
                            <th>Com Rep Time Rec.</th>
                            <th>Item Nr</th>
                            <th>Agenda Date</th>
                            <th>Action Taken</th>
                            <th>Indorsement 2</th>
                            <th>Indorsement 2 Date</th>
                            <th>Remarks</th>
                            <th>Folder</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($records_result->num_rows > 0) {
                            while($row = $records_result->fetch_assoc()) {
                                echo "<tr>
                                    <td>".($row['Date_Received'] ? date('M d, Y', strtotime($row['Date_Received'])) : '-')."</td>
                                    <td>".($row['Time_Received'] ? date('h:i A', strtotime($row['Time_Received'])) : '-')."</td>
                                    <td>".htmlspecialchars($row['Type'])."</td>
                                    <td>".htmlspecialchars($row['Proponent'])."</td>
                                    <td style='font-weight:600;'>".htmlspecialchars($row['Subject'])."</td>
                                    <td>".htmlspecialchars($row['Subject_Description'])."</td>
                                    <td>".htmlspecialchars($row['Subject_Notation'])."</td>
                                    <td>".htmlspecialchars($row['Committee_Referred'])."</td>
                                    <td>".htmlspecialchars($row['Indorsement1'])."</td>
                                    <td>".($row['Date_Indorsed1'] ? date('M d, Y', strtotime($row['Date_Indorsed1'])) : '-')."</td>
                                    <td>".htmlspecialchars($row['Com_Rep_Nr'])."</td>
                                    <td>".htmlspecialchars($row['Com_Rep'])."</td>
                                    <td>".($row['Com_Rep_Date_Received'] ? date('M d, Y', strtotime($row['Com_Rep_Date_Received'])) : '-')."</td>
                                    <td>".($row['Com_Rep_Time_Received'] ? date('h:i A', strtotime($row['Com_Rep_Time_Received'])) : '-')."</td>
                                    <td>".htmlspecialchars($row['Item_Nr'])."</td>
                                    <td>".($row['Agenda_Date'] ? date('M d, Y', strtotime($row['Agenda_Date'])) : '-')."</td>
                                    <td>".htmlspecialchars($row['Action_Taken'])."</td>
                                    <td>".htmlspecialchars($row['Indorsement2'])."</td>
                                    <td>".($row['Indorsement2_Date'] ? date('M d, Y', strtotime($row['Indorsement2_Date'])) : '-')."</td>
                                    <td>".htmlspecialchars($row['Remarks'])."</td>
                                    <td style='font-weight:700; color:#3b82f6;'>".htmlspecialchars($row['Folder'])."</td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='21' style='text-align:center; padding:40px; color:#94a3b8;'>No detailed records found for this year.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script src="../scripts/main.js"></script>
</body>
</html>