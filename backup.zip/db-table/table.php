<?php
session_start();
if (!isset($_SESSION['role'])) {
    header("Location: /index.php");
    exit();
}
include '../db.php';

// Fetch all unique years from both events and files
$years_query = "
    SELECT DISTINCT YEAR(event_date) as year FROM events
    UNION
    SELECT DISTINCT YEAR(upload_date) as year FROM files
    ORDER BY year DESC";
$years_result = $conn->query($years_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>BCH | Database Archives</title>
</head>
<body>
    <nav>
        <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
        <h1>Baguio City Database</h1>
        <div class="nav-actions">
            <button id="Dashboard" onclick="window.location.href='/admin/admin.php'">Home</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main>
        <div id="container1">
            <div class="table-header">
                <h1>Archive Database</h1>
                
<!-- Inside the table-header div in table.php -->
<button id="add" style="background: #10b981;" onclick="document.getElementById('modal-import').showModal()">
    📥 Import CSV Data
</button>

<!-- Import Modal -->
<dialog id="modal-import">
    <form action="import_logic.php" method="POST" enctype="multipart/form-data">
        <h2>Import City Records</h2>
        <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 15px;">
            Please upload a <strong>.csv</strong> file. Ensure columns match the database structure.
        </p>
        
        <div class="file-upload-wrapper">
            <input type="file" name="csv_file" accept=".csv" required>
        </div>

        <div class="modal-actions">
            <button type="submit" class="btn-save">Start Import</button>
            <button type="button" class="btn-cancel" onclick="document.getElementById('modal-import').close()">Cancel</button>
        </div>
    </form>
</dialog>
            </div>

            <!-- Search & Sort Bar -->
            <div class="search-filter-section">
                <div class="search-field">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="year-search" placeholder="Search for a specific year...">
                </div>
                <div class="filter-field">
                    <select id="year-sort">
                        <option value="desc">Latest Year</option>
                        <option value="asc">Oldest Year</option>
                    </select>
                </div>
            </div>

            <!-- Grid of Year Cards -->
            <div class="year-grid" id="year-grid">
                <?php
                if ($years_result->num_rows > 0) {
                    while($row = $years_result->fetch_assoc()) {
                        $year = $row['year'];
                        echo "
                        <a href='year_view.php?year=$year' class='year-card-link' data-year='$year'>
                            <div class='year-card'>
                                <div class='year-icon'>📅</div>
                                <h2>$year</h2>
                                <p>View events and files from $year</p>
                                <span class='view-btn'>Open Records →</span>
                            </div>
                        </a>";
                    }
                } else {
                    echo "<p style='text-align:center; grid-column: 1/-1; padding: 40px; color: #64748b;'>No records found in the database.</p>";
                }
                ?>
            </div>
        </div>
    </main>

    <script src="../scripts/main.js"></script>
</body>
</html>