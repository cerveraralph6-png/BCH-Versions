<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["csv_file"])) {
    $filename = $_FILES["csv_file"]["tmp_name"];

    if ($_FILES["csv_file"]["size"] > 0) {
        $file = fopen($filename, "r");
        
        // Skip the first line (the headers in your Excel file)
        fgetcsv($file);

        // Prepare the SQL statement for 21 columns
        $stmt = $conn->prepare("INSERT INTO city_records (
            Date_Received, Time_Received, Type, Proponent, Subject, 
            Subject_Description, Subject_Notation, Committee_Referred, 
            Indorsement1, Date_Indorsed1, Com_Rep_Nr, Com_Rep, 
            Com_Rep_Date_Received, Com_Rep_Time_Received, Item_Nr, 
            Agenda_Date, Action_Taken, Indorsement2, Indorsement2_Date, 
            Remarks, Folder
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        $count = 0;
        while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
            // Ensure we have enough columns in the CSV row
            if (count($column) >= 21) {
                // Bind all 21 parameters
                $stmt->bind_param("sssssssssssssssssssss", 
                    $column[0], $column[1], $column[2], $column[3], $column[4],
                    $column[5], $column[6], $column[7], $column[8], $column[9],
                    $column[10], $column[11], $column[12], $column[13], $column[14],
                    $column[15], $column[16], $column[17], $column[18], $column[19],
                    $column[20]
                );
                $stmt->execute();
                $count++;
            }
        }
        
        fclose($file);
        header("Location: table.php?success=imported&count=$count");
        exit();
    }
}
?>