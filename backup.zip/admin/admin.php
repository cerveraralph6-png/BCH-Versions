<?php 
include_once '../auth_check.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BCH | Admin Dashboard</title>
    <link rel="stylesheet" href="../CSS/admin.css">
</head>
<body>
    <nav>
        <div class="nav-logo">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
            <h1>Baguio City Database</h1>
        </div>
        <div class="nav-actions">
            <button class="btn-nav">🔔</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main>
        <div id="greetings"><h1>Hi, Admin!</h1></div>

        <h2>Tools</h2>
        <div class="card-grid">
            <a href="/tools/events.php" class="card-link">
                <div class="db-card">
                    <img src="../Imag3s/events.webp" alt="db">
                    <h1>Events</h1>
                </div>
            </a>
            <a href="/db-table/table.php" class="card-link">
                <div class="db-card">
                    <img src="../Imag3s/database.webp" alt="db">
                    <h1>Database</h1>
                </div>
            </a>
            <a href="/tools/files.php" class="card-link">
                <div class="db-card">
                    <img src="../Imag3s/Files.webp" alt="db">
                    <h1>File</h1>
                </div>
            </a>
            <a href="/tools/manage-accounts.php" class="card-link">
                <div class="db-card">
                    <img src="../Imag3s/accounts.webp" alt="db">
                    <h1>Accounts</h1>
                </div>
            </a>
            
            <!-- Add this inside your <div class="card-grid"> in admin.php -->
            <a href="/admin/security_logs.php" class="card-link">
                <div class="db-card">
                    <img src="https://media.istockphoto.com/id/1491171267/vector/security-guard-logo.jpg?s=612x612&w=0&k=20&c=DRr4HX5XlTNGVxr45XPEaU641gae-xpoqdLegKfXAis=" alt="db"> <!-- Ensure you have a security icon -->
                    <h1>Security Logs</h1>
                </div>
            </a>
        </div>
    </main>

    <script src="/scripts/main.js"></script>
</body>
</html>