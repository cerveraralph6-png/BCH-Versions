<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Unauthorized access.");
}

include '../db.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['event_name'];
    $date = $_POST['event_date'];
    $time = $_POST['event_time'];
    $location = $_POST['location'];
    $desc = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO events (event_name, event_date, event_time, location, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $date, $time, $location, $desc);

    if ($stmt->execute()) {
        header("Location: events.php?success=1");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>