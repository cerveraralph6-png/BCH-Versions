<?php
// Add error reporting to see what's wrong if it fails again
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../db.php';

// Check if ID is provided
if (!isset($_GET['id'])) {
    die("Error: No ID provided.");
}

$id = intval($_GET['id']); // Ensure ID is a number

// 1. Get current status
$query = $conn->query("SELECT status FROM events WHERE id = $id");

if (!$query) {
    die("Database Error: " . $conn->error); // This will tell us if 'status' column is missing
}

$row = $query->fetch_assoc();

if (!$row) {
    die("Error: Event not found.");
}

// 2. Flip the status
$newStatus = ($row['status'] == 'pending') ? 'done' : 'pending';

// 3. Update the database
$update = $conn->query("UPDATE events SET status = '$newStatus' WHERE id = $id");

if ($update) {
    // Redirect back to events page
    header("Location: events.php");
    exit();
} else {
    echo "Update failed: " . $conn->error;
}
?>