<?php
session_start();
// Security check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Unauthorized access.");
}

include '../db.php'; // Path to your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['event_id'];
    $name = $_POST['event_name'];
    $date = $_POST['event_date'];
    $time = $_POST['event_time'];
    $location = $_POST['location'];
    $description = $_POST['description'];

    // Prepared statement to securely update the database
    $stmt = $conn->prepare("UPDATE events SET event_name=?, event_date=?, event_time=?, location=?, description=? WHERE id=?");
    $stmt->bind_param("sssssi", $name, $date, $time, $location, $description, $id);

    if ($stmt->execute()) {
        // Redirect back to events.php with a success flag
        header("Location: events.php?success=updated");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>