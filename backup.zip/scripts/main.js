document.addEventListener('DOMContentLoaded', () => {
    console.log("System Initialized...");

    // --- 1. LOGIN FORM HANDLER (AJAX) ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const errorDiv = document.getElementById('error-msg');
            const formData = new FormData(this);

            fetch('login_process.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirect;
                } else {
                    errorDiv.innerText = data.message || "Invalid Passkey!";
                    setTimeout(() => { errorDiv.innerText = ""; }, 2000);
                }
            })
            .catch(err => {
                console.error("Fetch error:", err);
                if(errorDiv) errorDiv.innerText = "System error. Try again later.";
            });
        });
    }

    // --- 2. GLOBAL NAVIGATION & LOGOUT ---
    const dashboardBtn = document.getElementById("Dashboard");
    if (dashboardBtn) {
        dashboardBtn.addEventListener("click", () => {
            window.location.href = "/admin/admin.php";
        });
    }

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            alert('You have been logged out!');
            window.location.href = '/logout.php';
        });
    }

    // --- 3. EVENTS SEARCH & FILTER LOGIC ---
    const eventSearch = document.getElementById('event-search');
    const statusFilter = document.getElementById('status-filter');
    if (eventSearch && statusFilter) {
        const filterEvents = () => {
            const query = eventSearch.value.toLowerCase().trim();
            const filterValue = statusFilter.value;
            const rows = document.querySelectorAll('.event-row');

            rows.forEach(row => {
                const name = row.getAttribute('data-name') || "";
                const loc = row.getAttribute('data-location') || "";
                const status = row.getAttribute('data-status') || "";

                const matchesSearch = name.includes(query) || loc.includes(query);
                const matchesStatus = (filterValue === 'all' || status === filterValue);

                row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
            });
        };
        eventSearch.addEventListener('input', filterEvents);
        statusFilter.addEventListener('change', filterEvents);
    }

    // --- 4. ARCHIVE YEAR SEARCH & SORT ---
    const yearSearch = document.getElementById('year-search');
    const yearSort = document.getElementById('year-sort');
    const yearGrid = document.getElementById('year-grid');
    if (yearSearch && yearGrid) {
        yearSearch.addEventListener('input', function() {
            const query = this.value;
            document.querySelectorAll('.year-card-link').forEach(card => {
                const year = card.getAttribute('data-year');
                card.style.display = year.includes(query) ? "" : "none";
            });
        });

        if (yearSort) {
            yearSort.addEventListener('change', function() {
                const cards = Array.from(document.querySelectorAll('.year-card-link'));
                const isAsc = this.value === 'asc';
                cards.sort((a, b) => {
                    const yA = parseInt(a.getAttribute('data-year'));
                    const yB = parseInt(b.getAttribute('data-year'));
                    return isAsc ? yA - yB : yB - yA;
                });
                cards.forEach(card => yearGrid.appendChild(card));
            });
        }
    }

    // --- 5. FILE UPLOAD HELPER (Displays filename when chosen) ---
    const actualBtn = document.getElementById('actual-btn');
    const fileChosen = document.getElementById('file-chosen');
    if (actualBtn && fileChosen) {
        actualBtn.addEventListener('change', function() {
            fileChosen.textContent = this.files[0].name;
        });
    }
});

// --- 6. GLOBAL FUNCTIONS (Available to HTML 'onclick' attributes) ---

// For Accounts Management Page
function openEditModal(id, name, empId, pass, role) {
    const modal = document.getElementById('modal-edit');
    if (modal) {
        document.getElementById('edit-user-id').value = id;
        document.getElementById('edit-full-name').value = name;
        document.getElementById('edit-employee-id').value = empId;
        document.getElementById('edit-passkey').value = pass;
        document.getElementById('edit-role').value = role;
        modal.showModal();
    }
}

// For Events Management Page
function openEditEventModal(id, name, date, time, location, desc) {
    const modal = document.getElementById('edit-event-modal');
    if (modal) {
        document.getElementById('edit-event-id').value = id;
        document.getElementById('edit-event-name').value = name;
        document.getElementById('edit-event-date').value = date;
        document.getElementById('edit-event-time').value = time;
        document.getElementById('edit-event-location').value = location;
        document.getElementById('edit-event-desc').value = desc;
        modal.showModal();
    }
}

// For Login Page Forgot Password
function forgotPassword() {
    const modal = document.getElementById('modal-forgot');
    if (modal) modal.showModal();
}

function closeForgotModal() {
    const modal = document.getElementById('modal-forgot');
    if (modal) {
        modal.close();
        document.getElementById('result-display').innerText = ''; 
        document.getElementById('verify-id').value = ''; 
    }
}

function verifyAndReveal() {
    const inputId = document.getElementById('verify-id').value;
    const display = document.getElementById('result-display');
    if(!inputId) return;

    let formData = new FormData();
    formData.append('employee_id', inputId);

    fetch('check_id.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        display.style.color = (data.includes("Passkey")) ? "#3b82f6" : "#ef4444";
        display.innerText = data;
        if (data.includes("Passkey")) {
            setTimeout(() => { closeForgotModal(); }, 5000);
        }
    })
    .catch(() => {
        if(display) display.innerText = "Error contacting server.";
    });
}

// --- AUTO LOGOUT INACTIVITY TIMER ---
// --- AUTO LOGOUT INACTIVITY TIMER ---
let inactivityTimer;

function resetInactivityTimer() {
    // Don't run the timer if we are already on the login page
    if (window.location.pathname.includes('index.php') || window.location.pathname === '/') {
        return;
    }

    clearTimeout(inactivityTimer);
    
    // 5 minutes
    inactivityTimer = setTimeout(() => {
        // Clear locally to prevent multiple alerts
        clearTimeout(inactivityTimer);
        alert("Session expired due to inactivity.");
        window.location.href = '/logout.php';
    }, 300000); 
}

// Only attach listeners if the user is logged in (Dashboard/Tools pages)
if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
    window.onmousemove = resetInactivityTimer;
    window.onmousedown = resetInactivityTimer;
    window.onclick = resetInactivityTimer;
    window.onscroll = resetInactivityTimer;
    window.onkeypress = resetInactivityTimer;
    resetInactivityTimer();
}