<?php
session_start();
include_once '../auth_check.php';
include '../db.php';

date_default_timezone_set('Asia/Manila');

// 1. SETTINGS & INPUTS
$limit = 50; 
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'Date_Received';
$order  = (isset($_GET['order']) && strtolower($_GET['order']) == 'asc') ? 'ASC' : 'DESC';

// NEW: Date Range Filter
$date_from = isset($_GET['df']) ? $_GET['df'] : '';
$date_to   = isset($_GET['dt']) ? $_GET['dt'] : '';

// 2. CONSTRUCT QUERY
$where_clauses = ["1=1"]; // Default true
$params = [];
$types = "";

if (!empty($date_from) && !empty($date_to)) {
    $where_clauses[] = "(Date_Received BETWEEN ? AND ?)";
    $params[] = $date_from; $params[] = $date_to;
    $types .= "ss";
}

if (!empty($search)) {
    $where_clauses[] = "(Subject LIKE ? OR Proponent LIKE ? OR Folder LIKE ? OR Type LIKE ? OR Remarks LIKE ? OR Subject_Description LIKE ?)";
    $st = "%$search%";
    for($i=0; $i<6; $i++) { $params[] = $st; $types .= "s"; }
}

$where_sql = "WHERE " . implode(" AND ", $where_clauses);

// 3. GET COUNTERS
$count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM city_records $where_sql");
if(!empty($types)) { $count_stmt->bind_param($types, ...$params); }
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

$gen_res = $conn->query("SELECT COUNT(*) as total FROM city_records");
$general_total = $gen_res->fetch_assoc()['total'];

// 4. FETCH DATA
$allowed_cols = ['Date_Received', 'Time_Received','Ref_No' ,'Type', 'Proponent', 'Subject', 'Folder', 'Item_Nr', 'Agenda_Date'];
if (!in_array($sort, $allowed_cols)) { $sort = 'Date_Received'; }

$data_sql = "SELECT * FROM city_records $where_sql ORDER BY $sort $order LIMIT ? OFFSET ?";
$stmt_records = $conn->prepare($data_sql);
$data_types = $types . "ii";
$data_params = array_merge($params, [$limit, $offset]);
$stmt_records->bind_param($data_types, ...$data_params);
$stmt_records->execute();
$records_result = $stmt_records->get_result();

/** HELPERS **/
function safeJson($data) {
    foreach ($data as $key => $value) { if (is_string($value)) { $data[$key] = mb_convert_encoding($value, 'UTF-8', 'UTF-8'); } }
    return htmlspecialchars(json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8');
}
function shortenText($text, $limit = 25) {
    $text = trim($text);
    if (empty($text) || $text === "-none-") return "<span style='color:#94a3b8; font-style:italic;'>-none-</span>";
    return (mb_strlen($text) > $limit) ? htmlspecialchars(mb_substr($text, 0, $limit)) . "..." : htmlspecialchars($text);
}
function cleanDisplay($v) { $v = trim($v); return (empty($v) || $v === "-none-") ? "<span style='color:#94a3b8; font-style:italic;'>-none-</span>" : htmlspecialchars($v); }
function formatTableDate($d) { if (empty($d) || $d == '0000-00-00') return "<span style='color:#94a3b8;'>-none-</span>"; return htmlspecialchars($d); }
function formatTableTime($t) { if (empty($t)) return "<span style='color:#94a3b8;'>-none-</span>"; return htmlspecialchars($t); }
function getSortURL($col, $currSort, $currOrder, $search, $df, $dt) {
    $newOrder = ($col == $currSort && $currOrder == 'DESC') ? 'asc' : 'desc';
    return "?sort=$col&order=$newOrder&search=" . urlencode($search) . "&df=$df&dt=$dt";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>BCH | Database Records</title>
    <style>
        .wide-table-container { width: 100%; overflow-x: auto; border: 1.5px solid #e2e8f0; border-radius: 12px; background: #fff; margin-bottom: 20px;}
        table { min-width: 4000px; border-collapse: separate; border-spacing: 0; table-layout: fixed;}
        th { position: sticky; top: 0; background: #f8fafc; z-index: 10; border-bottom: 2px solid #e2e8f0; white-space: nowrap; font-size: 0.75rem; text-transform: uppercase; color: #64748b; padding: 0; }
        th a { display: block; padding: 15px; text-decoration: none; color: inherit; width: 100%; height: 100%; transition: 0.2s; }
        td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; white-space: nowrap; font-size: 0.82rem; color: #334155; overflow: hidden; text-overflow: ellipsis;}
        .folder-tag { background: #eff6ff; color: #1e40af; padding: 4px 10px; border-radius: 6px; font-weight: 700; border: 1px solid #bfdbfe; font-size: 0.75rem; }
        .pagination { display: flex; justify-content: center; align-items: center; gap: 8px; margin: 30px 0; flex-wrap: wrap; }
        .page-link { padding: 8px 16px; border-radius: 8px; background: #fff; border: 1.5px solid #e2e8f0; color: #475569; text-decoration: none; font-weight: 600; white-space: nowrap; transition: 0.2s; }
        .page-link.active { background: #3b82f6; color: #fff; border-color: #3b82f6; }
        .stats-info { background: #f8fafc; padding: 10px 20px; border-radius: 8px; font-size: 0.85rem; color: #64748b; border: 1px solid #e2e8f0; }
    </style>
</head>
<body>
    <nav>
        <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
        <h1>City Database</h1>
        <div class="nav-actions">
            <button class="btn-nav back-btn" onclick="window.location.href='/admin/admin.php'">Home</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main>
        <div id="container1">
            <div class="table-header">
                <h1>Administrative Records</h1>
                <div class="action-group">
                    <a href="download_template.php" class="btn-action">📥 Template</a>
                    <button id="btn-export-selected" class="btn-action" style="color: #059669; border-color: #a7f3d0; opacity: 0.5; pointer-events: none;" onclick="exportSelectedRecords()">📄 Selected (<span id="selected-count">0</span>)</button>
                    <button id="add" style="background: #10b981;" onclick="document.getElementById('modal-add-manual').showModal()">+ Add Record</button>
                    <button id="add" style="background: #3b82f6;" onclick="document.getElementById('modal-import').showModal()">📂 Import CSV</button>
                </div>
            </div>

            <!-- Global Counters -->
            <div style="display:flex; gap:10px; margin-bottom:15px;">
                <div class="stats-info">General Database: <strong><?php echo number_format($general_total); ?></strong></div>
                <div class="stats-info" style="border-color:#3b82f6;">Matching Filter: <strong><?php echo number_format($total_rows); ?></strong></div>
            </div>

            <!-- SEARCH & DATE RANGE -->
            <form method="GET" class="search-filter-section" id="filterForm">
                <div class="search-field">
                    <span class="search-icon">🔍</span>
                    <input type="text" name="search" placeholder="Search..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-field" style="display: flex; gap: 8px; align-items:center;">
                    <label style="margin:0; font-size:0.7rem;">FROM:</label>
                    <input type="date" name="df" value="<?php echo $date_from; ?>" style="width:135px; margin:0; padding:8px;">
                    <label style="margin:0; font-size:0.7rem;">TO:</label>
                    <input type="date" name="dt" value="<?php echo $date_to; ?>" style="width:135px; margin:0; padding:8px;">
                    <button type="submit" class="btn-save" style="height:40px; padding:0 15px;">Filter</button>
                </div>
            </form>

            <div class="wide-table-container">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 50px; text-align: center;"><input type="checkbox" id="select-all-rows"></th>
                            <?php 
                            $hdrs = ["Date Received"=>"Date_Received", "Time Received"=>"Time_Received","Ref No" => "Ref_No" ,"Type"=>"Type", "Proponent"=>"Proponent", "Subject"=>"Subject", "Description"=>"Subject_Description", "Notation"=>"Subject_Notation", "Committee"=>"Committee_Referred", "Indorsement 1"=>"Indorsement1", "Date Ind 1"=>"Date_Indorsed1", "Com Rep Nr"=>"Com_Rep_Nr", "Com Rep"=>"Com_Rep", "Date Rec (Rep)"=>"Com_Rep_Date_Received", "Time Rec (Rep)"=>"Com_Rep_Time_Received", "Item Nr"=>"Item_Nr", "Agenda Date"=>"Agenda_Date", "Action Taken"=>"Action_Taken", "Indorsement 2"=>"Indorsement2", "Date Ind 2"=>"Indorsement2_Date", "Remarks"=>"Remarks", "Folder"=>"Folder"];
                            foreach($hdrs as $l => $c) {
                                $icon = ($sort == $c) ? ($order == 'ASC' ? '▲' : '▼') : '↕';
                                echo "<th><a href='".getSortURL($c, $sort, $order, $search, $date_from, $date_to)."'>$l <span class='sort-icon'>$icon</span></a></th>";
                            }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
    <?php if ($records_result->num_rows > 0): $idx = 0; ?>
        <?php while($row = $records_result->fetch_assoc()): $rowData = safeJson($row); ?>
        <tr class="event-row">
            <td style="text-align: center;"><input type="checkbox" class="record-checkbox" value="<?php echo $row['id']; ?>"></td>
            <td><?php echo formatTableDate($row['Date_Received']); ?></td>
            <td><?php echo formatTableTime($row['Time_Received']); ?></td>
            <td><?php echo cleanDisplay($row['Ref_No']); ?></td>
            <td><?php echo cleanDisplay($row['Type']); ?></td>
            <td><?php echo shortenText($row['Proponent'], 25); ?></td>
            <td style="font-weight:600;">
                <a href="javascript:void(0)" onclick="openDetailByIndex(<?php echo $idx; ?>)" style="color:#3b82f6; text-decoration:none;">
                    <?php echo shortenText($row['Subject'], 30); ?>
                </a>
                <div class="json-store" style="display:none;"><?php echo $rowData; ?></div>
            </td>
            <td><?php echo shortenText($row['Subject_Description'], 25); ?></td>
            <td><?php echo shortenText($row['Subject_Notation'], 20); ?></td>
            <td><?php echo cleanDisplay($row['Committee_Referred']); ?></td>
            <td><?php echo shortenText($row['Indorsement1'], 20); ?></td>
            <td><?php echo formatTableDate($row['Date_Indorsed1']); ?></td>
            <td><?php echo cleanDisplay($row['Com_Rep_Nr']); ?></td>
            <td><?php echo shortenText($row['Com_Rep'], 20); ?></td>
            <td><?php echo formatTableDate($row['Com_Rep_Date_Received']); ?></td>
            <td><?php echo cleanDisplay($row['Item_Nr']); ?></td>
            <td><?php echo formatTableDate($row['Agenda_Date']); ?></td>
            <td><?php echo shortenText($row['Action_Taken'], 20); ?></td>
            <td><?php echo shortenText($row['Indorsement2'], 20); ?></td>
            <td><?php echo formatTableDate($row['Indorsement2_Date']); ?></td>
            <td><?php echo shortenText($row['Remarks'], 20); ?></td>
            <td><span class="folder-tag"><?php echo cleanDisplay($row['Folder']); ?></span></td>
        </tr>
        <?php $idx++; endwhile; ?>
    <?php else: ?>
        <tr><td colspan="22" style="text-align:center; padding:60px;">No records found.</td></tr>
    <?php endif; ?>
</tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): $base = "?search=".urlencode($search)."&df=$date_from&dt=$date_to&sort=$sort&order=".strtolower($order); ?>
            <div class="pagination">
                <a href="<?php echo $base; ?>&p=1" class="page-link"><<</a>
                <?php for($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
                    <a href="<?php echo $base; ?>&p=<?php echo $i; ?>" class="page-link <?php if($i == $page) echo 'active'; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
                <a href="<?php echo $base; ?>&p=<?php echo $total_pages; ?>" class="page-link">>></a>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Modals (Detail, Verification, Manual Add, Import) -->
    <dialog id="modal-view-details" style="max-width: 900px; width: 95%; border: none; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.4); padding: 0; overflow: hidden;">
        <form action="edit_record_logic.php" method="POST" id="edit-detail-form">
            <div style="padding: 24px 30px; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; background: #f8fafc;">
                <div><small id="modal-mode-label" style="text-transform: uppercase; color: #3b82f6; font-weight: 700; font-size: 0.7rem;">Document Details</small><h2 id="view-subject-title" style="margin: 0; color: #0f172a; font-size: 1.4rem; font-weight: 800;">Subject Title</h2></div>
                <button type="button" onclick="closeDetailModal()" style="background: #f1f5f9; border: none; width: 36px; height: 36px; border-radius: 50%; cursor: pointer;">&times;</button>
            </div>
            <input type="hidden" name="record_id" id="view-record-id"><input type="hidden" name="verify_passkey" id="hidden-passkey">
            <div id="details-content" style="padding: 30px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; max-height: 60vh; overflow-y: auto;"></div>
            <div style="padding: 20px 30px; background: #f8fafc; border-top: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center;">
                <div><button type="button" class="btn-nav" onclick="navRecord(-1)">« Prev</button><button type="button" class="btn-nav" onclick="navRecord(1)">Next »</button></div>
                <div class="action-group">
                    <button type="button" id="btn-enable-edit" class="btn-action btn-edit-blue" onclick="enableEditMode()">📝 Edit</button>
                    <button type="button" id="btn-trigger-verify" class="btn-save" style="display: none;" onclick="openVerifyModal()">💾 Save</button>
                    <button type="button" class="btn-danger" onclick="closeDetailModal()">Close</button>
                </div>
            </div>
        </form>
    </dialog>

    <dialog id="modal-verify-passkey" style="border: none; border-radius: 16px; padding: 25px; width: 380px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); margin: auto;">
        <div style="text-align: center;"><h3>Security Verification</h3><input type="password" id="popup-passkey-input" placeholder="Passkey" style="text-align:center; border:2px solid #3b82f6; margin:20px 0; padding:12px; border-radius:10px; width:100%;"><div style="display:flex; gap:10px;"><button type="button" class="btn-save" onclick="submitEditWithPasskey()" style="flex:1;">Authorize</button><button type="button" class="btn-nav" onclick="document.getElementById('modal-verify-passkey').close()" style="flex:1; background:#94a3b8; color:#fff;">Cancel</button></div></div>
    </dialog>

    <dialog id="modal-add-manual" style="max-width: 900px; width: 95%;">
        <form action="add_record_logic.php" method="POST" style="padding: 30px;">
            <h2>Add New Record</h2>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; max-height: 60vh; overflow-y: auto;">
                <?php foreach($hdrs as $l => $c): ?>
                    <div style="<?php echo (in_array($c, ['Subject', 'Subject_Description', 'Indorsement1', 'Com_Rep', 'Action_Taken', 'Indorsement2', 'Remarks', 'Folder'])) ? 'grid-column: span 2;' : ''; ?>">
                        <label><?php echo $l; ?></label>
                        <?php if(strpos($c, 'Description') !== false || strpos($c, 'Remarks') !== false || strpos($c, 'Indorsement') !== false || $c == 'Com_Rep' || $c == 'Action_Taken'): ?>
                            <textarea name="<?php echo $c; ?>" rows="2"></textarea>
                        <?php else: ?>
                            <input type="<?php echo (strpos($c, 'Date') !== false) ? 'date' : ((strpos($c, 'Time') !== false) ? 'time' : 'text'); ?>" name="<?php echo $c; ?>" <?php echo ($c == 'Date_Received' || $c == 'Subject') ? 'required' : ''; ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="modal-actions" style="margin-top:25px;"><button type="submit" class="btn-save">Save Record</button><button type="button" class="btn-nav" onclick="document.getElementById('modal-add-manual').close()">Cancel</button></div>
        </form>
    </dialog>

    <dialog id="modal-import">
        <form action="import_logic.php" method="POST" enctype="multipart/form-data">
            <h2>Import CSV</h2><div class="file-upload-wrapper"><input type="file" name="csv_file" accept=".csv" required></div><div class="modal-actions"><button type="submit" class="btn-save">Import</button><button type="button" class="btn-nav" onclick="document.getElementById('modal-import').close()">Cancel</button></div>
        </form>
    </dialog>
    
    <!-- GLOBAL LOADING OVERLAY -->
<div id="upload-loader" style="display: none; position: fixed; inset: 0; background: rgba(255,255,255,0.8); z-index: 9999; flex-direction: column; align-items: center; justify-content: center; backdrop-filter: blur(4px);">
    <div class="spinner"></div>
    <p style="margin-top: 20px; font-weight: 600; color: #1e293b; font-size: 1.1rem;">Processing Data, please wait...</p>
    <p style="font-size: 0.85rem; color: #64748b;">This may take a minute for large files.</p>
</div>

    <script src="../scripts/main.js"></script>
</body>
</html>