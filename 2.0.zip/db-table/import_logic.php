<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["csv_file"])) {
    $file = fopen($_FILES["csv_file"]["tmp_name"], "r");
    fgetcsv($file); // Skip Header

    $sql = "INSERT INTO city_records (Date_Received, Time_Received, Ref_No, Type, Proponent, Subject, Subject_Description, Subject_Notation, Committee_Referred, Indorsement1, Date_Indorsed1, Com_Rep_Nr, Com_Rep, Com_Rep_Date_Received, Item_Nr, Agenda_Date, Action_Taken, Indorsement2, Indorsement2_Date, Remarks, Folder) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);

    // Indices for Date/Time columns (0, 1, 10, 13, 15, 18)
    $dtIdx = [0, 1, 10, 13, 15, 18];

    while (($row = fgetcsv($file, 10000, ",")) !== FALSE) {
        if (empty(array_filter($row))) continue; 
        $data = array_pad(array_slice($row, 0, 21), 21, "");
        $processed = [];

        foreach($data as $idx => $val) {
            $val = trim($val);
            if (empty($val) || $val === "-none-") {
                $processed[] = in_array($idx, $dtIdx) ? null : "-none-";
            } else {
                $processed[] = $val;
            }
        }
        $stmt->bind_param("sssssssssssssssssssss", ...$processed);
        $stmt->execute();
    }
    fclose($file);
    header("Location: table.php?success=1");
    exit();
}