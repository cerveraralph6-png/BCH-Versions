<?php
session_start();
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sender_id = $_SESSION['user_id'];
    $receiver_id = $_POST['receiver_id'];
    $file_id = $_POST['file_id'];

    $stmt = $conn->prepare("INSERT INTO file_transfers (file_id, sender_id, receiver_id) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $file_id, $sender_id, $receiver_id);

    if ($stmt->execute()) {
        header("Location: files.php?success=sent");
    } else {
        header("Location: files.php?error=failed");
    }
}

?>