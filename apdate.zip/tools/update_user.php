<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['user_id'];
    $name = $_POST['full_name'];
    $empId = $_POST['employee_id'];
    $pass = $_POST['passkey'];
    $role = $_POST['role'];

    $stmt = $conn->prepare("UPDATE users SET full_name=?, employee_id=?, passkey=?, role=? WHERE id=?");
    $stmt->bind_param("ssssi", $name, $empId, $pass, $role, $id);
    $stmt->execute();

    header("Location: manage-accounts.php?success=updated");
}
?>