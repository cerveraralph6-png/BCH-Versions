<?php
include '../db.php';
header('Content-Type: application/json');

$query = $_GET['query'] ?? '';
$filter = $_GET['filter'] ?? 'Subject';
$status = $_GET['status'] ?? 'All';
$prop_type = $_GET['prop_type'] ?? 'All'; // NEW

$allowedFilters = ['Subject', 'Ref_No', 'Proponent'];
if (!in_array($filter, $allowedFilters)) { $filter = 'Subject'; }

if (empty($query) && $status === 'All' && $prop_type === 'All') {
    echo json_encode(['found' => false, 'results' => []]);
    exit;
}

$searchTerm = "%$query%";
$where_clauses = ["$filter LIKE ?"];
$params = [$searchTerm];
$types = "s";

// Existing Status Logic
if ($status === 'Approved') {
    $where_clauses[] = "(Action_Taken LIKE '%approved%' OR Folder LIKE '%approved%' OR Action_Taken LIKE '%passed%')";
} elseif ($status === 'Rejected') {
    $where_clauses[] = "(Action_Taken LIKE '%disapproved%' OR Action_Taken LIKE '%denied%' OR Action_Taken LIKE '%dropped%')";
} elseif ($status === 'Pending') {
    $where_clauses[] = "(Action_Taken NOT LIKE '%approved%' AND Folder NOT LIKE '%approved%' AND Action_Taken NOT LIKE '%disapproved%')";
}

// NEW: Proponent Type Logic
if ($prop_type === 'Single') {
    // Does NOT contain comma, 'and', or '&'
    $where_clauses[] = "Proponent NOT LIKE '%,%' AND Proponent NOT LIKE '% and %' AND Proponent NOT LIKE '% & %'";
} elseif ($prop_type === 'Multiple') {
    // DOES contain comma, 'and', or '&'
    $where_clauses[] = "(Proponent LIKE '%,%' OR Proponent LIKE '% and %' OR Proponent LIKE '% & %')";
}

$sql = "SELECT Subject, Ref_No, Folder, Action_Taken, Date_Received, Proponent FROM city_records WHERE " . implode(' AND ', $where_clauses) . " ORDER BY Date_Received DESC LIMIT 20";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

$results = [];
while ($row = $res->fetch_assoc()) { $results[] = $row; }

echo json_encode(['found' => (count($results) > 0), 'results' => $results]);
?>