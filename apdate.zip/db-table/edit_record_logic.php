<?php
session_start();
// Prevent PHP errors from leaking into JSON output
error_reporting(0);
ini_set('display_errors', 0);

include '../db.php';
header('Content-Type: application/json');

try {
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        throw new Exception("Invalid request method.");
    }

    $record_id = $_POST['record_id'] ?? null;
    $input_passkey = $_POST['verify_passkey'] ?? '';

    if (!$record_id) throw new Exception("Record ID missing.");

    // 1. SIMPLE SECURITY CHECK (Matches any active admin passkey)
    $auth = $conn->prepare("SELECT id FROM users WHERE passkey = ? AND status = 'active' LIMIT 1");
    $auth->bind_param("s", $input_passkey);
    $auth->execute();
    if ($auth->get_result()->num_rows === 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid Administrative Passkey.']);
        exit;
    }

    // 2. THE 21 COLUMNS (Must match your database exactly)
    $fields = [
        'Date_Received', 'Time_Received', 'Ref_No', 'Type', 'Proponent', 
        'Subject', 'Subject_Description', 'Subject_Notation', 'Committee_Referred', 
        'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 
        'Com_Rep_Date_Received', 'Item_Nr', 'Agenda_Date', 'Action_Taken', 
        'Indorsement2', 'Indorsement2_Date', 'Remarks', 'Folder'
    ];
    
    $set_clause = [];
    $params = [];
    $types = "";

    // Find the field loop inside edit_record_logic.php and update this part:
foreach($fields as $f) {
    $set_clause[] = "$f = ?";
    $val = isset($_POST[$f]) ? trim($_POST[$f]) : "";

    // --- TIMELINE TRACKING LOGIC ---
    if ($f === 'Action_Taken') {
        $new_note = isset($_POST['new_action_note']) ? trim($_POST['new_action_note']) : "";
        if (!empty($new_note)) {
            $timestamp = date('M d, Y | h:i A');
            $entry = $timestamp . "@@@" . $new_note;
            
            // Prepend the new entry to the existing history
            if (!empty($val) && $val !== "-none-") {
                $val = $entry . "|||" . $val;
            } else {
                $val = $entry;
            }
        }
    }

    $params[] = (empty($val) || $val == "-none-") ? null : $val;
    $types .= "s";
}
    
    // 3. EXECUTE THE UPDATE
    $sql = "UPDATE city_records SET " . implode(', ', $set_clause) . " WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    // We need 21 "s" for the fields and 1 "i" for the ID = 22 total
    $bind_types = $types . "i";
    $bind_values = array_merge($params, [$record_id]);
    
    $stmt->bind_param($bind_types, ...$bind_values);
    
    if ($stmt->execute()) {
        // Trigger Sync Heartbeat
        $conn->query("UPDATE system_sync SET last_update = CURRENT_TIMESTAMP WHERE module_name = 'records'");
        echo json_encode(['status' => 'success']);
    } else {
        throw new Exception("Database error: " . $conn->error);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

?>