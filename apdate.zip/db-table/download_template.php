<?php
// Clear any previous output buffers to prevent corruption
if (ob_get_level()) ob_end_clean();

// 1. Define the exact 21 headers
$headers = [
    'Date_Received', 'Time_Received', 'Ref_No', 'Type', 'Proponent', 'Subject', 
    'Subject_Description', 'Subject_Notation', 'Committee_Referred', 
    'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 
    'Com_Rep_Date_Received', 'Com_Rep_Time_Received', 'Item_Nr', 
    'Agenda_Date', 'Action_Taken', 'Indorsement2', 'Indorsement2_Date', 
    'Remarks', 'Folder'
];

// 2. Define an example row
$example = [
    '2024-05-21', '14:30:00', '2024-21', 'Memorandum', 'Office of the Mayor', 'Sample Subject', 
    'Detailed description here', 'Notation here', 'Health Committee', '1st Indorsement', '2024-05-22', 
    'CR-001', 'Approved', '2024-05-23', '09:00:00', 'Item-45', 
    '2024-05-25', 'Discussion held', '2nd Indorsement', '2024-05-26', 
    'No remarks', 'Folder 2024-A'
];

// 3. Set Download Headers
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="BCH_Template.csv"');
header('Pragma: no-cache');
header('Expires: 0');

// 4. Create the CSV content using a memory pointer
$fp = fopen('php://temp', 'w');
fputcsv($fp, $headers);
fputcsv($fp, $example);

// 5. Rewind and output the content
rewind($fp);
echo stream_get_contents($fp);
fclose($fp);
exit();
?>