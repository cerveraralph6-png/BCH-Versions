<?php 
include_once '../auth_check.php';
include '../db.php'; 

$current_user = $_SESSION['user_id'];

// 1. Check for unread RECEIVED FILES
$notifQuery = $conn->prepare("SELECT COUNT(*) as unread_count FROM file_transfers WHERE receiver_id = ? AND is_read = 0");
$notifQuery->bind_param("i", $current_user);
$notifQuery->execute();
$unread_count = $notifQuery->get_result()->fetch_assoc()['unread_count'];

// 2. NEW: Check for unread MESSAGES
$msgNotifQuery = $conn->prepare("SELECT COUNT(*) as unread_msg_count FROM messages WHERE receiver_id = ? AND is_read = 0");
$msgNotifQuery->bind_param("i", $current_user);
$msgNotifQuery->execute();
$unread_msg_count = $msgNotifQuery->get_result()->fetch_assoc()['unread_msg_count'];
// 1. Count Unread Files
$notifQuery = $conn->prepare("SELECT COUNT(*) as unread_count FROM file_transfers WHERE receiver_id = ? AND is_read = 0");
$notifQuery->bind_param("i", $current_user);
$notifQuery->execute();
$unread_count = $notifQuery->get_result()->fetch_assoc()['unread_count'];

// 2. Count Unread Messages
$msgQuery = $conn->prepare("SELECT COUNT(*) as unread_msgs FROM messages WHERE receiver_id = ? AND is_read = 0");
$msgQuery->bind_param("i", $current_user);
$msgQuery->execute();
$unread_msgs = $msgQuery->get_result()->fetch_assoc()['unread_msgs'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="icon" href="../Imag3s/baguio-logo-gov.webp" type="image/png">
    <title>BCH | Admin Dashboard</title>
    <link rel="stylesheet" href="../CSS/admin.css">
    <!-- Link the Chat CSS -->
    <link rel="stylesheet" href="../CSS/chat.css?v=<?php echo filemtime('../CSS/chat.css'); ?>">
    
    <style>
        /* --- LOADER STYLES --- */
        #page-loader {
            position: fixed; inset: 0; width: 100%; height: 100%; background: #ffffff;
            z-index: 99999; display: flex; align-items: center; justify-content: center;
            transition: opacity 0.6s cubic-bezier(0.4, 0, 0.2, 1), visibility 0.6s;
        }
        .loader-wrapper { position: relative; width: 120px; height: 120px; display: flex; align-items: center; justify-content: center; }
        .loader-logo { width: 70px; height: 70px; object-fit: contain; z-index: 10; animation: logo-pulse 2s ease-in-out infinite; }
        .loader-circle { position: absolute; width: 110px; height: 110px; border: 4px solid #f1f5f9; border-top: 4px solid var(--primary); border-radius: 50%; animation: spin 1s cubic-bezier(0.55, 0.17, 0.45, 0.89) infinite; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        @keyframes logo-pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.1); opacity: 0.8; } }
        .loader-hidden { opacity: 0; visibility: hidden; }

        /* --- NOTIFICATION STYLES --- */
        /* Notification Badges */
        .notif-badge {
            position: absolute; top: -5px; right: -5px;
            background: #ef4444; color: white;
            font-size: 10px; font-weight: 800;
            padding: 2px 6px; border-radius: 50%;
            border: 2px solid white;
        }
        .tool-card.has-notif { border-color: #3b82f6; background: #eff6ff; }
        .new-label { background: #3b82f6; color: white; font-size: 10px; padding: 2px 8px; border-radius: 10px; margin-left: 10px; font-weight: 800; }
    </style>
</head>
<body class="dashboard-bg">
    
    <div id="page-loader">
        <div class="loader-wrapper">
            <img src="../Imag3s/baguio-logo-gov.png" alt="BCH" class="loader-logo">
            <div class="loader-circle"></div>
        </div>
    </div>

   <nav class="glass-nav">
        <div class="nav-left">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo" class="nav-logo">
            <div class="nav-titles">
                <h1>Sangguniang Panlungsod</h1>
                <span>City Council (Baguio City)</span>
            </div>
        </div>
        <div class="nav-actions">
            <!-- NEW: Messaging Button -->
            <button class="btn-icon" title="Messages" style="position:relative;" onclick="window.location.href='../tools/messenger.php'">
                💬 <?php if($unread_msgs > 0): ?><span class="notif-badge"><?php echo $unread_msgs; ?></span><?php endif; ?>
            </button>

            <!-- Notification Bell (Files) -->
            <button class="btn-icon" title="Notifications" style="position:relative;" onclick="window.location.href='../tools/files.php'">
                🔔 <?php if($unread_count > 0): ?><span class="notif-badge"><?php echo $unread_count; ?></span><?php endif; ?>
            </button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main class="fade-in">
        <section class="welcome-section">
            <div class="greetings">
                <h1>Welcome back, <span class="admin-name">Admin!</span></h1>
                <p>System Overview & Control Panel</p>
            </div>
            <div class="date-display">
                <span id="current-date"><?php echo date('F d, Y'); ?></span>
            </div>
        </section>

        <h2 class="section-label">Management Tools</h2>
        
        <div class="card-grid">
            <a href="../tools/events.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper"><img src="../Imag3s/events.webp" alt="events"></div>
                    <div class="tool-info"><h3>Events</h3><p>Seminars & Trainings</p></div>
                </div>
            </a>

            <a href="../db-table/table.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper"><img src="../Imag3s/database.webp" alt="database"></div>
                    <div class="tool-info"><h3>Registry</h3><p>Central Database</p></div>
                </div>
            </a>

            <a href="../tools/files.php" class="card-link">
                <div class="tool-card <?php echo ($unread_count > 0) ? 'has-notif' : ''; ?>">
                    <div class="icon-wrapper"><img src="../Imag3s/Files.webp" alt="files"></div>
                    <div class="tool-info">
                        <h3>Cloud Files <?php if($unread_count > 0): ?><span class="new-label">NEW</span><?php endif; ?></h3>
                        <p><?php echo ($unread_count > 0) ? "You received $unread_count new file(s)" : "Storage & Transfer"; ?></p>
                    </div>
                </div>
            </a>

            <a href="../tools/manage-accounts.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper"><img src="../Imag3s/accounts.webp" alt="accounts"></div>
                    <div class="tool-info"><h3>Accounts</h3><p>User Management</p></div>
                </div>
            </a>
            
            <a href="../admin/security_logs.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper"><img src="../Imag3s/security.webp" alt="security"></div>
                    <div class="tool-info"><h3>Security</h3><p>Login & IP Logs</p></div>
                </div>
            </a>
        </div>
    </main>

    <!-- Include the Chat Widget -->
    <?php include '../tools/chat_widget.php'; ?>

    <script>
        // Provide the user ID to the JavaScript messenger logic
        const currentUserId = <?php echo (int)$current_user; ?>;
    </script>
    <script src="../scripts/main.js"></script>
</body>
</html>