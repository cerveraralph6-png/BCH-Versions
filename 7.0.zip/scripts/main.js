// --- PAGE LOAD HANDLER ---
window.addEventListener('load', () => {
    const loader = document.getElementById('page-loader');
    if (loader) {
        // Add the hidden class
        loader.classList.add('loader-hidden');
        
        // Remove from DOM after transition to save resources
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500); 
    }
});

// ... rest of your existing logic (login, trackOrdinance, clearTrackSearch) ...

document.addEventListener('DOMContentLoaded', () => {
    console.log("BCH System Active...");

    // --- 1. AJAX LOGIN ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const errorDiv = document.getElementById('error-msg');
            const formData = new FormData(this);
            fetch('login_process.php', { method: 'POST', body: formData })
            .then(res => res.json()).then(data => {
                if (data.status === 'success') { window.location.href = data.redirect; } 
                else { errorDiv.innerText = data.message || "Invalid Passkey!"; }
            }).catch(err => console.error("Login Error:", err));
        });
    }

    // --- 2. GLOBAL NAV ---
    /*const dashboardBtn = document.getElementById("Dashboard");
    if (dashboardBtn) { 
        dashboardBtn.addEventListener("click", () => { window.location.href = "/admin/admin.php"; }); 
    }*/

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) { logoutBtn.addEventListener('click', () => { window.location.href = '/logout.php'; }); }

    // --- 3. CSV UPLOAD LOADER ---
    const importForm = document.querySelector('#modal-import form');
    if (importForm) {
        importForm.addEventListener('submit', () => { document.getElementById('upload-loader').style.display = 'flex'; });
    }

    // --- 4. SELECTIVE DOWNLOAD ---
    const selectAll = document.getElementById('select-all-rows');
    const exportBtn = document.getElementById('btn-export-selected');
    const countDisplay = document.getElementById('selected-count');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.record-checkbox').forEach(cb => cb.checked = this.checked);
            updateExportButtonState();
        });
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('record-checkbox')) updateExportButtonState();
        });
        function updateExportButtonState() {
            const checkedCount = document.querySelectorAll('.record-checkbox:checked').length;
            if(countDisplay) countDisplay.innerText = checkedCount;
            if (exportBtn) {
                exportBtn.style.setProperty('opacity', checkedCount > 0 ? '1' : '0.5', 'important');
                exportBtn.style.setProperty('pointer-events', checkedCount > 0 ? 'auto' : 'none', 'important');
            }
        }
    }

    // --- 5. SMART REAL-TIME SYNC (Safety Mode) ---
    const pagePath = window.location.pathname;
    let moduleName = "";
    
    if (pagePath.includes('table.php')) moduleName = "records";
    else if (pagePath.includes('events.php')) moduleName = "events";

    if (moduleName !== "") {
        let lastSyncTime = Math.floor(Date.now() / 1000);
        
        setInterval(() => {
            // Safety 1: Stop request if user is not looking at the tab
            if (document.hidden) return;

            // Safety 2: Use Absolute Path
            const root = window.location.origin;
            const syncUrl = `${root}/tools/sync_check.php`;

            fetch(`${syncUrl}?module=${moduleName}&last_sync=${lastSyncTime}&v=${Date.now()}`, {
                method: 'GET',
                credentials: 'include', // Sends security cookies
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(res => res.json())
            .then(data => {
                if (data.update_needed) {
                    console.log("Changes detected. Syncing UI...");
                    refreshPageFragments();
                    lastSyncTime = data.server_time;
                }
            })
            .catch(err => console.log("Sync standby..."));
        }, 5000); // 30 seconds is the stable threshold for zya.me
    }
});

/**
 * Background Fragment Swapping
 */
function refreshPageFragments() {
    fetch(window.location.href, { credentials: 'include' })
    .then(response => response.text())
    .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const containers = ['tbody', '.table-pagination', '.pagination', '.stats-badges', '.badge-row', '.stats-info'];

        containers.forEach(selector => {
            const newData = doc.querySelector(selector);
            const currentArea = document.querySelector(selector);
            if (newData && currentArea) {
                currentArea.innerHTML = newData.innerHTML;
            }
        });
    })
    .catch(err => console.warn("Refresh delayed due to server load."));
}

// ... Keep all your popup functions (openDetailByIndex, navRecord, renderDetails, etc.) exactly as they were ...
// --- GLOBAL POPUP FUNCTIONS ---

let currentRecordIndex = -1;
let allPageRecords = [];
let currentRecordData = null;

function openDetailByIndex(index) {
    const stores = document.querySelectorAll('.json-store');
    allPageRecords = Array.from(stores).map(s => JSON.parse(s.innerText));
    currentRecordIndex = index;
    const modal = document.getElementById('modal-view-details');
    if (modal) { updateModalContent(allPageRecords[index]); modal.showModal(); }
}

function navRecord(step) {
    let nextIdx = currentRecordIndex + step;
    if (nextIdx >= 0 && nextIdx < allPageRecords.length) {
        currentRecordIndex = nextIdx;
        const editBtn = document.getElementById('btn-enable-edit');
        const saveBtn = document.getElementById('btn-trigger-verify');
        if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
        if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
        updateModalContent(allPageRecords[currentRecordIndex]);
    } else {
        alert(step > 0 ? "Last record." : "First record.");
    }
}

function updateModalContent(data) {
    currentRecordData = data;
    const title = document.getElementById('view-subject-title');
    if(title) title.innerText = data.Subject || "Details";
    const idField = document.getElementById('view-record-id');
    if(idField) idField.value = data.id;
    renderDetails(false); 
}



// --- NEW HELPER FUNCTION ---
function parseTimeline(dataString) {
    if (!dataString || dataString === "-none-" || dataString === "") {
        return "<p style='color:#94a3b8; font-size:0.85rem; font-style:italic;'>No history recorded yet.</p>";
    }
    
    const entries = dataString.split('|||').filter(e => e.trim() !== "");
    let html = '<div class="timeline-log">';
    
    entries.forEach(entry => {
        const parts = entry.split('@@@');
        const date = parts[0] || "Update";
        const text = parts[1] || entry;
        html += `
            <div class="timeline-entry">
                <span class="timeline-date">${date}</span>
                <p class="timeline-text">${text}</p>
            </div>`;
    });
    
    html += '</div>';
    return html;
}

// --- UPDATED RENDER DETAILS ---
function renderDetails(isEditMode) {
    const content = document.getElementById('details-content');
    const data = currentRecordData;

    const fields = {
        "Date_Received": "Date Received", "Time_Received": "Time Received", "Ref_No": "Ref No.", 
        "Type": "Type", "Proponent": "Proponent", "Subject": "Subject", 
        "Action_Taken": "Action History Tracking", // The specific field
        "Subject_Description": "Description", "Subject_Notation": "Notation", 
        "Committee_Referred": "Committee Referred", "Indorsement1": "Indorsement 1", 
        "Date_Indorsed1": "Date Indorsed 1", "Com_Rep_Nr": "Com Rep Nr", 
        "Com_Rep": "Com Rep", "Com_Rep_Date_Received": "Date Rec (Rep)", 
        "Item_Nr": "Item Nr", "Agenda_Date": "Agenda Date", 
        "Indorsement2": "Indorsement 2", "Indorsement2_Date": "Date Ind 2", 
        "Remarks": "Remarks", "Folder": "Folder"
    };

    let html = '';
    for (const [key, label] of Object.entries(fields)) {
        let value = data[key] || "";
        const isLong = label.includes("Description") || label.includes("Notation") || label.includes("Remarks") || label === "Subject" || label === "Proponent" || key === "Action_Taken";
        const containerClass = isLong ? "detail-item full-width" : "detail-item";

        if (isEditMode) {
            if (key === "Action_Taken") {
                // REFINED LAYOUT FOR TIMELINE EDITOR
                html += `
                    <div class="${containerClass}">
                        <div class="new-update-area">
                            <span class="new-update-label">➕ Add New Progress Update</span>
                            <textarea name="new_action_note" placeholder="What happened today? (e.g. Approved by Committee)"></textarea>
                            
                            <div class="history-preview-box">
                                <label>Existing History Log</label>
                                ${parseTimeline(value)}
                            </div>
                            <input type="hidden" name="Action_Taken" value="${value}">
                        </div>
                    </div>`;
            } else {
                // Standard Inputs
                let inputField = isLong ? `<textarea name="${key}" rows="2">${value}</textarea>` : `<input type="text" name="${key}" value="${value}">`;
                if(key.toLowerCase().includes('date')) inputField = `<input type="date" name="${key}" value="${value}">`;
                if(key.toLowerCase().includes('time')) inputField = `<input type="time" name="${key}" value="${value}">`;
                html += `<div class="${containerClass}"><label class="detail-label">${label}</label>${inputField}</div>`;
            }
        } else {
            // VIEW MODE
            const displayVal = (value === "" || value === "-none-" || value === "0000-00-00") ? '<span class="none-text">-none-</span>' : value;
            html += `
                <div class="${containerClass}">
                    <label class="detail-label">${label}</label>
                    <div class="detail-value">${key === "Action_Taken" ? parseTimeline(value) : displayVal}</div>
                </div>`;
        }
    }
    content.innerHTML = html;
}

function enableEditMode() {
    renderDetails(true);
    const label = document.getElementById('modal-mode-label');
    if(label) { label.innerText = "⚠️ EDITING MODE"; label.style.color = "#ef4444"; }
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if (editBtn) editBtn.style.setProperty('display', 'none', 'important');
    if (saveBtn) saveBtn.style.setProperty('display', 'inline-flex', 'important');
}

function openVerifyModal() { document.getElementById('modal-verify-passkey').showModal(); }

function submitEditWithPasskey() {
    const passInput = document.getElementById('popup-passkey-input');
    const hiddenPasskey = document.getElementById('hidden-passkey');
    const editForm = document.getElementById('edit-detail-form');
    
    if (!passInput.value) { 
        alert("Please enter your passkey."); 
        return; 
    }

    // 1. Set the passkey into the hidden form field
    hiddenPasskey.value = passInput.value;

    // 2. Gather all form data
    const formData = new FormData(editForm);

    // 3. Send data via Fetch (AJAX) to bypass the "Unsafe attempt" block
fetch('edit_record_logic.php', {
        method: 'POST',
        body: formData
    })
    .then(async res => {
        const text = await res.text(); // Get raw text first
        try {
            return JSON.parse(text); // Try to parse as JSON
        } catch (e) {
            // If it's not JSON, the PHP crashed and printed an error
            console.error("Server Crash Output:", text);
            throw new Error("Server Error: The PHP script crashed. Check Console (F12).");
        }
    })
    .then(data => {
        if (data.status === 'success') {
            document.getElementById('modal-verify-passkey').close();
            closeDetailModal();
            refreshPageFragments();
            alert("Record updated successfully!");
        } else {
            alert("Error: " + data.message);
        }
    })
    .catch(err => {
        alert(err.message);
    });
}
function closeDetailModal() {
    document.getElementById('modal-view-details').close();
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
    if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
}

function exportSelectedRecords() {
    const ids = Array.from(document.querySelectorAll('.record-checkbox:checked')).map(cb => cb.value);
    if (ids.length > 0) window.location.href = `export_selected_csv.php?ids=${ids.join(',')}`;
}

function forgotPassword() { document.getElementById('modal-forgot').showModal(); }
function closeForgotModal() { document.getElementById('modal-forgot').close(); }
function verifyAndReveal() {
    const inputId = document.getElementById('verify-id').value;
    const display = document.getElementById('result-display');
    if(!inputId) return;
    let formData = new FormData();
    formData.append('employee_id', inputId);
    fetch('check_id.php', { method: 'POST', body: formData })
    .then(res => res.text()).then(data => {
        display.style.color = (data.includes("Passkey")) ? "#3b82f6" : "#ef4444";
        display.innerText = data;
    });
}

// --- Add this to your existing main.js ---

function trackOrdinance() {
    const query = document.getElementById('public-search-query').value;
    const filter = document.getElementById('public-filter-by').value;
    const statusFilter = document.getElementById('public-status-filter').value;
    const resultContainer = document.getElementById('ordinance-result-container');
    
    if (!query && statusFilter === "All") {
        alert("Please enter keywords or select a status.");
        return;
    }

    resultContainer.innerHTML = "<div class='loader-text'>Searching city registry...</div>";

    fetch(`tools/public_track.php?query=${encodeURIComponent(query)}&filter=${filter}&status=${statusFilter}`)
    .then(res => res.json())
    .then(data => {
        resultContainer.innerHTML = ""; 

        if (data.found) {
            data.results.forEach(item => {
                const actionRaw = item.Action_Taken || "";
                const actionClean = actionRaw.toLowerCase();
                const folderClean = (item.Folder || "").toLowerCase();

                // --- NEW LOGIC: EXTRACT LATEST ENTRY FROM HISTORY ---
                // 1. Split by '|||' to get individual history entries
                const historyEntries = actionRaw.split('|||');
                // 2. The first one [0] is the newest. Split it by '@@@' to separate Date and Action Text
                const latestEntryParts = historyEntries[0].split('@@@');
                
                // If there's a match, latestAction is the text. If not, fallback to the raw string.
                const latestActionDate = latestEntryParts[0] ? latestEntryParts[0].trim() : "";
                const latestActionText = latestEntryParts[1] ? latestEntryParts[1].trim() : latestEntryParts[0];

                let statusClass = "status-pending";
                let statusText = "Pending Review";

                // Check for Approved status
                if (actionClean.includes("approved") || folderClean.includes("approved") || actionClean.includes("passed")) {
                    statusClass = "status-approved";
                    // Dynamic text: APPROVED: [The actual specific action from the history]
                    statusText = `Approved: ${latestActionText}`;
                } else if (actionClean.includes("disapproved") || actionClean.includes("dropped")) {
                    statusClass = "status-disapproved";
                    statusText = `Rejected: ${latestActionText}`;
                }

                // Render the Result Card
                resultContainer.innerHTML += `
                    <div class="result-box ${statusClass}-border">
                        <div class="result-header">
                            <span class="status-pill ${statusClass}">${statusText}</span>
                            <small class="result-meta">Rec: ${item.Date_Received}</small>
                        </div>
                        
                        <h3 class="result-subject">${item.Subject}</h3>
                        
                        <div class="result-footer" style="margin-top:15px; padding-top:12px; border-top:1px dashed #ddd; font-size:0.85rem; color:#64748b;">
                            <strong>Final Ordinance Number:</strong> ${item.Ref_No || '-none-'} <br>
                            <strong>Proponent:</strong> ${item.Proponent || 'N/A'} <br>
                            <div style="margin-top:8px; color:#1e293b;">
                                <strong>Latest Update:</strong> ${latestActionText} 
                                <span style="color:#94a3b8; font-size:0.75rem;">(${latestActionDate})</span>
                            </div>
                        </div>
                    </div>`;
            });
        } else {
            resultContainer.innerHTML = `<div class="result-empty">No matching records found.</div>`;
        }
    });
}
// --- PUBLIC SEARCH CLEAR FUNCTION ---
function clearTrackSearch() {
    // 1. Get the elements
    const queryInput = document.getElementById('public-search-query');
    const filterSelect = document.getElementById('public-filter-by');
    const resultContainer = document.getElementById('ordinance-result-container');

    // 2. Clear the search text
    if (queryInput) {
        queryInput.value = "";
    }

    // 3. Clear the displayed results
    if (resultContainer) {
        resultContainer.innerHTML = "";
    }

    // 4. Reset the filter dropdown to the first option (Subject)
    if (filterSelect) {
        filterSelect.selectedIndex = 0;
    }

    // 5. Put the typing cursor back in the box for convenience
    if (queryInput) {
        queryInput.focus();
    }

    console.log("Search engine reset.");
}