<?php
session_start();
include '../db.php';

// Enable error reporting to find out why it fails
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['my_file'])) {
    $uploader_id = $_SESSION['user_id'];
    $file = $_FILES['my_file'];

    // Check for PHP upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        die("Upload failed with error code: " . $file['error']);
    }

    $fileName = basename($file['name']);
    $fileSize = round($file['size'] / 1024, 2) . " KB";
    
    // THE PATH: Since upload_handler is in /tools/, ../uploads/ is the root uploads folder
    $targetDir = "../uploads/"; 

    // FIX 1: Create the directory if it doesn't exist
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // FIX 2: Generate a safe filename (remove spaces and add timestamp)
    $cleanFileName = preg_replace("/[^a-zA-Z0-9.]/", "_", $fileName);
    $uniqueName = time() . "_" . $cleanFileName;
    
    $targetPath = $targetDir . $uniqueName;
    $dbPath = "uploads/" . $uniqueName; // Store this for the View link

    // FIX 3: Check if move was successful
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        $stmt = $conn->prepare("INSERT INTO files (uploader_id, filename, file_path, file_size) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $uploader_id, $fileName, $dbPath, $fileSize);
        
        if ($stmt->execute()) {
            header("Location: files.php?success=uploaded");
            exit();
        } else {
            echo "Database Error: " . $conn->error;
        }
    } else {
        echo "Error: Could not move file to $targetDir. Check folder permissions (CHMOD 777).";
    }
} else {
    echo "No file detected in the request.";
}
?>