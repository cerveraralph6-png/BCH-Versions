<?php
include_once '../auth_check.php';
include '../db.php'; 

date_default_timezone_set('Asia/Manila'); 
$now = new DateTime();

// Get the selected category from the URL
$selected_cat = isset($_GET['cat']) ? $_GET['cat'] : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>BCH | Events Management</title>
</head>
<body>
    <nav>
        <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
        <h1>Baguio City Database</h1>
        <div class="nav-actions">
            <button id="Dashboard" onclick="window.location.href='/admin/admin.php'">Home</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main>
        <?php if (!$selected_cat): ?>
            <!-- --- CATEGORY SELECTION CARDS --- -->
            <div id="container1">
                <div class="table-header">
                    <h1>Select Event Category</h1>
                </div>
                <div class="year-grid">
                    <a href="?cat=Seminar" class="year-card-link">
                        <div class="year-card">
                            <div class="year-icon">🎓</div>
                            <h2>Seminars</h2>
                            <p>Manage workshops and educational talks</p>
                            <span class="view-btn">Open Category →</span>
                        </div>
                    </a>
                    <a href="?cat=Training" class="year-card-link">
                        <div class="year-card">
                            <div class="year-icon">🏋️</div>
                            <h2>Trainings</h2>
                            <p>Manage employee skill development</p>
                            <span class="view-btn">Open Category →</span>
                        </div>
                    </a>
                    <a href="?cat=Others" class="year-card-link">
                        <div class="year-card">
                            <div class="year-icon">📂</div>
                            <h2>Others</h2>
                            <p>General events and special occasions</p>
                            <span class="view-btn">Open Category →</span>
                        </div>
                    </a>
                </div>
            </div>

        <?php else: ?>
            <!-- --- THE MAIN MANAGEMENT TABLE (Filtered by Category) --- -->
            <div id="container1">
                <div class="table-header">
                    <div style="display:flex; align-items:center; gap:15px;">
                        <button class="btn-nav" onclick="window.location.href='events.php'" style="padding: 5px 10px;">← Back</button>
                        <h1><?php echo $selected_cat; ?> Management</h1>
                    </div>
                    <button id="add" onclick="document.getElementById('event-modal').showModal()">+ Add <?php echo $selected_cat; ?></button>
                </div>

                <div class="search-filter-section">
                    <div class="search-field">
                        <span class="search-icon">🔍</span>
                        <input type="text" id="event-search" placeholder="Search in <?php echo $selected_cat; ?>...">
                    </div>
                    <div class="filter-field">
                        <select id="status-filter">
                            <option value="all">All Status</option>
                            <option value="Pending">Pending</option>
                            <option value="Today">Today</option>
                            <option value="Ongoing">Ongoing</option>
                            <option value="Ended">Ended</option>
                        </select>
                    </div>
                </div>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Event Name</th>
                                <th>Date & Time</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="events-table-body">
<?php
$stmt = $conn->prepare("SELECT * FROM events WHERE category = ? ORDER BY event_date ASC, event_time ASC");
$stmt->bind_param("s", $selected_cat);
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $name = htmlspecialchars($row['event_name']);
    $date_raw = $row['event_date'];
    $time_raw = $row['event_time'];
    $loc = htmlspecialchars($row['location']);
    $desc = htmlspecialchars($row['description']);
    $manual_status = $row['status']; // 'pending' or 'done'

    // --- RELIABLE DYNAMIC STATUS LOGIC ---
    $event_start_ts = strtotime($date_raw . ' ' . $time_raw); 
    $event_day_ts   = strtotime($date_raw);                  
    $today_ts       = strtotime(date('Y-m-d'));             
    $now_ts         = time();                                

    if ($manual_status == 'done') {
        $statusText = "Ended";
        $badgeClass = "archived";
    } elseif ($event_day_ts < $today_ts) {
        $statusText = "Ended";
        $badgeClass = "archived";
    } elseif ($event_day_ts == $today_ts) {
        if ($now_ts >= $event_start_ts) {
            $statusText = "Ongoing";
            $badgeClass = "active";
        } else {
            $statusText = "Today";
            $badgeClass = "role-tag";
        }
    } else {
        $statusText = "Pending";
        $badgeClass = "role-tag";
    }

    // --- TABLE ROW OUTPUT ---
    echo "<tr class='event-row' data-name='".strtolower($name)."' data-location='".strtolower($loc)."' data-status='$statusText'>
        <td style='font-weight:600;'>$name</td>
        <td>" . date('M d, Y', strtotime($date_raw)) . "<br><small>" . date('h:i A', strtotime($time_raw)) . "</small></td>
        <td>$loc</td>
        <td><span class='badge $badgeClass'>$statusText</span></td>
        <td>
            <div class='action-group'>
                <button class='btn-action btn-edit-blue' onclick='openEditEventModal($id, \"$name\", \"$selected_cat\", \"$date_raw\", \"$time_raw\", \"$loc\", \"$desc\")'>Edit</button>
                
                <!-- FIXED: Changed $status to $manual_status -->
                <button class='btn-action' onclick='window.location.href=\"toggle_event_status.php?id=$id&cat=".urlencode($selected_cat)."\"' style='border-color:#bbf7d0;'>
                    " . ($manual_status == 'done' ? '🔓 Reset' : '✅ Done') . "
                </button>
                
                <button class='btn-action' onclick='if(confirm(\"Delete this event?\")) window.location.href=\"delete_event.php?id=$id&cat=".urlencode($selected_cat)."\"' style='color:#dc2626; border-color:#fecaca;'>🗑️</button>
            </div>
        </td>
    </tr>";
}
?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <!-- CREATE MODAL (Updated with hidden Category) -->
    <dialog id="event-modal">
        <form action="add_event.php" method="POST">
            <h2>Add <?php echo $selected_cat; ?></h2>
            <input type="hidden" name="category" value="<?php echo $selected_cat; ?>">
            <label>Event Name</label>
            <input type="text" name="event_name" placeholder="Name" required>
            <label>Date</label>
            <input type="date" name="event_date" required>
            <label>Time</label>
            <input type="time" name="event_time" required>
            <label>Location</label>
            <input type="text" name="location" placeholder="Location" required>
            <label>Description</label>
            <textarea name="description" placeholder="Description" style="width: 100%; padding: 12px; border: 1.5px solid #e2e8f0; border-radius: 10px; margin-bottom: 18px; min-height: 80px;"></textarea>
            <div class="modal-actions">
                <button type="submit" class="btn-save">Save</button>
                <button type="button" class="btn-cancel" onclick="document.getElementById('event-modal').close()">Cancel</button>
            </div>
        </form>
    </dialog>

    <!-- EDIT MODAL (Updated with Category Select) -->
    <dialog id="edit-event-modal">
        <form action="update_event.php" method="POST">
            <h2>Edit Event</h2>
            <input type="hidden" name="event_id" id="edit-event-id">
            <label>Category</label>
            <select name="category" id="edit-event-category">
                <option value="Seminar">Seminar</option>
                <option value="Training">Training</option>
                <option value="Others">Others</option>
            </select>
            <label>Event Name</label>
            <input type="text" name="event_name" id="edit-event-name" required>
            <label>Date</label>
            <input type="date" name="event_date" id="edit-event-date" required>
            <label>Time</label>
            <input type="time" name="event_time" id="edit-event-time" required>
            <label>Location</label>
            <input type="text" name="location" id="edit-event-location" required>
            <textarea name="description" id="edit-event-desc"></textarea>
            <div class="modal-actions">
                <button type="submit" class="btn-save">Update</button>
                <button type="button" class="btn-cancel" onclick="document.getElementById('edit-event-modal').close()">Cancel</button>
            </div>
        </form>
    </dialog>

    <script src="/scripts/main.js"></script>
</body>
</html>