<?php
include_once '../auth_check.php';
include '../db.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$cat = isset($_GET['cat']) ? $_GET['cat'] : 'Others';

if ($id > 0) {
    $conn->query("DELETE FROM events WHERE id = $id");
}

// Add this right after a successful SQL execution
$conn->query("UPDATE system_sync SET last_update = NOW() WHERE module_name = 'events'");

// Redirect back to the specific category
header("Location: events.php?cat=" . urlencode($cat) . "&success=deleted");
exit();
?>