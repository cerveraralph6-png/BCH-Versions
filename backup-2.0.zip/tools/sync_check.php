<?php
include '../db.php';
header('Content-Type: application/json');

$module = $_GET['module'];
$client_time = $_GET['last_sync'];

$stmt = $conn->prepare("SELECT last_update FROM system_sync WHERE module_name = ?");
$stmt->bind_param("s", $module);
$stmt->execute();
$server_time = $stmt->get_result()->fetch_assoc()['last_update'];

// If the server has a newer timestamp than the browser, tell browser to refresh
echo json_encode(['update_needed' => (strtotime($server_time) > strtotime($client_time))]);

?>