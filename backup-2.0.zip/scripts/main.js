document.addEventListener('DOMContentLoaded', () => {
    console.log("BCH System Active...");
    
    // --- REAL-TIME REFRESH LOGIC ---
function refreshEventsRealtime() {
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('cat');
    const tableBody = document.getElementById('events-table-body');

    if (!tableBody || !category) return; // Only run on the events table page

    fetch(`get_events_data.php?cat=${category}`)
        .then(res => res.json())
        .then(data => {
            let html = '';
            data.forEach(event => {
                html += `
                <tr class="event-row" id="event-row-${event.id}">
                    <td style="font-weight:600;">${event.event_name}</td>
                    <td>${event.event_date}<br><small>${event.event_time}</small></td>
                    <td>${event.location}</td>
                    <td><span class="badge ${event.dynamic_class}">${event.dynamic_status}</span></td>
                    <td>
                        <div class="action-group">
                            <button class="btn-action btn-edit-blue" onclick='openEditEventModal(${event.id}, "${event.event_name}", "${event.category}", "${event.event_date}", "${event.event_time}", "${event.location}", "${event.description}")'>Edit</button>
                            <button class="btn-action" onclick="ajaxToggleStatus(${event.id})" style="border-color:#bbf7d0;">${event.status === 'done' ? '🔓 Reset' : '✅ Done'}</button>
                            <button class="btn-action" onclick="ajaxDeleteEvent(${event.id})" style="color:#dc2626; border-color:#fecaca;">🗑️</button>
                        </div>
                    </td>
                </tr>`;
            });
            tableBody.innerHTML = html;
        });
}

// Start the real-time loop (Every 5 seconds)
if (document.getElementById('events-table-body')) {
    setInterval(refreshEventsRealtime, 5000);
}

    // --- 1. LOGIN FORM HANDLER ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const errorDiv = document.getElementById('error-msg');
            const formData = new FormData(this);
            fetch('login_process.php', { method: 'POST', body: formData })
            .then(res => res.json()).then(data => {
                if (data.status === 'success') { window.location.href = data.redirect; } 
                else { 
                    errorDiv.innerText = data.message || "Invalid Passkey!";
                    setTimeout(() => { errorDiv.innerText = ""; }, 2000);
                }
            }).catch(err => console.error("Login Error:", err));
        });
    }

    // --- 2. GLOBAL NAVIGATION & LOGOUT ---
    const dashboardBtn = document.getElementById("Dashboard");
    if (dashboardBtn) {
        dashboardBtn.addEventListener("click", () => { window.location.href = "/admin/admin.php"; });
    }

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            alert('You have been logged out!');
            window.location.href = '/logout.php';
        });
    }

    // --- 3. SEARCH & FILTER (EVENTS & ARCHIVE) ---
    const eventSearch = document.getElementById('event-search');
    const statusFilter = document.getElementById('status-filter');
    if (eventSearch) {
        const filterEvents = () => {
            const query = eventSearch.value.toLowerCase().trim();
            const filterValue = statusFilter ? statusFilter.value : 'all';
            document.querySelectorAll('.event-row').forEach(row => {
                const name = row.getAttribute('data-name') || "";
                const loc = row.getAttribute('data-location') || "";
                const status = row.getAttribute('data-status') || "";
                const matchesSearch = name.includes(query) || loc.includes(query);
                const matchesStatus = (filterValue === 'all' || status === filterValue);
                row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
            });
        };
        eventSearch.addEventListener('input', filterEvents);
        if(statusFilter) statusFilter.addEventListener('change', filterEvents);
    }

    // --- 4. ARCHIVE YEAR SEARCH & SORT ---
    const yearSearch = document.getElementById('year-search');
    const yearSort = document.getElementById('year-sort');
    const yearGrid = document.getElementById('year-grid');
    if (yearSearch && yearGrid) {
        yearSearch.addEventListener('input', function() {
            const query = this.value;
            document.querySelectorAll('.year-card-link').forEach(card => {
                const year = card.getAttribute('data-year');
                card.style.display = year.includes(query) ? "" : "none";
            });
        });

        if (yearSort) {
            yearSort.addEventListener('change', function() {
                const cards = Array.from(document.querySelectorAll('.year-card-link'));
                const isAsc = this.value === 'asc';
                cards.sort((a, b) => {
                    const yA = parseInt(a.getAttribute('data-year'));
                    const yB = parseInt(b.getAttribute('data-year'));
                    return isAsc ? yA - yB : yB - yA;
                });
                cards.forEach(card => yearGrid.appendChild(card));
            });
        }
    }

    // --- 5. FILE UPLOAD HELPER ---
    const actualBtn = document.getElementById('actual-btn');
    const fileChosen = document.getElementById('file-chosen');
    if (actualBtn && fileChosen) {
        actualBtn.addEventListener('change', function() {
            fileChosen.textContent = this.files[0] ? this.files[0].name : "No file chosen";
        });
    }

    // --- 6. AUTO LOGOUT INACTIVITY TIMER ---
    if (!window.location.pathname.includes('index.php') && window.location.pathname !== '/') {
        window.onmousemove = resetInactivityTimer;
        window.onmousedown = resetInactivityTimer;
        window.onclick = resetInactivityTimer;
        window.onscroll = resetInactivityTimer;
        window.onkeypress = resetInactivityTimer;
        resetInactivityTimer();
    }

    // --- 7. SELECTIVE DOWNLOAD LOGIC ---
    const selectAll = document.getElementById('select-all-rows');
    const exportBtn = document.getElementById('btn-export-selected');
    const countDisplay = document.getElementById('selected-count');

    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.record-checkbox').forEach(cb => cb.checked = this.checked);
            updateExportButtonState();
        });

        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('record-checkbox')) {
                updateExportButtonState();
            }
        });

        function updateExportButtonState() {
            const checkedCount = document.querySelectorAll('.record-checkbox:checked').length;
            if(countDisplay) countDisplay.innerText = checkedCount;
            if (exportBtn) {
                if (checkedCount > 0) {
                    exportBtn.style.setProperty('opacity', '1', 'important');
                    exportBtn.style.setProperty('pointer-events', 'auto', 'important');
                } else {
                    exportBtn.style.setProperty('opacity', '0.5', 'important');
                    exportBtn.style.setProperty('pointer-events', 'none', 'important');
                    if(selectAll) selectAll.checked = false;
                }
            }
        }
    }
});

// --- GLOBAL FUNCTIONS ---

function confirmImport() {
    return confirm("Double check your data! Dates that don't match this term's range will not be imported correctly. Proceed?");
}

let inactivityTimer;
function resetInactivityTimer() {
    if (window.location.pathname.includes('index.php') || window.location.pathname === '/') return;
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(() => {
        window.location.href = '/logout.php';
    }, 300000); 
}

function exportSelectedRecords() {
    const selectedIds = Array.from(document.querySelectorAll('.record-checkbox:checked')).map(cb => cb.value);
    if (selectedIds.length === 0) return;
    window.location.href = `export_selected_csv.php?ids=${selectedIds.join(',')}`;
}

let currentRecordData = null;
function viewRecordDetails(data) {
    currentRecordData = data; 
    document.getElementById('view-subject-title').innerText = data.Subject || "Details";
    document.getElementById('view-record-id').value = data.id;
    renderDetails(false); 
    document.getElementById('modal-view-details').showModal();
}

function renderDetails(isEditMode) {
    const content = document.getElementById('details-content');
    const data = currentRecordData;
    const fields = {
        "Date_Received": "Date Received", "Time_Received": "Time Received", "Type": "Type", 
        "Proponent": "Proponent", "Subject": "Subject", "Subject_Description": "Description", 
        "Subject_Notation": "Notation", "Committee_Referred": "Committee Referred", 
        "Indorsement1": "Indorsement 1", "Date_Indorsed1": "Date Indorsed 1", 
        "Com_Rep_Nr": "Com Rep Nr", "Com_Rep": "Com Rep", 
        "Com_Rep_Date_Received": "Com Rep Date Rec.", "Com_Rep_Time_Received": "Com Rep Time Rec.", 
        "Item_Nr": "Item Nr", "Agenda_Date": "Agenda Date", "Action_Taken": "Action Taken", 
        "Indorsement2": "Indorsement 2", "Indorsement2_Date": "Indorsement 2 Date", 
        "Remarks": "Remarks", "Folder": "Folder"
    };

    let html = '';
    for (const [key, label] of Object.entries(fields)) {
        let value = data[key] || "";
        const isLong = label.includes("Description") || label.includes("Indorsement") || label.includes("Report") || label.includes("Action") || label.includes("Remarks") || label === "Subject";
        const style = isLong ? "grid-column: span 2;" : "";

        if (isEditMode) {
            let input = isLong ? `<textarea name="${key}" rows="2" style="width:100%;">${value}</textarea>` : `<input type="text" name="${key}" value="${value}" style="width:100%;">`;
            if(key.includes('Date')) input = `<input type="date" name="${key}" value="${value}">`;
            if(key.includes('Time')) input = `<input type="time" name="${key}" value="${value}">`;
            html += `<div style="${style}"><label class="detail-label">${label}</label>${input}</div>`;
        } else {
            const displayVal = (value === "" || value === "-none-" || value === null) ? '<span style="color:#94a3b8; font-style:italic;">-none-</span>' : value;
            html += `<div style="${style} border-bottom: 1px solid #f8fafc; padding-bottom: 8px;"><label class="detail-label">${label}</label><div style="font-size:0.95rem; color:#1e293b; word-break:break-word;">${displayVal}</div></div>`;
        }
    }
    content.innerHTML = html;
}

function enableEditMode() {
    renderDetails(true);
    document.getElementById('modal-mode-label').innerText = "⚠️ EDITING MODE";
    document.getElementById('modal-mode-label').style.color = "#ef4444";
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if (editBtn) editBtn.style.setProperty('display', 'none', 'important');
    if (saveBtn) saveBtn.style.setProperty('display', 'inline-flex', 'important');
}

function openVerifyModal() { document.getElementById('modal-verify-passkey').showModal(); }

function submitEditWithPasskey() {
    const passInput = document.getElementById('popup-passkey-input');
    if (!passInput.value) { alert("Please enter your passkey."); return; }
    document.getElementById('hidden-passkey').value = passInput.value;
    passInput.value = ""; 
    document.getElementById('edit-detail-form').submit();
}

function closeDetailModal() {
    document.getElementById('modal-view-details').close();
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
    if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
    const label = document.getElementById('modal-mode-label');
    if(label) { label.innerText = "Document Details"; label.style.color = "#3b82f6"; }
}

function openEditModal(id, name, empId, pass, role) {
    document.getElementById('edit-user-id').value = id;
    document.getElementById('edit-full-name').value = name;
    document.getElementById('edit-employee-id').value = empId;
    document.getElementById('edit-passkey').value = pass;
    document.getElementById('edit-role').value = role;
    document.getElementById('modal-edit').showModal();
}

function openEditEventModal(id, name, category, date, time, location, desc) {
    document.getElementById('edit-event-id').value = id;
    document.getElementById('edit-event-name').value = name;
    document.getElementById('edit-event-category').value = category; 
    document.getElementById('edit-event-date').value = date;
    document.getElementById('edit-event-time').value = time;
    document.getElementById('edit-event-location').value = location;
    document.getElementById('edit-event-desc').value = desc;
    document.getElementById('edit-event-modal').showModal();
}

function forgotPassword() { document.getElementById('modal-forgot').showModal(); }
function closeForgotModal() { document.getElementById('modal-forgot').close(); }
function verifyAndReveal() {
    const inputId = document.getElementById('verify-id').value;
    const display = document.getElementById('result-display');
    if(!inputId) return;
    let formData = new FormData();
    formData.append('employee_id', inputId);
    fetch('check_id.php', { method: 'POST', body: formData })
    .then(res => res.text()).then(data => {
        display.style.color = (data.includes("Passkey")) ? "#3b82f6" : "#ef4444";
        display.innerText = data;
    });
}

// --- AJAX EVENTS HELPERS ---

function ajaxDeleteEvent(id) {
    if (!confirm("Are you sure you want to delete this event?")) return;
    fetch(`delete_event.php?id=${id}`).then(res => res.json()).then(data => {
        if (data.status === 'success') {
            const row = document.getElementById(`event-row-${id}`);
            if (row) row.remove();
        }
    });
}

function ajaxToggleStatus(id) {
    fetch(`toggle_event_status.php?id=${id}`).then(res => res.json()).then(data => {
        if (data.status === 'success') {
            // Stay on the page and reload the current list
            location.reload(); 
        }
    });
}

// --- REAL-TIME GLOBAL SYNC ---
let lastSyncTime = new Date().toISOString().slice(0, 19).replace('T', ' ');

function startHeartbeat(module) {
    setInterval(() => {
        fetch(`../tools/sync_check.php?module=${module}&last_sync=${encodeURIComponent(lastSyncTime)}`)
            .then(res => res.json())
            .then(data => {
                if (data.update_needed) {
                    console.log(`Update detected in ${module}. Refreshing...`);
                    
                    // Option A: Full Reload (Easiest & most reliable)
                    location.reload(); 
                    
                    // Option B: If you want to avoid a blink, you would use 
                    // a fetch call here to update only the table body.
                }
            });
    }, 5000); // Check every 5 seconds
}

// Detect which page we are on and start the specific heartbeat
if (window.location.pathname.includes('events.php')) {
    startHeartbeat('events');
} else if (window.location.pathname.includes('year_view.php')) {
    startHeartbeat('city_records');
} else if (window.location.pathname.includes('manage-accounts.php')) {
    startHeartbeat('users');
}