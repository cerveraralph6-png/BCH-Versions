<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $record_id = $_POST['record_id'];
    $term_id = $_POST['term_id']; // This must match the name in the form
    $input_passkey = $_POST['verify_passkey'];
    $user_id = $_SESSION['user_id'];

    // 1. Verify Passkey
    $stmt = $conn->prepare("SELECT id FROM users WHERE id = ? AND passkey = ?");
    $stmt->bind_param("is", $user_id, $input_passkey);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        die("<script>alert('Error: Invalid Passkey.'); window.history.back();</script>");
    }

    // 2. Prepare all 21 fields for the Update
    $fields = [
        'Date_Received', 'Time_Received', 'Type', 'Proponent', 'Subject', 
        'Subject_Description', 'Subject_Notation', 'Committee_Referred', 
        'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 
        'Com_Rep_Date_Received', 'Com_Rep_Time_Received', 'Item_Nr', 
        'Agenda_Date', 'Action_Taken', 'Indorsement2', 'Indorsement2_Date', 
        'Remarks', 'Folder'
    ];

    $set_clause = [];
    $params = [];
    foreach($fields as $f) {
        $set_clause[] = "$f = ?";
        $val = trim($_POST[$f]);
        $params[] = ($val === "" || $val === "-none-") ? null : $val;
    }
    
    $sql = "UPDATE city_records SET " . implode(', ', $set_clause) . " WHERE id = ?";
    $stmt_update = $conn->prepare($sql);
    
    // Bind 21 strings + 1 ID integer
    $stmt_update->bind_param("sssssssssssssssssssssi", ...array_merge($params, [$record_id]));

    if ($stmt_update->execute()) {
        // SUCCESS: Redirect back to the correct term view using the ID
        header("Location: term_view.php?id=$term_id&success=updated");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
    
    // Add this right after a successful SQL execution
$conn->query("UPDATE system_sync SET last_update = NOW() WHERE module_name = 'city_records'");
}
?>