<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $term_id = $_POST['redirect_id'];
    
    // Capture all 21 fields, using "-none-" if text is empty
    $fields = [
        'Date_Received', 'Time_Received', 'Type', 'Proponent', 'Subject', 
        'Subject_Description', 'Subject_Notation', 'Committee_Referred', 
        'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 
        'Com_Rep_Date_Received', 'Com_Rep_Time_Received', 'Item_Nr', 
        'Agenda_Date', 'Action_Taken', 'Indorsement2', 'Indorsement2_Date', 
        'Remarks', 'Folder'
    ];

    $processed = [];
    $dateIndices = ['Date_Received', 'Date_Indorsed1', 'Com_Rep_Date_Received', 'Agenda_Date', 'Indorsement2_Date'];
    $timeIndices = ['Time_Received', 'Com_Rep_Time_Received'];

    foreach($fields as $f) {
        $val = trim($_POST[$f]);
        if (empty($val)) {
            $processed[] = (in_array($f, $dateIndices) || in_array($f, $timeIndices)) ? null : "-none-";
        } else {
            $processed[] = $val;
        }
    }

    $sql = "INSERT INTO city_records (".implode(',', $fields).") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssssssss", ...$processed);

    if ($stmt->execute()) {
        header("Location: term_view.php?id=$term_id&success=added");
        exit();
    } else {
        die("Error: " . $stmt->error);
    }
    
    // Add this right after a successful SQL execution
$conn->query("UPDATE system_sync SET last_update = NOW() WHERE module_name = 'city_records'");
}
?>