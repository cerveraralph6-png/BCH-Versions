<?php
session_start();
include '../db.php';

// 1. Clear any buffers to prevent file corruption (extra spaces, etc.)
if (ob_get_level()) ob_end_clean();

// 2. Get current filters from URL (Must match year_view.php)
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'Date_Received';
$order  = (isset($_GET['order']) && strtolower($_GET['order']) == 'asc') ? 'ASC' : 'DESC';

// 3. Match the Administrative Term Logic from year_view.php
$start_date = "$selected_year-07-01";
$end_date = ($selected_year + 3) . "-06-30";

// 4. Build the Query
$where_clauses = ["(Date_Received BETWEEN ? AND ?)"];
$params = [$start_date, $end_date];
$types = "ss";

if (!empty($search)) {
    // 5 placeholders for search
    $where_clauses[] = "(Subject LIKE ? OR Proponent LIKE ? OR Folder LIKE ? OR Type LIKE ? OR Remarks LIKE ?)";
    $st = "%$search%";
    $params = array_merge($params, [$st, $st, $st, $st, $st]);
    $types .= "sssss";
}

$where_sql = "WHERE " . implode(" AND ", $where_clauses);
$sql = "SELECT * FROM city_records $where_sql ORDER BY $sort $order";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// 5. Set Download Headers
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="BCH_Archive_Export_'.$selected_year.'.csv"');
header('Pragma: no-cache');
header('Expires: 0');

$output = fopen('php://output', 'w');

// 6. Add UTF-8 BOM for Excel compatibility (Fixes weird symbols)
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// 7. Write the 21 Headers
fputcsv($output, [
    'Date_Received', 'Time_Received', 'Type', 'Proponent', 'Subject', 
    'Subject_Description', 'Subject_Notation', 'Committee_Referred', 
    'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 
    'Com_Rep_Date_Received', 'Com_Rep_Time_Received', 'Item_Nr', 
    'Agenda_Date', 'Action_Taken', 'Indorsement2', 'Indorsement2_Date', 
    'Remarks', 'Folder'
]);

// 8. Write the Data Rows
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, [
            $row['Date_Received'], $row['Time_Received'], $row['Type'], $row['Proponent'], $row['Subject'],
            $row['Subject_Description'], $row['Subject_Notation'], $row['Committee_Referred'], $row['Indorsement1'], $row['Date_Indorsed1'],
            $row['Com_Rep_Nr'], $row['Com_Rep'], $row['Com_Rep_Date_Received'], $row['Com_Rep_Time_Received'], $row['Item_Nr'],
            $row['Agenda_Date'], $row['Action_Taken'], $row['Indorsement2'], $row['Indorsement2_Date'], $row['Remarks'], $row['Folder']
        ]);
    }
}

fclose($output);
exit();
?>