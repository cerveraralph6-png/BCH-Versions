<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["csv_file"])) {
    $redirect_id = isset($_POST['redirect_id']) ? intval($_POST['redirect_id']) : null;
    $file = fopen($_FILES["csv_file"]["tmp_name"], "r");
    fgetcsv($file); // Skip Header

    $sql = "INSERT INTO city_records (
        Date_Received, Time_Received, Type, Proponent, Subject, 
        Subject_Description, Subject_Notation, Committee_Referred, 
        Indorsement1, Date_Indorsed1, Com_Rep_Nr, Com_Rep, 
        Com_Rep_Date_Received, Com_Rep_Time_Received, Item_Nr, 
        Agenda_Date, Action_Taken, Indorsement2, Indorsement2_Date, 
        Remarks, Folder
    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    $stmt = $conn->prepare($sql);

    // Columns that are specifically Dates or Times (Indices 0 to 20)
    $dateIndices = [0, 9, 12, 15, 18];
    $timeIndices = [1, 13];

    while (($row = fgetcsv($file, 10000, ",")) !== FALSE) {
        if (empty(array_filter($row))) continue; // Skip empty rows

        $data = array_pad(array_slice($row, 0, 21), 21, "");
        $processed = [];

        foreach($data as $idx => $val) {
            $val = trim($val);
            if (empty($val)) {
                if (in_array($idx, $dateIndices) || in_array($idx, $timeIndices)) {
                    $processed[] = null;
                } else {
                    $processed[] = "-none-";
                }
            } else {
                // If it's a date, ensure MySQL format
                if (in_array($idx, $dateIndices)) {
                    $ts = strtotime($val);
                    $processed[] = $ts ? date('Y-m-d', $ts) : null;
                } else {
                    $processed[] = $val;
                }
            }
        }

        $stmt->bind_param("sssssssssssssssssssss", ...$processed);
        $stmt->execute();
    }
    
    fclose($file);
    $url = $redirect_id ? "term_view.php?id=$redirect_id&success=1" : "table.php?success=1";
    header("Location: $url");
    exit();
}