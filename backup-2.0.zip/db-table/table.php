<?php
session_start();
include_once '../auth_check.php';
include '../db.php';

// Fetch the administrative terms
$terms_result = $conn->query("SELECT * FROM archive_terms ORDER BY start_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>BCH | Term Archives</title>
</head>
<body>
    <nav>
        <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
        <h1>Baguio City Database</h1>
        <div class="nav-actions">
            <button id="Dashboard" onclick="window.location.href='/admin/admin.php'">Home</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main>
        <div id="container1">
            <div class="table-header">
                <h1>Administrative Term Archives</h1>
                <button id="add" onclick="document.getElementById('modal-add-term').showModal()">+ Add New Term</button>
            </div>

            <div class="year-grid">
                <?php while($term = $terms_result->fetch_assoc()): ?>
                    <a href="term_view.php?id=<?php echo $term['id']; ?>" class="year-card-link">
                        <div class="year-card">
                            <div class="year-icon">🏛️</div>
                            <h2 style="font-size: 1.1rem;"><?php echo $term['term_label']; ?></h2>
                            <p>Records Collection</p>
                            <span class="view-btn">Open Records →</span>
                        </div>
                    </a>
                <?php endwhile; ?>
            </div>
        </div>
    </main>

    <!-- Modal to add a new custom term range -->
<dialog id="modal-add-term">
    <!-- Action must match the filename we just created -->
    <form action="add_term_logic.php" method="POST">
        <h2>Add New Term Range</h2>
        
        <label>Term Label</label>
        <input type="text" name="label" placeholder="e.g. 01 July 2028 - 30 June 2031" required>
        
        <label>Start Date</label>
        <input type="date" name="start" required>
        
        <label>End Date</label>
        <input type="date" name="end" required>

        <div class="modal-actions">
            <button type="submit" class="btn-save">Save Term</button>
            <button type="button" class="btn-cancel" onclick="document.getElementById('modal-add-term').close()">Cancel</button>
        </div>
    </form>
</dialog>
    <script src="../scripts/main.js"></script>
</body>
</html>