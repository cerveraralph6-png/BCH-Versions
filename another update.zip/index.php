<?php
session_start();
if (isset($_SESSION['role'])) {
    $redirect = ($_SESSION['role'] == 'admin') ? 'admin/admin.php' : 'user/user.php';
    header("Location: $redirect");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <link rel="icon" href="../Imag3s/baguio-logo-gov.png" type="image/png">
    <link rel="stylesheet" href="CSS/index.css?v=<?php echo filemtime('CSS/index.css'); ?>">
    <title>Baguio City Hall | Ordinance Tracker</title>
    
    <style>
        /* --- UNIFIED COMMAND CONSOLE --- */
.search-console {
    display: flex;
    align-items: stretch;
    background: #fff;
    border: 2px solid #3b82f6;
    border-radius: 16px;
    padding: 6px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 4px 20px rgba(59, 130, 246, 0.1);
}

.console-section { display: flex; align-items: center; }

/* Filters Section */
.console-section.filters { background: var(--bg-light); border-radius: 10px; padding: 0 5px; }
.console-input { border: none !important; background: transparent !important; height: 42px; width: 100vh; padding: 0 10px; font-size: 0.85rem; font-weight: 700; color: var(--text-dark); cursor: pointer; outline: none; }
.console-divider { width: 1px; height: 20px; background: #cbd5e1; margin: 0 5px; }

/* Search Main Section */
.console-section.search-main { position: relative; flex: 1; }
.console-icon { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); opacity: 0.4; pointer-events: none; }
.console-section.search-main input { width: 100%; border: none !important; background: transparent !important; padding: 0 15px 0 50px !important; height: 48px; font-size: 1rem; outline: none; }

/* Actions Section */
.console-section.actions { gap: 8px; padding-left: 10px; }
.btn-search-primary { background: #0f172a; color: #fff; border: none; padding: 0 25px; height: 42px; border-radius: 10px; font-weight: 800; cursor: pointer; transition: 0.2s; }
.btn-search-clear { background: #f1f5f9; color: var(--text-muted); border: 1px solid var(--border-color); padding: 0 15px; height: 42px; border-radius: 10px; font-weight: 700; cursor: pointer; }

/* --- RESPONSIVE FIXES --- */
@media (max-width: 900px) {
    .search-console { flex-direction: column; background: transparent; border: none; box-shadow: none; padding: 0; gap: 10px; }
    .console-section.filters, .console-section.search-main { 
        width: 100%; background: #fff; border: 2px solid #3b82f6; border-radius: 12px; padding: 5px; 
    }
    .console-section.actions { width: 100%; padding: 0; display: grid; grid-template-columns: 2fr 1fr; gap: 8px; }
    .btn-search-primary, .btn-search-clear { height: 55px; }
    .console-input { flex: 1; text-align: center; }
}

/* --- RESULT BOX BORDER ACCENTS --- */
.status-approved-border { border-left: 6px solid var(--success) !important; }
.status-pending-border { border-left: 6px solid var(--warning) !important; }
.status-disapproved-border { border-left: 6px solid var(--danger) !important; }
    </style>
    
    <script>
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () { window.history.go(1); };
    </script>
</head>
<body class="public-bg">

    <!-- Page Loader -->
    <div id="page-loader">
        <div class="loader-wrapper">
            <img src="Imag3s/baguio-logo-gov.png" alt="BCH" class="loader-logo">
            <div class="loader-circle"></div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="public-nav">
        <div class="nav-brand">
            <img src="Imag3s/baguio-logo-gov.png" alt="Logo">
            <div class="brand-text">
                <h1>Baguio City hall</h1>
                <span>Sangguniang Panlungsod Portal</span>
            </div>
        </div>
        <button class="btn-login-trigger" onclick="document.getElementById('modal-login').showModal()">
            Administrative Login
        </button>
    </nav>

<!-- Update this part inside index.php -->
<main class="public-main">
    <div class="search-card fade-in">
<header class="card-header">
    <img src="Imag3s/baguio-logo-gov.png" alt="City Seal">
    <h1>Track My Ordinance</h1>
    <p>
        Search by <strong>Ordinance Title</strong>, <strong>Final Number</strong>, 
        or <strong>Proponent Name</strong> (e.g., Hon. Faustino Olowan).
    </p>
</header>

<div class="search-engine">
    
            <!-- Group 1: The Filters -->
        <div class="console-section filters">
            <select id="public-filter-by" class="console-input">
                <option value="Subject">Keywords</option>
                <option value="Ref_No">Ordinance No.</option>
                <option value="Proponent">Proponent Name</option>
            </select>
            <div class="console-divider"></div>
            <select id="public-status-filter" class="console-input">
                <option value="All">All Status</option>
                <option value="Approved">Approved</option>
                <option value="Pending">Pending</option>
                <option value="Rejected">Rejected</option>
            </select>
        </div>
    <div class="search-console">


        <!-- Group 2: The Input Area -->
        <div class="console-section search-main">
            <span class="console-icon">🔍</span>
            <input type="text" id="public-search-query" placeholder="Type here to search city records..." onkeyup="if(event.key === 'Enter') trackOrdinance()">
        </div>

        <!-- Group 3: The Actions -->
        <div class="console-section actions">
            <button class="btn-search-primary" onclick="trackOrdinance()">Search</button>
            <button class="btn-search-clear" onclick="clearTrackSearch()">Clear</button>
        </div>
    </div>
</div>

        <div id="ordinance-result-container"></div>
    </div>
</main>

    <!-- Modal: Administrative Login -->
    <dialog id="modal-login" class="login-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="document.getElementById('modal-login').close()">&times;</button>
            <div class="modal-header">
                <h2>Administrative Access</h2>
                <p>Authorized Personnel Only</p>
            </div>
            
            <form id="login-form" method="POST">
                <div class="input-box">
                    <label for="passkey">System Passkey</label>
                    <input type="password" name="passkey" id="passkey" placeholder="••••••••" required>
                </div>
                <div id="error-msg"></div>
                <button type="submit" class="btn-submit-login">Enter Dashboard</button>
            </form>

            <div class="forgot-link">
                <a href="#" onclick="forgotPassword()">Request Passkey Recovery</a>
            </div>
        </div>
    </dialog>

    <!-- Modal: Password Recovery -->
    <dialog id="modal-forgot" class="recovery-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="closeForgotModal()">&times;</button>
            <h2>Identity Verification</h2>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:20px;">Provide your Employee ID Number to verify your identity.</p>
            
            <div class="input-box">
                <label>Employee ID</label>
                <input type="text" id="verify-id" placeholder="Ex: 2024-001" required>
            </div>
            
            <div id="result-display"></div>
            
            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeForgotModal()">Cancel</button>
                <button type="button" class="btn-save" onclick="verifyAndReveal()">Verify</button>
            </div>
        </div>
    </dialog>

    <script src="scripts/main.js"></script>
</body>
</html>