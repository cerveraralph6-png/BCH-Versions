<?php
include_once '../auth_check.php';
include '../db.php';

$me = $_SESSION['user_id'];
$with = isset($_GET['with']) ? (int)$_GET['with'] : 0;

// --- CLEAR NOTIFICATIONS ON PAGE LOAD ---
if ($with > 0) {
    $conn->query("UPDATE messages SET is_read = 1 WHERE sender_id = $with AND receiver_id = $me");
}
?>
<!-- rest of the file remains the same... -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>SP Messenger</title>
    <style>
        .msg-grid { display: grid; grid-template-columns: 300px 1fr; height: calc(100vh - 180px); background: white; border-radius: 15px; border: 1px solid #e2e8f0; overflow: hidden; }
        .user-list { border-right: 1px solid #e2e8f0; overflow-y: auto; background: #f8fafc; }
        .user-item { padding: 15px; border-bottom: 1px solid #e2e8f0; cursor: pointer; display: flex; justify-content: space-between; align-items: center; transition: 0.2s; }
        .user-item:hover { background: #f1f5f9; }
        .user-item.active { background: #eff6ff; border-left: 4px solid #2563eb; }
        .msg-pane { display: flex; flex-direction: column; height: 100%; }
        .chat-header { padding: 15px 25px; border-bottom: 1px solid #e2e8f0; font-weight: 800; background: #fff; }
        .msg-history { flex: 1; padding: 20px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; background: #fff; scroll-behavior: smooth; }
        .bubble { padding: 10px 15px; border-radius: 15px; max-width: 75%; font-size: 0.95rem; line-height: 1.4; word-wrap: break-word; }
        .sent { align-self: flex-end; background: #2563eb; color: white; border-bottom-right-radius: 2px; }
        .received { align-self: flex-start; background: #f1f5f9; color: #1e293b; border-bottom-left-radius: 2px; }
        .msg-form { padding: 20px; border-top: 1px solid #e2e8f0; display: flex; gap: 10px; background: #f8fafc; }
        .msg-form input { flex: 1; padding: 12px; border-radius: 10px; border: 1px solid #e2e8f0; outline: none; background: white; }
        @media (max-width: 768px) { .msg-grid { grid-template-columns: 1fr; height: 75vh; } .user-list { <?php echo $with > 0 ? 'display:none;' : ''; ?> } .msg-pane { <?php echo $with > 0 ? '' : 'display:none;'; ?> } }
    </style>
</head>
<body class="table-page-bg">
    <nav class="table-nav" style="background: white; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; padding: 10px 40px; position: fixed; top: 0; width: 100%; z-index: 1000; height: 70px;">
        <div style="display: flex; align-items: center; gap: 15px;">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo" style="height: 40px;">
            <div>
                <h1 style="font-size: 1rem; font-weight: 800; color: #0f172a; line-height: 1;">Sangguniang Panlungsod</h1>
                <span style="font-size: 0.7rem; font-weight: 600; color: #64748b; text-transform: uppercase;">City Council (Baguio City)</span>
            </div>
        </div>
        <div class="nav-actions">
            <?php $homePath = ($_SESSION['role'] === 'admin') ? '/admin/admin.php' : '/user/user.php'; ?>
            <button id="Dashboard" class="btn-home" onclick="window.location.href='<?php echo $homePath; ?>'" style="padding: 8px 16px; border-radius: 8px; font-weight: 700; border: 1px solid #e2e8f0; cursor: pointer; background: white;">Home</button>
            <button class="btn-nav logout" onclick="window.location.href='../logout.php'" style="padding: 8px 16px; border-radius: 8px; font-weight: 700; color: #ef4444; border: 1px solid #fecaca; background: white; cursor: pointer;">Logout</button>
        </div>
    </nav>

    <main style="margin-top: -10px; padding: 5px;">
        <div class="table-header">
            <button class="btn-nav" onclick="window.location.href='<?php echo $homePath; ?>'">← Back</button>
            <h1>Messenger</h1>
        </div>

        <div class="msg-grid">
            <div class="user-list" id="user-sidebar">
                <?php
                $users = $conn->query("SELECT id, full_name, (SELECT COUNT(*) FROM messages WHERE sender_id = users.id AND receiver_id = $me AND is_read = 0) as unread FROM users WHERE id != $me AND status='active'");
                while($u = $users->fetch_assoc()):
                ?>
                    <div class="user-item <?php echo ($with == $u['id']) ? 'active' : ''; ?>" onclick="window.location.href='?with=<?php echo $u['id']; ?>'">
                        <span>👤 <?php echo $u['full_name']; ?></span>
                        <?php if($u['unread'] > 0): ?><span class="badge" style="background:#ef4444; color:white; padding: 2px 8px; border-radius: 10px; font-size: 0.7rem;"><?php echo $u['unread']; ?></span><?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>

<div class="msg-pane">
                <?php if($with > 0): 
                    $other = $conn->query("SELECT full_name FROM users WHERE id = $with")->fetch_assoc();
                ?>
                    <div class="chat-header">Conversation with <?php echo $other['full_name']; ?></div>
                    
                    <div class="msg-history" id="history">
                        <!-- NEW: Initial Load via PHP so it's never empty -->
                        <?php
                        $msgs = $conn->query("SELECT * FROM messages WHERE (sender_id=$me AND receiver_id=$with) OR (sender_id=$with AND receiver_id=$me) ORDER BY sent_at ASC");
                        while($m = $msgs->fetch_assoc()):
                            $class = ($m['sender_id'] == $me) ? 'sent' : 'received';
                        ?>
                            <div class="bubble <?php echo $class; ?>"><?php echo htmlspecialchars($m['message_text']); ?></div>
                        <?php endwhile; ?>
                    </div>

                    <form action="msg_logic.php" method="POST" class="msg-form" target="hidden_post_frame" onsubmit="clearInput()">
                        <input type="hidden" name="to_id" value="<?php echo $with; ?>">
                        <input type="text" name="message" id="msg-input" placeholder="Type your message..." required autocomplete="off">
                        <button type="submit" class="btn-save" style="background: #2563eb; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 700; cursor: pointer;">Send</button>
                    </form>
                <?php else: ?>
                    <div style="margin:auto; text-align:center; color:#94a3b8;">
                        <span style="font-size:4rem;">💬</span>
                        <p>Select a staff member to start messaging.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <iframe name="hidden_post_frame" style="display:none;"></iframe>
    <?php if($with > 0): ?>
        <iframe src="chat_view.php?with=<?php echo $with; ?>" style="display:none;" id="chat-data-frame"></iframe>
    <?php endif; ?>

    <script>
        const historyBox = document.getElementById('history');

        // Scroll to bottom immediately on load
        if(historyBox) historyBox.scrollTop = historyBox.scrollHeight;

        function clearInput() {
            // Give it 50ms to ensure the form finishes sending to the iframe
            setTimeout(() => { 
                document.getElementById('msg-input').value = ''; 
                document.getElementById('msg-input').focus();
            }, 50);
        }

        // This function is triggered by chat_view.php
        function syncDisplay(html) {
            if(!historyBox) return;
            
            // Only update if there is new content to prevent jumping
            if(historyBox.innerHTML.trim() !== html.trim()) {
                historyBox.innerHTML = html;
                historyBox.scrollTop = historyBox.scrollHeight;
            }
        }
    </script>
</body>
</html>