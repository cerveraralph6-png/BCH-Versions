<?php
session_start();
include '../db.php';
$me = $_SESSION['user_id'];
$with = (int)$_GET['with'];

if(!$me || $with <= 0) exit;

// --- CLEAR NOTIFICATIONS IN REAL-TIME ---
// As long as this hidden iframe is running, new messages are marked as "seen"
$conn->query("UPDATE messages SET is_read = 1 WHERE sender_id = $with AND receiver_id = $me");

// ... then continue to fetch messages ...
$msgs = $conn->query("SELECT * FROM messages WHERE (sender_id=$me AND receiver_id=$with) OR (sender_id=$with AND receiver_id=$me) ORDER BY sent_at ASC");
// ... rest of the file ...
$html = '';
while($m = $msgs->fetch_assoc()) {
    $class = ($m['sender_id'] == $me) ? 'sent' : 'received';
    $text = htmlspecialchars($m['message_text']);
    $html .= "<div class='bubble $class'>$text</div>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <!-- Refresh every 8 seconds -->
    <meta http-equiv="refresh" content="8">
</head>
<body onload="if(parent && parent.syncDisplay) parent.syncDisplay(document.getElementById('data').innerHTML)">
    <div id="data">
        <?php echo $html; ?>
    </div>
</body>
</html>