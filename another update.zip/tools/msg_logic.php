<?php
session_start();
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $from = $_SESSION['user_id'];
    $to = (int)$_POST['to_id'];
    $msg = trim($_POST['message']);

    if (!empty($msg) && $to > 0) {
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message_text) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $from, $to, $msg);
        $stmt->execute();
        $stmt->close();
    }
}
?>
// ... after your INSERT query in msg_logic.php ...
?>
<script>
    // Refresh the iframe in the parent window
    if(window.parent.document.getElementById('chat-data-frame')) {
        window.parent.document.getElementById('chat-data-frame').src += '';
    }
</script>