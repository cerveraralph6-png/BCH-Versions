<?php
session_start();
if (isset($_SESSION['role'])) {
    $redirect = ($_SESSION['role'] == 'admin') ? 'admin/admin.php' : 'user/user.php';
    header("Location: $redirect");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <link rel="icon" href="../Imag3s/baguio-logo-gov.png" type="image/png">
    <link rel="stylesheet" href="CSS/index.css?v=<?php echo filemtime('CSS/index.css'); ?>">
    <title>Baguio City Hall | Ordinance Tracker</title>

    <script>
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () { window.history.go(1); };
    </script>
</head>
<body class="public-bg">

    <!-- Page Loader -->
    <div id="page-loader">
        <div class="loader-wrapper">
            <img src="Imag3s/baguio-logo-gov.png" alt="BCH" class="loader-logo">
            <div class="loader-circle"></div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="public-nav">
        <div class="nav-brand">
            <img src="Imag3s/baguio-logo-gov.png" alt="Logo">
            <div class="brand-text">
                <h1>Baguio City hall</h1>
                <span>Sangguniang Panlungsod Portal</span>
            </div>
        </div>
        <button class="btn-login-trigger" onclick="document.getElementById('modal-login').showModal()">
            Administrative Login
        </button>
    </nav>

<!-- Update this part inside index.php -->
<main class="public-main">
    <div class="search-card fade-in">
<header class="card-header">
    <img src="Imag3s/baguio-logo-gov.png" alt="City Seal">
    <h1>Track My Ordinance</h1>
    <p>
        Search by <strong>Ordinance Title</strong>, <strong>Final Number</strong>, 
        or <strong>Proponent Name</strong> (e.g., Hon. Faustino Olowan).
    </p>
</header>

<div class="search-engine">
    
            <!-- Group 1: The Filters -->
<!-- Locate the console-section filters in index.php and update it to this -->
<div class="console-section filters">
    <select id="public-filter-by" class="console-input">
        <option value="Subject">Keywords</option>
        <option value="Ref_No">Ordinance No.</option>
        <option value="Proponent">Proponent Name</option>
    </select>
    <div class="console-divider"></div>
    <select id="public-status-filter" class="console-input">
        <option value="All">All Status</option>
        <option value="Approved">Approved</option>
        <option value="Pending">Pending</option>
        <option value="Rejected">Rejected</option>
    </select>
    <!-- NEW: Proponent Type Filter -->
    <div class="console-divider"></div>
    <select id="public-proponent-type" class="console-input">
        <option value="All">Any Proponent</option>
        <option value="Single">Single Proponent</option>
        <option value="Multiple">Multiple Proponents</option>
    </select>
</div>
    <div class="search-console">


        <!-- Group 2: The Input Area -->
        <div class="console-section search-main">
            <span class="console-icon">🔍</span>
            <input type="text" id="public-search-query" placeholder="Type here to search city records..." onkeyup="if(event.key === 'Enter') trackOrdinance()">
        </div>

        <!-- Group 3: The Actions -->
        <div class="console-section actions">
            <button class="btn-search-primary" onclick="trackOrdinance()">Search</button>
            <button class="btn-search-clear" onclick="clearTrackSearch()">Clear</button>
        </div>
    </div>
</div>

        <div id="ordinance-result-container"></div>
    </div>
</main>

    <!-- Modal: Administrative Login -->
    <dialog id="modal-login" class="login-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="document.getElementById('modal-login').close()">&times;</button>
            <div class="modal-header">
                <h2>Administrative Access</h2>
                <p>Authorized Personnel Only</p>
            </div>
            
            <form id="login-form" method="POST">
                <div class="input-box">
                    <label for="passkey">System Passkey</label>
                    <input type="password" name="passkey" id="passkey" placeholder="••••••••" required>
                </div>
                <div id="error-msg"></div>
                <button type="submit" class="btn-submit-login">Enter Dashboard</button>
            </form>

            <div class="forgot-link">
                <a href="#" onclick="forgotPassword()">Request Passkey Recovery</a>
            </div>
        </div>
    </dialog>

    <!-- Modal: Password Recovery -->
    <dialog id="modal-forgot" class="recovery-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="closeForgotModal()">&times;</button>
            <h2>Identity Verification</h2>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:20px;">Provide your Employee ID Number to verify your identity.</p>
            
            <div class="input-box">
                <label>Employee ID</label>
                <input type="text" id="verify-id" placeholder="Ex: 2024-001" required>
            </div>
            
            <div id="result-display"></div>
            
            <div class="modal-actions">
                <button type="button" class="btn-save" onclick="verifyAndReveal()">Verify</button>
            </div>
        </div>
    </dialog>

    <button id="btn-back-to-top" title="Go to top">↑</button>

    <script src="scripts/main.js"></script>
</body>
</html>