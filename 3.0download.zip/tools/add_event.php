<?php
// Use the centralized security check to allow both Admin and User roles
include_once '../auth_check.php';
include '../db.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['event_name'];
    $category = $_POST['category']; 
    $date = $_POST['event_date'];
    $time = $_POST['event_time'];
    $location = $_POST['location'];
    $desc = $_POST['description'];

    // SQL remains functional
    $stmt = $conn->prepare("INSERT INTO events (event_name, category, event_date, event_time, location, description) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $category, $date, $time, $location, $desc);

    if ($stmt->execute()) {
        // Redirect back to events.php with category preserved
        header("Location: events.php?cat=" . urlencode($category) . "&success=1");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
    
$conn->query("UPDATE system_sync SET last_update = CURRENT_TIMESTAMP WHERE module_name = 'events'");

    $stmt->close();
    $conn->close();
}
?>