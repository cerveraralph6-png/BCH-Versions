document.addEventListener('DOMContentLoaded', () => {
    console.log("BCH System Active...");

    // --- 1. AJAX LOGIN ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const errorDiv = document.getElementById('error-msg');
            const formData = new FormData(this);
            fetch('login_process.php', { method: 'POST', body: formData })
            .then(res => res.json()).then(data => {
                if (data.status === 'success') { window.location.href = data.redirect; } 
                else { errorDiv.innerText = data.message || "Invalid Passkey!"; }
            }).catch(err => console.error("Login Error:", err));
        });
    }

    // --- 2. GLOBAL NAV ---
    const dashboardBtn = document.getElementById("Dashboard");
    if (dashboardBtn) { 
        dashboardBtn.addEventListener("click", () => { 
            window.location.href = "/admin/admin.php"; 
        }); 
    }

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) { logoutBtn.addEventListener('click', () => { window.location.href = '/logout.php'; }); }

    // --- 3. CSV UPLOAD LOADER ---
    const importForm = document.querySelector('#modal-import form');
    if (importForm) {
        importForm.addEventListener('submit', () => { document.getElementById('upload-loader').style.display = 'flex'; });
    }

    // --- 4. SELECTIVE DOWNLOAD ---
    const selectAll = document.getElementById('select-all-rows');
    const exportBtn = document.getElementById('btn-export-selected');
    const countDisplay = document.getElementById('selected-count');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.record-checkbox').forEach(cb => cb.checked = this.checked);
            updateExportButtonState();
        });
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('record-checkbox')) updateExportButtonState();
        });
        function updateExportButtonState() {
            const checkedCount = document.querySelectorAll('.record-checkbox:checked').length;
            if(countDisplay) countDisplay.innerText = checkedCount;
            if (exportBtn) {
                exportBtn.style.setProperty('opacity', checkedCount > 0 ? '1' : '0.5', 'important');
                exportBtn.style.setProperty('pointer-events', checkedCount > 0 ? 'auto' : 'none', 'important');
            }
        }
    }
});

// --- GLOBAL POPUP FUNCTIONS ---

let currentRecordIndex = -1;
let allPageRecords = [];
let currentRecordData = null;

function openDetailByIndex(index) {
    const stores = document.querySelectorAll('.json-store');
    allPageRecords = Array.from(stores).map(s => JSON.parse(s.innerText));
    currentRecordIndex = index;
    const modal = document.getElementById('modal-view-details');
    if (modal) { updateModalContent(allPageRecords[index]); modal.showModal(); }
}

function navRecord(step) {
    let nextIdx = currentRecordIndex + step;
    if (nextIdx >= 0 && nextIdx < allPageRecords.length) {
        currentRecordIndex = nextIdx;
        const editBtn = document.getElementById('btn-enable-edit');
        const saveBtn = document.getElementById('btn-trigger-verify');
        if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
        if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
        updateModalContent(allPageRecords[currentRecordIndex]);
    } else {
        alert(step > 0 ? "Last record." : "First record.");
    }
}

function updateModalContent(data) {
    currentRecordData = data;
    const title = document.getElementById('view-subject-title');
    if(title) title.innerText = data.Subject || "Details";
    const idField = document.getElementById('view-record-id');
    if(idField) idField.value = data.id;
    renderDetails(false); 
}

function renderDetails(isEditMode) {
    const content = document.getElementById('details-content');
    const data = currentRecordData;

    const fields = {
        "Date_Received": "Date Received", "Time_Received": "Time Received", "Ref_No": "Ref No.", 
        "Type": "Type", "Proponent": "Proponent", "Subject": "Subject", 
        "Subject_Description": "Description", "Subject_Notation": "Notation", 
        "Committee_Referred": "Committee Referred", "Indorsement1": "Indorsement 1", 
        "Date_Indorsed1": "Date Indorsed 1", "Com_Rep_Nr": "Com Rep Nr", 
        "Com_Rep": "Com Rep", "Com_Rep_Date_Received": "Date Rec (Rep)", 
        "Item_Nr": "Item Nr", "Agenda_Date": "Agenda Date", 
        "Action_Taken": "Action Taken", "Indorsement2": "Indorsement 2", 
        "Indorsement2_Date": "Date Ind 2", "Remarks": "Remarks", "Folder": "Folder"
    };

    let html = '';
    for (const [key, label] of Object.entries(fields)) {
        let value = data[key] || "";
        const isLong = label.includes("Description") || label.includes("Indorsement") || label.includes("Report") || label.includes("Action") || label.includes("Remarks") || label.includes("Notation") || label.includes("Committee") || label === "Subject" || label === "Proponent";
        const containerClass = isLong ? "detail-item full-width" : "detail-item";

        if (isEditMode) {
            let inputField = isLong ? `<textarea name="${key}" rows="2">${value}</textarea>` : `<input type="text" name="${key}" value="${value}">`;
            if(key.includes('Date')) inputField = `<input type="date" name="${key}" value="${value}">`;
            if(key.includes('Time')) inputField = `<input type="time" name="${key}" value="${value}">`;
            html += `<div class="${containerClass}"><label class="detail-label">${label}</label>${inputField}</div>`;
        } else {
            const displayVal = (value === "" || value === "-none-" || value === null || value === "0000-00-00") ? '<span class="none-text">-none-</span>' : value;
            html += `<div class="${containerClass}"><label class="detail-label">${label}</label><div class="detail-value">${displayVal}</div></div>`;
        }
    }
    content.innerHTML = html;
}

function enableEditMode() {
    renderDetails(true);
    const label = document.getElementById('modal-mode-label');
    if(label) { label.innerText = "⚠️ EDITING MODE"; label.style.color = "#ef4444"; }
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if (editBtn) editBtn.style.setProperty('display', 'none', 'important');
    if (saveBtn) saveBtn.style.setProperty('display', 'inline-flex', 'important');
}

function openVerifyModal() { document.getElementById('modal-verify-passkey').showModal(); }

function submitEditWithPasskey() {
    const passInput = document.getElementById('popup-passkey-input');
    if (!passInput.value) { alert("Enter passkey."); return; }
    document.getElementById('hidden-passkey').value = passInput.value;
    document.getElementById('edit-detail-form').submit();
}

function closeDetailModal() {
    document.getElementById('modal-view-details').close();
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
    if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
}

function exportSelectedRecords() {
    const ids = Array.from(document.querySelectorAll('.record-checkbox:checked')).map(cb => cb.value);
    if (ids.length > 0) window.location.href = `export_selected_csv.php?ids=${ids.join(',')}`;
}