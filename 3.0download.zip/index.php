<?php
session_start();
// If user is already logged in, don't show the login form, redirect to dashboard
if (isset($_SESSION['role'])) {
    $redirect = ($_SESSION['role'] == 'admin') ? 'admin/admin.php' : 'user/user.php';
    header("Location: $redirect");
    exit();
}
?>
<!-- Your HTML code follows... -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/index.css"> <!-- Removed leading / to ensure path works -->
    <title>Baguio City Hall Database</title>
    
    <script>
        // --- PREVENT BACK BUTTON AFTER LOGOUT ---
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () {
            window.history.go(1);
        };
    </script>
</head>
<body>

    <main>
        <div id="container1">
            <div id="img-logo-title">
                <img src="Imag3s/baguio-logo-gov.png" alt="Baguio City Hall">
                <h1>Sangguniang Panlungsod</h1>
            </div>
            
            <form id="login-form" method="POST">
                <div class="input-box">
                    <label for="passkey">Passkey</label>
                    <input type="password" name="passkey" id="passkey" placeholder="••••••••" required>
                </div>
                <div id="error-msg" style="color: red; font-size: 0.8rem; margin: 5px 0; height: 1rem;"></div>
                <button type="submit">Login</button>
            </form>

            <div class="forgot-link">
                <a href="#" onclick="forgotPassword()">Forgot your password?</a>
            </div>
        </div>
    </main>

    <dialog id="modal-forgot">
        <form method="dialog" id="forgot-form">
            <h2>Retrieve Passkey</h2>
            <input type="text" id="verify-id" placeholder="Enter Employee ID" required>
            <div id="result-display"></div>
            <div class="modal-actions">
                <button type="button" onclick="closeForgotModal()">Close</button>
                <button type="button" onclick="verifyAndReveal()">Verify</button>
            </div>
        </form>
    </dialog>

    <script src="scripts/main.js"></script>
</body>
</html>