<?php
session_start();
include_once '../auth_check.php';
include '../db.php';

// Logic remains identical to your original code...
$conn->set_charset("utf8mb4");
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
date_default_timezone_set('Asia/Manila');

$limit = 50; 
$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort   = isset($_GET['sort']) ? $_GET['sort'] : 'Date_Received';
$order  = (isset($_GET['order']) && strtolower($_GET['order']) == 'asc') ? 'ASC' : 'DESC';
$date_from = isset($_GET['df']) ? $_GET['df'] : '';
$date_to   = isset($_GET['dt']) ? $_GET['dt'] : '';

$where_clauses = ["1=1"];
$params = [];
$types = "";

if (!empty($date_from) && !empty($date_to)) {
    $where_clauses[] = "(Date_Received BETWEEN ? AND ?)";
    $params[] = $date_from; $params[] = $date_to; $types .= "ss";
}
if (!empty($search)) {
    $where_clauses[] = "(Subject LIKE ? OR Proponent LIKE ? OR Folder LIKE ? OR Ref_No LIKE ? OR Item_Nr LIKE ? OR Subject_Description LIKE ?)";
    $st = "%$search%";
    for($i=0; $i<6; $i++){ $params[] = $st; $types .= "s"; }
}
$where_sql = "WHERE " . implode(" AND ", $where_clauses);

$count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM city_records $where_sql");
if(!empty($types)) { $count_stmt->bind_param($types, ...$params); }
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

$gen_res = $conn->query("SELECT COUNT(*) as total FROM city_records");
$general_total = $gen_res->fetch_assoc()['total'];

$allowed_cols = ['Date_Received', 'Ref_No', 'Type', 'Proponent', 'Subject', 'Folder'];
if (!in_array($sort, $allowed_cols)) { $sort = 'Date_Received'; }

$stmt_records = $conn->prepare("SELECT * FROM city_records $where_sql ORDER BY $sort $order LIMIT ? OFFSET ?");
$data_types = $types . "ii";
$data_params = array_merge($params, [$limit, $offset]);
$stmt_records->bind_param($data_types, ...$data_params);
$stmt_records->execute();
$records_result = $stmt_records->get_result();

function safeJson($data) {
    foreach ($data as $key => $val) { if (is_string($val)) $data[$key] = mb_convert_encoding($val, 'UTF-8', 'UTF-8'); }
    return htmlspecialchars(json_encode($data, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP), ENT_QUOTES, 'UTF-8');
}
function shorten($t, $l = 30) {
    $t = trim($t);
    if (empty($t) || $t === "-none-") return "<span class='none-text'>-none-</span>";
    return (mb_strlen($t) > $l) ? htmlspecialchars(mb_substr($t, 0, $l)) . "..." : htmlspecialchars($t);
}
function cleanDisplay($v) { $v = trim($v); return (empty($v) || $v === "-none-" || $v == "0000-00-00") ? "<span class='none-text'>-none-</span>" : htmlspecialchars($v); }
function formatTableDate($d) { if (empty($d) || $d == '0000-00-00') return "<span class='none-text'>-none-</span>"; return date('M d, Y', strtotime($d)); }
function getSortURL($col, $currSort, $currOrder, $search, $df, $dt) {
    $newOrder = ($col == $currSort && $currOrder == 'DESC') ? 'asc' : 'desc';
    return "?sort=$col&order=$newOrder&search=".urlencode($search)."&df=$df&dt=$dt";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <link rel="icon" href="../Imag3s/baguio-logo-gov.png" type="image/png">
    <link rel="stylesheet" href="../CSS/table.css">
    <title>BCH | Administrative Records</title>
</head>
<body class="table-page-bg">
    <nav class="table-nav">
        <div class="nav-left">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo">
            <div class="nav-text">
                <h1>Baguio City Hall</h1>
                <span>Administrative Database</span>
            </div>
        </div>
        <div class="nav-actions">
            <button class="btn-nav-outline" onclick="window.location.href='../admin/admin.php'">🏠 Dashboard</button>
            <button class="btn-nav-outline logout" id="logout">Logout</button>
        </div>
    </nav>

    <main class="table-main-content">
        <div class="registry-card">
            <div class="registry-header">
                <div class="header-titles">
                    <h2>Record Registry</h2>
                    <div class="stats-badges">
                        <span class="stat-badge">Total: <?php echo number_format($general_total); ?></span>
                        <span class="stat-badge filtered">Filtered: <?php echo number_format($total_rows); ?></span>
                    </div>
                </div>
                <div class="header-actions">
                    <a href="download_template.php" class="btn-action-gray">Template</a>
                    <button id="btn-export-selected" class="btn-action-gray disabled" onclick="exportSelectedRecords()">Export Selected (<span id="selected-count">0</span>)</button>
                    <button class="btn-add-record" onclick="document.getElementById('modal-add-manual').showModal()">+ New Record</button>
                    <button class="btn-import-csv" onclick="document.getElementById('modal-import').showModal()">Import CSV</button>
                </div>
            </div>

            <form method="GET" class="filter-toolbar" id="filterForm">
                <div class="search-box">
                    <span class="search-icon">🔍</span>
                    <input type="text" name="search" placeholder="Search Subject, Proponent, Folder..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="filter-controls">
                    <div class="date-range-group">
                        <label>From</label>
                        <input type="date" name="df" value="<?php echo $date_from; ?>">
                        <label>To</label>
                        <input type="date" name="dt" value="<?php echo $date_to; ?>">
                    </div>
                    <select name="order" onchange="this.form.submit()" class="order-dropdown">
                        <option value="desc" <?php echo $order == 'DESC' ? 'selected' : ''; ?>>Newest First</option>
                        <option value="asc" <?php echo $order == 'ASC' ? 'selected' : ''; ?>>Oldest First</option>
                    </select>
                    <button type="submit" class="btn-apply-filter">Apply Filters</button>
                </div>
            </form>

            <div class="table-viewport">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 50px; text-align: center;"><input type="checkbox" id="select-all-rows"></th>
                            <th style="width: 130px;"><a href="<?php echo getSortURL('Date_Received', $sort, $order, $search, $date_from, $date_to); ?>">Date Rec.</a></th>
                            <th style="width: 120px;"><a href="<?php echo getSortURL('Ref_No', $sort, $order, $search, $date_from, $date_to); ?>">Ref No.</a></th>
                            <th style="width: 140px;"><a href="<?php echo getSortURL('Type', $sort, $order, $search, $date_from, $date_to); ?>">Type</a></th>
                            <th style="width: 220px;"><a href="<?php echo getSortURL('Proponent', $sort, $order, $search, $date_from, $date_to); ?>">Proponent</a></th>
                            <th style="width: auto;"><a href="<?php echo getSortURL('Subject', $sort, $order, $search, $date_from, $date_to); ?>">Subject</a></th>
                            <th style="width: 250px;">Latest Action</th>
                            <th style="width: 140px;"><a href="<?php echo getSortURL('Folder', $sort, $order, $search, $date_from, $date_to); ?>">Folder</a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records_result->num_rows > 0): $idx = 0; ?>
                            <?php while($row = $records_result->fetch_assoc()): 
                                $rowData = safeJson($row); 
                                $action = "Initial Receipt"; $actionClass = "status-initial";
                                if (!empty($row['Indorsement2']) && $row['Indorsement2'] !== "-none-") { $action = "2nd Ind: ".$row['Indorsement2']; $actionClass="status-ind2"; }
                                elseif (!empty($row['Com_Rep']) && $row['Com_Rep'] !== "-none-") { $action = "Report: ".$row['Com_Rep']; $actionClass="status-rep"; }
                                elseif (!empty($row['Indorsement1']) && $row['Indorsement1'] !== "-none-") { $action = "1st Ind: ".$row['Indorsement1']; $actionClass="status-ind1"; }
                            ?>
                            <tr>
                                <td style="text-align: center;"><input type="checkbox" class="record-checkbox" value="<?php echo $row['id']; ?>"></td>
                                <td class="text-mono"><?php echo formatTableDate($row['Date_Received']); ?></td>
                                <td class="text-mono"><?php echo cleanDisplay($row['Ref_No']); ?></td>
                                <td><span class="type-badge"><?php echo cleanDisplay($row['Type']); ?></span></td>
                                <td><?php echo shorten($row['Proponent'], 25); ?></td>
                                <td class="subject-cell">
                                    <a href="javascript:void(0)" onclick="openDetailByIndex(<?php echo $idx; ?>)" class="subject-link"><?php echo shorten($row['Subject'], 65); ?></a>
                                    <div class="json-store" style="display:none;"><?php echo $rowData; ?></div>
                                </td>
                                <td><span class="action-pill <?php echo $actionClass; ?>" title="<?php echo htmlspecialchars($action); ?>"><?php echo $action; ?></span></td>
                                <td><span class="folder-tag"><?php echo cleanDisplay($row['Folder']); ?></span></td>
                            </tr>
                        <?php $idx++; endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="8" class="empty-row" style="text-align:center; padding:50px;">No documents match your current filter.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): $base = "?search=".urlencode($search)."&df=$date_from&dt=$date_to&sort=$sort&order=".strtolower($order); ?>
            <div class="table-pagination">
                <a href="<?php echo $base; ?>&p=1" class="page-btn">« First</a>
                <div class="page-numbers">
                    <?php for($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
                        <a href="<?php echo $base; ?>&p=<?php echo $i; ?>" class="page-btn <?php if($i == $page) echo 'active'; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                </div>
                <a href="<?php echo $base; ?>&p=<?php echo $total_pages; ?>" class="page-btn">Last »</a>
            </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Modal: View Details -->
    <dialog id="modal-view-details" class="table-modal">
        <form action="edit_record_logic.php" method="POST" id="edit-detail-form">
            <div class="modal-head">
                <div class="modal-title-box">
                    <small id="modal-mode-label">Document Details</small>
                    <h2 id="view-subject-title">Subject</h2>
                </div>
                <button type="button" class="modal-close-x" onclick="closeDetailModal()">&times;</button>
            </div>
            <input type="hidden" name="record_id" id="view-record-id">
            <input type="hidden" name="verify_passkey" id="hidden-passkey">
            <div id="details-content" class="modal-details-grid"></div>
            <div class="modal-foot">
                <div class="record-nav">
                    <button type="button" class="btn-nav-outline" onclick="navRecord(-1)">←</button>
                    <button type="button" class="btn-nav-outline" onclick="navRecord(1)">→</button>
                </div>
                <div style="display:flex; gap:10px;">
                    <button type="button" id="btn-enable-edit" class="btn-nav-outline" style="color:var(--primary); border-color:var(--primary);" onclick="enableEditMode()">📝 Edit Record</button>
                    <button type="button" id="btn-trigger-verify" class="btn-add-record" style="display: none;" onclick="openVerifyModal()">💾 Save Changes</button>
                    <button type="button" class="btn-close-gray" onclick="closeDetailModal()">Close</button>
                </div>
            </div>
        </form>
    </dialog>

    <!-- Modal: Add Record -->
    <dialog id="modal-add-manual" class="table-modal" style="max-width:900px;">
        <form action="add_record_logic.php" method="POST">
            <div class="modal-head">
                <h2>New Administrative Entry</h2>
                <button type="button" class="modal-close-x" onclick="document.getElementById('modal-add-manual').close()">&times;</button>
            </div>
            <div class="modal-form-grid">
                <?php 
                $manual_hdrs = ["Date Received"=>"Date_Received", "Time Received"=>"Time_Received","Ref No" => "Ref_No" ,"Type"=>"Type", "Proponent"=>"Proponent", "Subject"=>"Subject", "Description"=>"Subject_Description", "Notation"=>"Subject_Notation", "Committee"=>"Committee_Referred", "Indorsement 1"=>"Indorsement1", "Date Ind 1"=>"Date_Indorsed1", "Com Rep Nr"=>"Com_Rep_Nr", "Com Rep"=>"Com_Rep", "Date Rec (Rep)"=>"Com_Rep_Date_Received", "Item Nr"=>"Item_Nr", "Agenda Date"=>"Agenda_Date", "Action Taken"=>"Action_Taken", "Indorsement 2"=>"Indorsement2", "Date Ind 2"=>"Indorsement2_Date", "Remarks"=>"Remarks", "Folder"=>"Folder"];
                foreach($manual_hdrs as $l => $c): 
                    $isFull = in_array($c, ['Subject', 'Subject_Description', 'Action_Taken', 'Remarks', 'Notation', 'Committee_Referred', 'Indorsement1', 'Indorsement2']);
                ?>
                    <div class="form-group <?php echo $isFull ? 'full' : ''; ?>">
                        <label><?php echo $l; ?></label>
                        <?php if($isFull): ?>
                            <textarea name="<?php echo $c; ?>" rows="2"></textarea>
                        <?php else: ?>
                            <input type="<?php echo (strpos($c, 'Date') !== false) ? 'date' : ((strpos($c, 'Time') !== false) ? 'time' : 'text'); ?>" name="<?php echo $c; ?>" <?php echo ($c == 'Date_Received' || $c == 'Subject') ? 'required' : ''; ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="modal-foot" style="justify-content: flex-end; gap:10px;">
                <button type="button" class="btn-close-gray" onclick="document.getElementById('modal-add-manual').close()">Discard</button>
                <button type="submit" class="btn-add-record">Save New Record</button>
            </div>
        </form>
    </dialog>

    <!-- Modal: Batch Import -->
    <dialog id="modal-import" class="table-modal" style="max-width:450px;">
        <form action="import_logic.php" method="POST" enctype="multipart/form-data">
            <div class="modal-head"><h2>Batch Import</h2></div>
            <div style="padding:30px; text-align:center;">
                <div style="border:2px dashed var(--border-color); padding:30px; border-radius:12px; background:var(--bg-light); cursor:pointer;" onclick="document.getElementById('csv_inp').click()">
                    <input type="file" name="csv_file" accept=".csv" required id="csv_inp" style="display:none;">
                    <div style="font-size:2rem;">📥</div>
                    <div style="font-weight:700; margin-top:10px; color:#0f172a;">Click to select CSV file</div>
                    <div id="csv-name" style="margin-top:10px; font-size:0.8rem; color:var(--primary); font-weight:700;"></div>
                </div>
                <p style="font-size:0.8rem; color:var(--text-muted); margin-top:15px;">Ensure your CSV matches the official template columns.</p>
            </div>
            <div class="modal-foot" style="justify-content: flex-end; gap:10px;">
                <button type="button" class="btn-close-gray" onclick="document.getElementById('modal-import').close()">Cancel</button>
                <button type="submit" class="btn-add-record">Start Import</button>
            </div>
        </form>
    </dialog>

    <script src="../scripts/main.js"></script>
    <script>
        document.getElementById('csv_inp').addEventListener('change', function() {
            document.getElementById('csv-name').textContent = this.files[0] ? this.files[0].name : "";
        });
    </script>
</body>
</html>