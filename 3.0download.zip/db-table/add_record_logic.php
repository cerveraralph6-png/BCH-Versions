<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fields = ['Date_Received', 'Time_Received', 'Type', 'Proponent', 'Subject', 'Subject_Description', 'Subject_Notation', 'Committee_Referred', 'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 'Com_Rep_Date_Received', 'Com_Rep_Time_Received', 'Item_Nr', 'Agenda_Date', 'Action_Taken', 'Indorsement2', 'Indorsement2_Date', 'Remarks', 'Folder'];
    
    $processed = [];
    $dateFields = ['Date_Received', 'Date_Indorsed1', 'Com_Rep_Date_Received', 'Agenda_Date', 'Indorsement2_Date'];
    $timeFields = ['Time_Received', 'Com_Rep_Time_Received'];

    foreach($fields as $f) {
        $val = isset($_POST[$f]) ? trim($_POST[$f]) : "";
        if (empty($val)) {
            $processed[] = (in_array($f, $dateFields) || in_array($f, $timeFields)) ? null : "-none-";
        } else {
            $processed[] = $val;
        }
    }

    $sql = "INSERT INTO city_records (".implode(',', $fields).") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssssssss", ...$processed);
    

    if ($stmt->execute()) {
        header("Location: table.php?success=1");
        exit();
    }
    $conn->query("UPDATE system_sync SET last_update = CURRENT_TIMESTAMP WHERE module_name = 'records'");
}

?>