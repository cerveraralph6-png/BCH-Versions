<?php
// Set session cookie to last for 24 hours 
// This allows the user to "resume" if they close the window, 
// provided they return within the 5-minute activity window.
session_set_cookie_params(86400); 

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- CRITICAL: PREVENT BROWSER FROM CACHING PROTECTED PAGES ---
// This forces the browser to check with the server every time a user 
// clicks the "Back" or "Forward" buttons.
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Expire in the past

// 1. Check if user is logged in
if (!isset($_SESSION['role'])) {
    header("Location: /index.php");
    exit();
}

// 2. FORCE SECURITY SETUP LOGIC
// Check if the user hasn't changed their password yet
if (isset($_SESSION['password_changed']) && $_SESSION['password_changed'] == 0) {
    
    // Define which pages they ARE allowed to see (don't lock them out of the setup itself!)
    $allowed_pages = ['change_password.php', 'logout.php', 'update_password_logic.php'];
    $current_page = basename($_SERVER['PHP_SELF']);

    if (!in_array($current_page, $allowed_pages)) {
        // If they try to go anywhere else, force them back to setup
        header("Location: /change_password.php");
        exit();
    }
}

// 2. 5 Minute Inactivity Check (300 seconds)
$timeout_duration = 600; 

if (isset($_SESSION['last_activity'])) {
    $elapsed_time = time() - $_SESSION['last_activity'];
    
    if ($elapsed_time >= $timeout_duration) {
        // Time is up! Destroy session and send to login
        session_unset();
        session_destroy();
        header("Location: /index.php?reason=timeout");
        exit();
    }
}

// ... existing session and login checks ...

// 2. Check if user is forced to change password
// We allow them to be on 'change_password.php' or 'update_password_logic.php'
$currentPage = basename($_SERVER['PHP_SELF']);
if (isset($_SESSION['must_change_password']) && $_SESSION['must_change_password'] === true) {
    if ($currentPage !== 'change_password.php' && $currentPage !== 'update_password_logic.php') {
        header("Location: /change_password.php");
        exit();
    }
}

// 3. Update the timestamp to 'now'
// This resets the 5-minute clock on every page refresh or interaction
$_SESSION['last_activity'] = time();
?>