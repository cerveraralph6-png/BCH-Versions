<?php
session_set_cookie_params(86400); 
session_start();
header('Content-Type: application/json');
include 'db.php';

// Helper function to get the real IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

$ip_address = getUserIP();
$max_attempts = 5;
$lockout_duration = 10;

// 1. Check if user is currently locked out
if (isset($_SESSION['lockout_time'])) {
    $seconds_left = ($_SESSION['lockout_time'] + $lockout_duration) - time();
    if ($seconds_left > 0) {
        echo json_encode(['status' => 'error', 'message' => "Too many failed attempts. Wait $seconds_left seconds."]);
        exit();
    } else {
        unset($_SESSION['lockout_time']);
        $_SESSION['failed_attempts'] = 0;
    }
}

$passkey = $_POST['passkey'] ?? '';
if (empty($passkey)) {
    echo json_encode(['status' => 'error', 'message' => 'No passkey provided']);
    exit();
}

$authenticated_row = null;

// --- 2. STEP A: CHECK MASTER ADMIN (PLAIN TEXT) ---
// We check if the passkey matches the Master Admin (ID 1) directly.
$master_stmt = $conn->prepare("SELECT id, passkey, role, status, full_name, password_changed FROM users WHERE id = 1 AND passkey = ? LIMIT 1");
$master_stmt->bind_param("s", $passkey);
$master_stmt->execute();
$master_res = $master_stmt->get_result();

if ($row = $master_res->fetch_assoc()) {
    $authenticated_row = $row;
} else {
    // --- 3. STEP B: CHECK ALL OTHER USERS (HASHED) ---
    // If it wasn't the Master Admin, we look through all other active users.
    $stmt = $conn->prepare("SELECT id, passkey, role, status, full_name, password_changed FROM users WHERE id != 1 AND status = 'active'");
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        if (password_verify($passkey, $row['passkey'])) {
            $authenticated_row = $row;
            break; 
        }
    }
}

// 4. AUTHENTICATION RESULT
if ($authenticated_row) {
    // Check if account is archived
    if ($authenticated_row['status'] == 'archived') {
        echo json_encode(['status' => 'error', 'message' => 'This account is archived.']);
        exit();
    }
    
    $_SESSION['failed_attempts'] = 0;
    $_SESSION['user_id'] = $authenticated_row['id'];
    $_SESSION['role'] = $authenticated_row['role'];
    $_SESSION['full_name'] = $authenticated_row['full_name'];
    $_SESSION['password_changed'] = $row['password_changed']; // ADD THIS LINE
    $_SESSION['last_activity'] = time(); 
    
    $redirect = ($authenticated_row['password_changed'] == 0) ? './change_password.php' : (($authenticated_row['role'] == 'admin') ? './admin/admin.php' : './user/user.php');
    echo json_encode(['status' => 'success', 'redirect' => $redirect]);

} else {
   // --- FAILURE LOGIC: Group by IP and increment attempts ---
    $log_stmt = $conn->prepare("
        INSERT INTO login_logs (ip_address, attempts) 
        VALUES (?, 1) 
        ON DUPLICATE KEY UPDATE attempts = attempts + 1, last_attempt = CURRENT_TIMESTAMP
    ");
    $log_stmt->bind_param("s", $ip_address);
    $log_stmt->execute();

    if (!isset($_SESSION['failed_attempts'])) {
        $_SESSION['failed_attempts'] = 0;
    }
    $_SESSION['failed_attempts']++;

    if ($_SESSION['failed_attempts'] >= $max_attempts) {
        $_SESSION['lockout_time'] = time();
        echo json_encode(['status' => 'error', 'message' => "Too many attempts. Lockout active."]);
    } else {
        $remaining = $max_attempts - $_SESSION['failed_attempts'];
        echo json_encode(['status' => 'error', 'message' => "Invalid Passkey. $remaining attempts left."]);
    }
}
?>