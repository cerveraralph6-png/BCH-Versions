<?php
include_once '../auth_check.php';
include '../db.php'; // Include DB to check for notifications

$current_user = $_SESSION['user_id'];
$displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Employee';

// 1. Check for unread received files
$notifQuery = $conn->prepare("SELECT COUNT(*) as unread_count FROM file_transfers WHERE receiver_id = ? AND is_read = 0");
$notifQuery->bind_param("i", $current_user);
$notifQuery->execute();
$unread_count = $notifQuery->get_result()->fetch_assoc()['unread_count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../Imag3s/baguio-logo-gov.png">
    <link rel="stylesheet" href="../CSS/user.css">
    <title>BCH | Staff Portal</title>
    <style>
        /* Notification Badge Style */
        .notif-badge {
            position: absolute; top: -5px; right: -5px;
            background: #ef4444; color: white;
            font-size: 10px; font-weight: 800;
            padding: 2px 6px; border-radius: 50%;
            border: 2px solid white;
        }
        .tool-card.has-notif { border-color: #3b82f6; background: #eff6ff; }
        .new-label { background: #3b82f6; color: white; font-size: 10px; padding: 2px 8px; border-radius: 10px; margin-left: 10px; }
    </style>
</head>
<body class="dashboard-bg">

    <nav class="glass-nav">
        <div class="nav-left">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo" class="nav-logo">
            <div class="nav-titles">
                <h1>Baguio City Hall</h1>
                <span>Staff Portal</span>
            </div>
        </div>
        <div class="nav-actions">
            <!-- Updated Bell with Dynamic Badge -->
            <button class="btn-icon" title="Notifications" style="position:relative;" onclick="window.location.href='../tools/files.php'">
                🔔 <?php if($unread_count > 0): ?><span class="notif-badge"><?php echo $unread_count; ?></span><?php endif; ?>
            </button>
            <button class="btn-nav logout" onclick="window.location.href='../logout.php'">Logout</button>
        </div>
    </nav>

    <main class="fade-in">
        <section class="welcome-section">
            <div class="greetings">
                <h1>Welcome back, <span class="user-name"><?php echo htmlspecialchars($displayName); ?>!</span></h1>
                <p>Have a productive day at the Sangguniang Panlungsod.</p>
            </div>
            <div class="date-display">
                <span><?php echo date('l, F d, Y'); ?></span>
            </div>
        </section>
        
        <h2 class="section-label">Your Workspace</h2>
        
        <div class="card-grid">
            <!-- Standard Cards ... -->
            <a href="../tools/events.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper"><img src="../Imag3s/events.webp" alt="events"></div>
                    <div class="tool-info"><h3>Events</h3><p>View & Manage Schedules</p></div>
                </div>
            </a>

            <a href="../db-table/table.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper"><img src="../Imag3s/database.webp" alt="database"></div>
                    <div class="tool-info"><h3>Registry</h3><p>Access Record Database</p></div>
                </div>
            </a>

            <!-- Updated File Center Card with Notification Alert -->
            <a href="../tools/files.php" class="card-link">
                <div class="tool-card <?php echo ($unread_count > 0) ? 'has-notif' : ''; ?>">
                    <div class="icon-wrapper"><img src="../Imag3s/Files.webp" alt="files"></div>
                    <div class="tool-info">
                        <h3>File Center <?php if($unread_count > 0): ?><span class="new-label">NEW</span><?php endif; ?></h3>
                        <p><?php echo ($unread_count > 0) ? "You received $unread_count new file(s)" : "Storage & Cloud Transfer"; ?></p>
                    </div>
                </div>
            </a>
        </div>
    </main>
    <script src="../scripts/main.js"></script>
</body>
</html>