<?php
include_once '../auth_check.php';
include '../db.php';

$current_user = $_SESSION['user_id'];

$conn->query("UPDATE file_transfers SET is_read = 1 WHERE receiver_id = $current_user");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/tools.css">
    <title>BCH | File Management</title>
</head>
<body class="table-page-bg">
    <nav class="table-nav" style="background: white; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; padding: 10px 40px; position: fixed; top: 0; width: 100%; z-index: 1000;">
        <div style="display: flex; align-items: center; gap: 15px;">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo" style="height: 45px;">
            <div>
                <h1 style="font-size: 1.1rem; font-weight: 800; color: #0f172a; line-height: 1;">Sangguniang Panlungsod</h1>
                <span style="font-size: 0.75rem; font-weight: 600; color: #64748b; text-transform: uppercase;">City Council (Baguio City)</span>
            </div>
        </div>
        <div class="nav-actions">
            <?php 
                $homePath = ($_SESSION['role'] === 'admin') ? '/admin/admin.php' : '/user/user.php'; 
            ?>
            <button id="Dashboard" class="btn-home" onclick="window.location.href='<?php echo $homePath; ?>'" style="padding: 8px 16px; border-radius: 8px; font-weight: 700; border: 1px solid #e2e8f0; cursor: pointer;">Home</button>
                <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

<main style="padding-top: 100px; max-width: 1200px; margin: auto;">
    
    <!-- Status Alerts -->
    <?php if(isset($_GET['success'])): ?>
        <div id="success-alert" style="background: #ecfdf5; color: #065f46; padding: 12px; border-radius: 8px; margin-bottom: 15px; font-weight: 600; text-align: center; border: 1px solid #bbf7d0;">
            <?php 
                if($_GET['success'] == 'deleted') echo "File deleted successfully!";
                if($_GET['success'] == 'uploaded') echo "File uploaded successfully!";
                if($_GET['success'] == 'sent') echo "File sent successfully!";
            ?>
        </div>
        <script>setTimeout(() => { document.getElementById('success-alert').style.display = 'none'; }, 3000);</script>
    <?php endif; ?>

    <div id="container1" style="background: white; border-radius: 16px; border: 1px solid #e2e8f0; padding: 30px;">
        <div class="table-header" style="margin-bottom: 30px;">
            <h1 style="font-size: 1.5rem; font-weight: 800;">File Management</h1>
        </div>

        <!-- ⬆️ Upload Section -->
        <div class="card upload-card" style="border: 2px dashed #cbd5e1; text-align: center; padding: 30px; border-radius: 12px; background: #f8fafc;">
            <h2 style="font-size: 1.1rem; margin-bottom: 15px;"><span>⬆️</span> Upload New Document</h2>
            <form action="upload_handler.php" method="POST" enctype="multipart/form-data" class="upload-form">
                <div class="file-upload-wrapper" style="margin-bottom: 15px;">
                    <input type="file" name="my_file" id="actual-btn" hidden required>
                    <label for="actual-btn" class="btn-action btn-edit-blue" style="cursor: pointer; padding: 10px 20px; border: 1px solid #3b82f6; border-radius: 8px; display: inline-block;">
                        📁 Choose File...
                    </label>
                    <div id="file-chosen" style="margin-top: 10px; font-size: 0.85rem; color: #64748b;">No file chosen</div>
                </div>
                <button type="submit" class="btn-save" style="background: #3b82f6; color: white; border: none; padding: 10px 25px; border-radius: 8px; font-weight: 700; cursor: pointer;">
                    Upload to Server
                </button>
            </form>
        </div>

        <!-- 📂 List Section -->
        <h2 class="section-title" style="margin-top: 40px; margin-bottom: 15px; font-size: 1.2rem; font-weight: 800;">📂 My Documents</h2>
        <div class="table-container" style="width: 100%; overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f8fafc; text-align: left; border-bottom: 2px solid #e2e8f0;">
                        <th style="padding: 15px;">Filename</th>
                        <th style="padding: 15px;">Size</th>
                        <th style="padding: 15px;">Date</th>
                        <th style="padding: 15px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query: Show files I uploaded OR files sent to me
                    $query = "SELECT f.*, u.full_name as sender_name 
                              FROM files f
                              LEFT JOIN file_transfers ft ON f.id = ft.file_id
                              LEFT JOIN users u ON f.uploader_id = u.id
                              WHERE f.uploader_id = $current_user OR ft.receiver_id = $current_user
                              GROUP BY f.id
                              ORDER BY f.upload_date DESC";
                    
                    $myFiles = $conn->query($query);

                    if ($myFiles->num_rows > 0) {
                        while($f = $myFiles->fetch_assoc()) {
                            $id = $f['id'];
                            $name = htmlspecialchars($f['filename']);
                            $size = $f['file_size'];
                            $date = date('M d, Y', strtotime($f['upload_date']));
                            $filePath = "../" . $f['file_path']; 
                            
                            $isReceived = ($f['uploader_id'] != $current_user) ? "<br><small style='color:#3b82f6; font-weight:bold;'>Shared by: {$f['sender_name']}</small>" : "";

                            echo "<tr style='border-bottom: 1px solid #f1f5f9;'>
                                <td style='padding: 15px; font-weight: 600;'>📄 {$name} {$isReceived}</td>
                                <td style='padding: 15px; color: #64748b;'>{$size}</td>
                                <td style='padding: 15px;'>{$date}</td>
                                <td style='padding: 15px;'>
                                    <div class='action-group' style='display: flex; gap: 8px;'>
                                        <a href='{$filePath}' target='_blank' class='btn-action' style='text-decoration: none; color: #3b82f6; border: 1px solid #bfdbfe; padding: 5px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: 700;'>👁️ View</a>
                                        <a href='{$filePath}' download class='btn-action' style='text-decoration: none; color: #10b981; border: 1px solid #bbf7d0; padding: 5px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: 700;'>📥 Download</a>";
                                        
                                        // Only uploader can delete
                                        if($f['uploader_id'] == $current_user) {
                                            echo "<button class='btn-action' onclick='if(confirm(\"Delete file permanently?\")) window.location.href=\"delete_file.php?id={$id}\"' style='background: none; color: #ef4444; border: 1px solid #fecaca; padding: 5px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: 700; cursor: pointer;'>🗑️ Delete</button>";
                                        }
                                    echo "</div>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' style='padding: 40px; text-align: center; color: #94a3b8;'>No files found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- ✉️ Send Section -->
        <div class="card send-card" style="margin-top: 40px; background: #f8fafc; padding: 25px; border-radius: 12px; border: 1px solid #e2e8f0;">
            <h2 style="font-size: 1.1rem; margin-bottom: 20px;"><span>✉️</span> Send File to Account</h2>
            <form action="send_handler.php" method="POST" style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 15px; align-items: flex-end;">
                <div class="form-input-group">
                    <label style="display: block; font-size: 0.75rem; font-weight: 800; color: #64748b; margin-bottom: 8px;">RECIPIENT ACCOUNT</label>
                    <select name="receiver_id" required style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0;">
                        <option value="" disabled selected>Select staff...</option>
                        <?php
                        $users = $conn->query("SELECT id, full_name, role FROM users WHERE id != $current_user AND status='active'");
                        while($u = $users->fetch_assoc()) {
                            echo "<option value='{$u['id']}'>{$u['full_name']} (" . ucfirst($u['role']) . ")</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-input-group">
                    <label style="display: block; font-size: 0.75rem; font-weight: 800; color: #64748b; margin-bottom: 8px;">SELECT DOCUMENT</label>
                    <select name="file_id" required style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0;">
                        <option value="" disabled selected>Select from uploaded...</option>
                        <?php
                        $files = $conn->query("SELECT id, filename FROM files WHERE uploader_id = $current_user");
                        while($f = $files->fetch_assoc()) {
                            echo "<option value='{$f['id']}'>{$f['filename']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <button type="submit" class="btn-save" style="background: #0f172a; color: white; border: none; padding: 12px 25px; border-radius: 8px; font-weight: 700; cursor: pointer;">
                    🚀 Send File Now
                </button>
            </form>
        </div>
    </div>
</main>
    <script src="/scripts/main.js"></script>
    <script>
        // File selection display logic
        document.getElementById('actual-btn').addEventListener('change', function(){
            document.getElementById('file-chosen').textContent = this.files[0] ? this.files[0].name : "No file chosen";
        });
    </script>
</body>
</html>