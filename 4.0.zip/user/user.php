<?php
include_once '../auth_check.php';
// Dynamic greeting name
$displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : 'Employee';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="icon" type="image/x-icon" href="../Imag3s/baguio-logo-gov.png">
    <link rel="stylesheet" href="../CSS/user.css">
    <title>BCH | Staff Portal</title>
</head>
<body class="dashboard-bg">

    <nav class="glass-nav">
        <div class="nav-left">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo" class="nav-logo">
            <div class="nav-titles">
                <h1>Baguio City Hall</h1>
                <span>Staff Portal</span>
            </div>
        </div>
        <div class="nav-actions">
            <button class="btn-icon" title="Notifications">🔔</button>
            <button class="btn-nav logout" onclick="window.location.href='../logout.php'">Logout</button>
        </div>
    </nav>

    <main class="fade-in">
        <section class="welcome-section">
            <div class="greetings">
                <h1>Welcome back, <span class="user-name"><?php echo htmlspecialchars($displayName); ?>!</span></h1>
                <p>Have a productive day at the Sangguniang Panlungsod.</p>
            </div>
            <div class="date-display">
                <span><?php echo date('l, F d, Y'); ?></span>
            </div>
        </section>
        
        <h2 class="section-label">Your Workspace</h2>
        
        <div class="card-grid">
            <a href="../tools/events.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/events.webp" alt="events">
                    </div>
                    <div class="tool-info">
                        <h3>Events</h3>
                        <p>View & Manage Schedules</p>
                    </div>
                </div>
            </a>

            <a href="../db-table/table.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/database.webp" alt="database">
                    </div>
                    <div class="tool-info">
                        <h3>Registry</h3>
                        <p>Access Record Database</p>
                    </div>
                </div>
            </a>

            <a href="../tools/files.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/Files.webp" alt="files">
                    </div>
                    <div class="tool-info">
                        <h3>File Center</h3>
                        <p>Storage & Cloud Transfer</p>
                    </div>
                </div>
            </a>
        </div>
    </main>

    <script src="../scripts/main.js"></script>
</body>
</html>