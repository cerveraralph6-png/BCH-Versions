<?php
session_start();
if (!isset($_SESSION['role'])) { header("Location: index.php"); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BCH | Security Setup</title>
    <link rel="stylesheet" href="CSS/tools.css">
</head>
<body style="display: flex; align-items: center; justify-content: center; height: 100vh; padding: 0; margin: 0; overflow: hidden;">
    
    <div class="card" style="max-width: 420px; width: 90%; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);">
        <h2 style="justify-content: center; font-size: 1.5rem; font-weight: 700;">Security Setup</h2>
        
        <p style="font-size: 0.95rem; color: #64748b; line-height: 1.6; text-align: center; margin-bottom: 25px;">
            Hi, <strong><?php echo htmlspecialchars($_SESSION['full_name']); ?></strong>. Since this is your first time logging in, please set a new personal passkey to secure your account.
        </p>

        <form action="update_password_logic.php" method="POST">
            <div class="form-group">
                <label>New Passkey</label>
                <input type="password" name="new_pass" placeholder="Enter new passkey" required minlength="6">
            </div>
            
            <div class="form-group">
                <label>Confirm Passkey</label>
                <input type="password" name="confirm_pass" placeholder="Repeat new passkey" required>
            </div>

            <?php if(isset($_GET['error'])): ?>
                <div style="background: #fef2f2; color: #dc2626; padding: 10px; border-radius: 8px; font-size: 0.85rem; margin-bottom: 15px; text-align: center; border: 1px solid #fecaca;">
                    ⚠️ Passkeys do not match!
                </div>
            <?php endif; ?>

            <button type="submit" class="btn-save" style="width: 100%; height: 50px; font-size: 1rem; margin-top: 10px;">
                Save & Continue
            </button>
        </form>
    </div>

</body>
</html>