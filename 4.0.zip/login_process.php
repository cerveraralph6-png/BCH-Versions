<?php
session_set_cookie_params(86400); 
session_start();
header('Content-Type: application/json');
include 'db.php';

// Helper function to get the real IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

$ip_address = getUserIP();
$max_attempts = 5;
$lockout_duration = 10;

// 1. Check if user is currently locked out
if (isset($_SESSION['lockout_time'])) {
    $seconds_left = ($_SESSION['lockout_time'] + $lockout_duration) - time();
    if ($seconds_left > 0) {
        echo json_encode(['status' => 'error', 'message' => "Too many failed attempts. Wait $seconds_left seconds."]);
        exit();
    } else {
        unset($_SESSION['lockout_time']);
        $_SESSION['failed_attempts'] = 0;
    }
}

$passkey = $_POST['passkey'] ?? '';
if (empty($passkey)) {
    echo json_encode(['status' => 'error', 'message' => 'No passkey provided']);
    exit();
}

$stmt = $conn->prepare("SELECT id, role, status, full_name, password_changed FROM users WHERE passkey = ?");
$stmt->bind_param("s", $passkey);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // --- SUCCESS LOGIC ---
    if ($row['status'] == 'archived') {
        echo json_encode(['status' => 'error', 'message' => 'This account is archived.']);
        exit();
    }
    
    $_SESSION['failed_attempts'] = 0;
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['role'] = $row['role'];
    $_SESSION['full_name'] = $row['full_name'];
    $_SESSION['last_activity'] = time(); 
    
    $redirect = ($row['password_changed'] == 0) ? './change_password.php' : (($row['role'] == 'admin') ? './admin/admin.php' : './user/user.php');
    echo json_encode(['status' => 'success', 'redirect' => $redirect]);

} else {
   // --- UPDATED FAILURE LOGIC: Group by IP and increment attempts ---
    $log_stmt = $conn->prepare("
        INSERT INTO login_logs (ip_address, attempts) 
        VALUES (?, 1) 
        ON DUPLICATE KEY UPDATE attempts = attempts + 1, last_attempt = CURRENT_TIMESTAMP
    ");
    $log_stmt->bind_param("s", $ip_address);
    $log_stmt->execute();

    // The rest of your failed_attempts session logic follows...
    if (!isset($_SESSION['failed_attempts'])) {
        $_SESSION['failed_attempts'] = 0;
    }
    $_SESSION['failed_attempts']++;

    if ($_SESSION['failed_attempts'] >= $max_attempts) {
        $_SESSION['lockout_time'] = time();
        echo json_encode(['status' => 'error', 'message' => "Too many attempts. Lockout active."]);
    } else {
        $remaining = $max_attempts - $_SESSION['failed_attempts'];
        echo json_encode(['status' => 'error', 'message' => "Invalid Passkey. $remaining attempts left."]);
    }
}

// Example of how to ban a specific bad actor
//if ($ip_address === "123.456.7.8") {
//    die("Your IP has been permanently banned for security reasons.");
//}
?>