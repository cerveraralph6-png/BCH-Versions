document.addEventListener('DOMContentLoaded', () => {
    console.log("BCH System Active...");

    // --- 1. AJAX LOGIN ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const errorDiv = document.getElementById('error-msg');
            const formData = new FormData(this);
            fetch('login_process.php', { method: 'POST', body: formData })
            .then(res => res.json()).then(data => {
                if (data.status === 'success') { window.location.href = data.redirect; } 
                else { errorDiv.innerText = data.message || "Invalid Passkey!"; }
            }).catch(err => console.error("Login Error:", err));
        });
    }

    // --- 2. GLOBAL NAV ---
    /*const dashboardBtn = document.getElementById("Dashboard");
    if (dashboardBtn) { 
        dashboardBtn.addEventListener("click", () => { window.location.href = "/admin/admin.php"; }); 
    }*/

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) { logoutBtn.addEventListener('click', () => { window.location.href = '/logout.php'; }); }

    // --- 3. CSV UPLOAD LOADER ---
    const importForm = document.querySelector('#modal-import form');
    if (importForm) {
        importForm.addEventListener('submit', () => { document.getElementById('upload-loader').style.display = 'flex'; });
    }

    // --- 4. SELECTIVE DOWNLOAD ---
    const selectAll = document.getElementById('select-all-rows');
    const exportBtn = document.getElementById('btn-export-selected');
    const countDisplay = document.getElementById('selected-count');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.record-checkbox').forEach(cb => cb.checked = this.checked);
            updateExportButtonState();
        });
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('record-checkbox')) updateExportButtonState();
        });
        function updateExportButtonState() {
            const checkedCount = document.querySelectorAll('.record-checkbox:checked').length;
            if(countDisplay) countDisplay.innerText = checkedCount;
            if (exportBtn) {
                exportBtn.style.setProperty('opacity', checkedCount > 0 ? '1' : '0.5', 'important');
                exportBtn.style.setProperty('pointer-events', checkedCount > 0 ? 'auto' : 'none', 'important');
            }
        }
    }

    // --- 5. SMART REAL-TIME SYNC (Safety Mode) ---
    const pagePath = window.location.pathname;
    let moduleName = "";
    
    if (pagePath.includes('table.php')) moduleName = "records";
    else if (pagePath.includes('events.php')) moduleName = "events";

    if (moduleName !== "") {
        let lastSyncTime = Math.floor(Date.now() / 1000);
        
        setInterval(() => {
            // Safety 1: Stop request if user is not looking at the tab
            if (document.hidden) return;

            // Safety 2: Use Absolute Path
            const root = window.location.origin;
            const syncUrl = `${root}/tools/sync_check.php`;

            fetch(`${syncUrl}?module=${moduleName}&last_sync=${lastSyncTime}&v=${Date.now()}`, {
                method: 'GET',
                credentials: 'include', // Sends security cookies
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(res => res.json())
            .then(data => {
                if (data.update_needed) {
                    console.log("Changes detected. Syncing UI...");
                    refreshPageFragments();
                    lastSyncTime = data.server_time;
                }
            })
            .catch(err => console.log("Sync standby..."));
        }, 5000); // 30 seconds is the stable threshold for zya.me
    }
});

/**
 * Background Fragment Swapping
 */
function refreshPageFragments() {
    fetch(window.location.href, { credentials: 'include' })
    .then(response => response.text())
    .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const containers = ['tbody', '.table-pagination', '.pagination', '.stats-badges', '.badge-row', '.stats-info'];

        containers.forEach(selector => {
            const newData = doc.querySelector(selector);
            const currentArea = document.querySelector(selector);
            if (newData && currentArea) {
                currentArea.innerHTML = newData.innerHTML;
            }
        });
    })
    .catch(err => console.warn("Refresh delayed due to server load."));
}

// ... Keep all your popup functions (openDetailByIndex, navRecord, renderDetails, etc.) exactly as they were ...
// --- GLOBAL POPUP FUNCTIONS ---

let currentRecordIndex = -1;
let allPageRecords = [];
let currentRecordData = null;

function openDetailByIndex(index) {
    const stores = document.querySelectorAll('.json-store');
    allPageRecords = Array.from(stores).map(s => JSON.parse(s.innerText));
    currentRecordIndex = index;
    const modal = document.getElementById('modal-view-details');
    if (modal) { updateModalContent(allPageRecords[index]); modal.showModal(); }
}

function navRecord(step) {
    let nextIdx = currentRecordIndex + step;
    if (nextIdx >= 0 && nextIdx < allPageRecords.length) {
        currentRecordIndex = nextIdx;
        const editBtn = document.getElementById('btn-enable-edit');
        const saveBtn = document.getElementById('btn-trigger-verify');
        if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
        if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
        updateModalContent(allPageRecords[currentRecordIndex]);
    } else {
        alert(step > 0 ? "Last record." : "First record.");
    }
}

function updateModalContent(data) {
    currentRecordData = data;
    const title = document.getElementById('view-subject-title');
    if(title) title.innerText = data.Subject || "Details";
    const idField = document.getElementById('view-record-id');
    if(idField) idField.value = data.id;
    renderDetails(false); 
}

function renderDetails(isEditMode) {
    const content = document.getElementById('details-content');
    const data = currentRecordData;

    const fields = {
        "Date_Received": "Date Received", "Time_Received": "Time Received", "Ref_No": "Ref No.", 
        "Type": "Type", "Proponent": "Proponent", "Subject": "Subject", 
        "Subject_Description": "Description", "Subject_Notation": "Notation", 
        "Committee_Referred": "Committee Referred", "Indorsement1": "Indorsement 1", 
        "Date_Indorsed1": "Date Indorsed 1", "Com_Rep_Nr": "Com Rep Nr", 
        "Com_Rep": "Com Rep", "Com_Rep_Date_Received": "Date Rec (Rep)", 
        "Item_Nr": "Item Nr", "Agenda_Date": "Agenda Date", 
        "Action_Taken": "Action Taken", "Indorsement2": "Indorsement 2", 
        "Indorsement2_Date": "Date Ind 2", "Remarks": "Remarks", "Folder": "Folder"
    };

    let html = '';
    for (const [key, label] of Object.entries(fields)) {
        let value = data[key] || "";
        
        // Logic to determine if a field is full-width (3 columns)
        const isLong = label.includes("Description") || label.includes("Indorsement") || 
                       label.includes("Report") || label.includes("Action") || 
                       label.includes("Remarks") || label.includes("Notation") || 
                       label.includes("Committee") || label === "Subject" || label === "Proponent";
        
        const containerClass = isLong ? "detail-item full-width" : "detail-item";

        if (isEditMode) {
            // Render Input Fields for editing
            let inputField = isLong ? 
                `<textarea name="${key}" rows="2">${value}</textarea>` : 
                `<input type="text" name="${key}" value="${value}">`;
            
            // Special input types for dates/times
            if(key.toLowerCase().includes('date')) inputField = `<input type="date" name="${key}" value="${value}">`;
            if(key.toLowerCase().includes('time')) inputField = `<input type="time" name="${key}" value="${value}">`;
            
            html += `
                <div class="${containerClass}">
                    <label class="detail-label">${label}</label>
                    ${inputField}
                </div>`;
        } else {
            // Render static text for viewing
            const displayVal = (value === "" || value === "-none-" || value === null || value === "0000-00-00") ? 
                '<span class="none-text">-none-</span>' : value;
            
            html += `
                <div class="${containerClass}">
                    <label class="detail-label">${label}</label>
                    <div class="detail-value">${displayVal}</div>
                </div>`;
        }
    }
    content.innerHTML = html;
}

function enableEditMode() {
    renderDetails(true);
    const label = document.getElementById('modal-mode-label');
    if(label) { label.innerText = "⚠️ EDITING MODE"; label.style.color = "#ef4444"; }
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if (editBtn) editBtn.style.setProperty('display', 'none', 'important');
    if (saveBtn) saveBtn.style.setProperty('display', 'inline-flex', 'important');
}

function openVerifyModal() { document.getElementById('modal-verify-passkey').showModal(); }

function submitEditWithPasskey() {
    const passInput = document.getElementById('popup-passkey-input');
    if (!passInput.value) { alert("Enter passkey."); return; }
    document.getElementById('hidden-passkey').value = passInput.value;
    document.getElementById('edit-detail-form').submit();
}

function closeDetailModal() {
    document.getElementById('modal-view-details').close();
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
    if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
}

function exportSelectedRecords() {
    const ids = Array.from(document.querySelectorAll('.record-checkbox:checked')).map(cb => cb.value);
    if (ids.length > 0) window.location.href = `export_selected_csv.php?ids=${ids.join(',')}`;
}

function forgotPassword() { document.getElementById('modal-forgot').showModal(); }
function closeForgotModal() { document.getElementById('modal-forgot').close(); }
function verifyAndReveal() {
    const inputId = document.getElementById('verify-id').value;
    const display = document.getElementById('result-display');
    if(!inputId) return;
    let formData = new FormData();
    formData.append('employee_id', inputId);
    fetch('check_id.php', { method: 'POST', body: formData })
    .then(res => res.text()).then(data => {
        display.style.color = (data.includes("Passkey")) ? "#3b82f6" : "#ef4444";
        display.innerText = data;
    });
}

// --- Add this to your existing main.js ---

function trackOrdinance() {
    const query = document.getElementById('public-search-query').value;
    const filter = document.getElementById('public-filter-by').value;
    const resultContainer = document.getElementById('ordinance-result-container');
    
    if (!query) {
        alert("Please enter a keyword to search.");
        return;
    }

    resultContainer.innerHTML = "<div class='loader-text'>Searching city records...</div>";

    fetch(`tools/public_track.php?query=${encodeURIComponent(query)}&filter=${filter}`)
    .then(res => res.json())
    .then(data => {
        resultContainer.innerHTML = ""; // Clear loader

        if (data.found) {
            // Loop through every ordinance found
            data.results.forEach(item => {
                let statusClass = "status-pending";
                let statusText = "Pending";

                const folder = (item.Folder || "").toLowerCase();
                const action = (item.Action_Taken || "").toLowerCase();

                if (folder.includes("approved") || action.includes("approved")) {
                    statusClass = "status-approved";
                    statusText = "Approved";
                } else if (action.includes("disapproved") || action.includes("denied") || action.includes("dropped")) {
                    statusClass = "status-disapproved";
                    statusText = "Disapproved";
                }

                // Append a new result card for each item
                resultContainer.innerHTML += `
                    <div class="result-box">
                        <div class="result-header">
                            <span class="status-pill ${statusClass}">${statusText}</span>
                            <small class="result-date">Rec: ${item.Date_Received}</small>
                        </div>
                        <h3 class="result-subject">${item.Subject}</h3>
                        <div class="result-footer">
                            <span class="result-ref">Ref: ${item.Ref_No || 'N/A'}</span>
                        </div>
                    </div>
                `;
            });
        } else {
            resultContainer.innerHTML = `
                <div class="result-empty">
                    <p>No records found for "<strong>${query}</strong>" in <strong>${filter}</strong>.</p>
                </div>
            `;
        }
    })
    .catch(err => {
        resultContainer.innerHTML = "<p class='error-text'>Server error. Please try again.</p>";
    });
}