<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_pass = $_POST['new_pass'];
    $confirm_pass = $_POST['confirm_pass'];
    $user_id = $_SESSION['user_id'];

    if ($new_pass !== $confirm_pass) {
        header("Location: change_password.php?error=mismatch");
        exit();
    }

    // Update database: set new password and mark changed as 1
    $stmt = $conn->prepare("UPDATE users SET passkey = ?, password_changed = 1 WHERE id = ?");
    $stmt->bind_param("si", $new_pass, $user_id);

    if ($stmt->execute()) {
        // Success! Set the session flag to false so they can browse the site
        $_SESSION['must_change_password'] = false;
        
        $redirect = ($_SESSION['role'] == 'admin') ? 'admin/admin.php' : 'user/user.php';
        header("Location: $redirect");
        exit();
    }
}
?>