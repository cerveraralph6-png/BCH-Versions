<?php
session_start();
if (isset($_SESSION['role'])) {
    $redirect = ($_SESSION['role'] == 'admin') ? 'admin/admin.php' : 'user/user.php';
    header("Location: $redirect");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/index.css">
    <title>Baguio City Hall | Ordinance Tracker</title>
    
    <script>
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () { window.history.go(1); };
    </script>
</head>
<body class="public-bg">

    <!-- Top Navigation -->
    <nav class="public-nav">
        <div class="nav-brand">
            <img src="Imag3s/baguio-logo-gov.png" alt="Logo">
            <span>Sangguniang Panlungsod Portal</span>
        </div>
        <button class="btn-login-trigger" onclick="document.getElementById('modal-login').showModal()">
            Administrative Login
        </button>
    </nav>

    <main class="public-main">
        <div class="search-card fade-in">
            <div class="card-header">
                <img src="Imag3s/baguio-logo-gov.png" alt="City Seal">
                <h1>Track My Ordinance</h1>
                <p>Enter your Ordinance Subject or Reference Number to check the current status.</p>
            </div>

<!-- Inside <main class="public-main"> ... <div class="search-card"> -->

<div class="search-engine">
    <div class="search-box-group">
        <div class="filter-field">
            <select id="public-filter-by">
                <option value="Subject">Filter: Subject</option>
                <option value="Ref_No">Filter: Ref No.</option>
                <option value="Proponent">Filter: Proponent</option>
                <option value="Date_Received">Filter: Date Received</option>
            </select>
        </div>
        <div class="search-input-box">
            <span class="search-icon">🔍</span>
            <input type="text" id="public-search-query" placeholder="Type to search database..." onkeyup="if(event.key === 'Enter') trackOrdinance()">
        </div>
        <button class="btn-track" onclick="trackOrdinance()">Search</button>
    </div>
</div>

<!-- This will now hold multiple result cards -->
<div id="ordinance-result-container"></div>
        </div>
    </main>

    <!-- Modal: Administrative Login -->
    <dialog id="modal-login" class="login-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="document.getElementById('modal-login').close()">&times;</button>
            <div class="modal-header">
                <h2>Administrative Access</h2>
                <p>Enter passkey to manage city records</p>
            </div>
            
            <form id="login-form" method="POST">
                <div class="input-box">
                    <label for="passkey">System Passkey</label>
                    <input type="password" name="passkey" id="passkey" placeholder="••••••••" required>
                </div>
                <div id="error-msg"></div>
                <button type="submit" class="btn-submit-login">Login to Dashboard</button>
            </form>

            <div class="forgot-link">
                <a href="#" onclick="forgotPassword()">Forgot your password?</a>
            </div>
        </div>
    </dialog>

    <!-- Modal: Password Recovery -->
    <dialog id="modal-forgot" class="recovery-modal">
        <form method="dialog" id="forgot-form">
            <h2>Passkey Recovery</h2>
            <p>Please enter your Employee ID Number.</p>
            <input type="text" id="verify-id" placeholder="Enter Employee ID" required>
            <div id="result-display"></div>
            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeForgotModal()">Close</button>
                <button type="button" class="btn-save" onclick="verifyAndReveal()">Verify Identity</button>
            </div>
        </form>
    </dialog>

    <script src="scripts/main.js"></script>
</body>
</html>