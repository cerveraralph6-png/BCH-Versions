<?php
include '../db.php';
header('Content-Type: application/json');

$query = $_GET['query'] ?? '';
$filter = $_GET['filter'] ?? 'Subject';

// White-list allowed columns to prevent SQL injection
$allowedFilters = ['Subject', 'Ref_No', 'Proponent'];
if (!in_array($filter, $allowedFilters)) { $filter = 'Subject'; }

if (empty($query)) {
    echo json_encode(['found' => false, 'results' => []]);
    exit;
}

$searchTerm = "%$query%";
// Fetch up to 10 matching results
$sql = "SELECT Subject, Ref_No, Folder, Action_Taken, Date_Received FROM city_records WHERE $filter LIKE ? ORDER BY Date_Received DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $searchTerm);
$stmt->execute();
$res = $stmt->get_result();

$results = [];
while ($row = $res->fetch_assoc()) {
    $results[] = $row;
}

if (count($results) > 0) {
    echo json_encode(['found' => true, 'results' => $results]);
} else {
    echo json_encode(['found' => false, 'results' => []]);
}
?>