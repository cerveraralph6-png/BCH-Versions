<?php
session_start();

// 1. Security Check: Only allow logged-in users
if (!isset($_SESSION['role'])) {
    header("Location: /index.php");
    exit();
}

include '../db.php'; // Adjust path to your database connection

if (isset($_GET['id'])) {
    $file_id = intval($_GET['id']);

    // 2. Fetch the file path from the database first
    $stmt = $conn->prepare("SELECT file_path FROM files WHERE id = ?");
    $stmt->bind_param("i", $file_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $relative_path = $row['file_path']; // e.g., "uploads/filename.pdf"
        $full_path = "../" . $relative_path; // Path relative to this script

        // 3. Delete the physical file from the server
        if (file_exists($full_path)) {
            unlink($full_path);
        }

        // 4. Delete the record from the database
        $del_stmt = $conn->prepare("DELETE FROM files WHERE id = ?");
        $del_stmt->bind_param("i", $file_id);
        
        if ($del_stmt->execute()) {
            // Success: Redirect back with a success message
            header("Location: files.php?success=deleted");
            exit();
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "File not found in database.";
    }
} else {
    echo "No file ID provided.";
}
?>