<?php
include_once '../auth_check.php';
include '../db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/CSS/tools.css">
    <title>BCH | File Management</title>
</head>
<body>
    <nav>
        <img src="/Imag3s/baguio-logo-gov.png" alt="logo">
                <h1>Sangguniang Panlungsod</h1>
                <span>City Council (Baguio City)</span>
<div class="nav-actions">
    <?php 
        // Determine the home path based on session role
        $homePath = ($_SESSION['role'] === 'admin') ? '/admin/admin.php' : '/user/user.php'; 
    ?>
    <button id="Dashboard" class="btn-home" onclick="window.location.href='<?php echo $homePath; ?>'">Home</button>
    <button class="btn-nav logout" id="logout">Logout</button>
</div>
    </nav>

<main>
    <?php if(isset($_GET['success']) && $_GET['success'] == 'deleted'): ?>
        <div id="success-alert" style="background: #fee2e2; color: #991b1b; padding: 12px; border-radius: 8px; margin-bottom: 15px; font-weight: 600; text-align: center; border: 1px solid #fecaca;">
            File deleted successfully!
        </div>
        <script>setTimeout(() => { document.getElementById('success-alert').style.display = 'none'; }, 3000);</script>
    <?php endif; ?>
    <div id="container1">
        <div class="table-header">
            <h1>File Management</h1>
        </div>

        <!-- ⬆️ Upload Section -->
        <div class="card upload-card">
            <h2><span>⬆️</span> Upload New Document</h2>
            <form action="upload_handler.php" method="POST" enctype="multipart/form-data" class="upload-form">
                <div class="file-upload-wrapper">
                    <input type="file" name="my_file" id="actual-btn" hidden required>
                    <label for="actual-btn" class="btn-action btn-upload-label">
                        📁 Choose File...
                    </label>
                    <span id="file-chosen">No file chosen</span>
                </div>
                <button type="submit" class="btn-save">
                    Upload to Server
                </button>
            </form>
        </div>

        <!-- 📂 List Section -->
        <h2 class="section-title">📂 My Documents</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Filename</th>
                        <th>Size</th>
                        <th>Uploaded Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $myFiles = $conn->query("SELECT * FROM files ORDER BY upload_date DESC");
                    if ($myFiles->num_rows > 0) {
                        while($f = $myFiles->fetch_assoc()) {
                            $id = $f['id'];
                            $name = htmlspecialchars($f['filename']);
                            $size = $f['file_size'];
                            $date = date('M d, Y', strtotime($f['upload_date']));
                            $filePath = "../" . $f['file_path']; 

                            echo "<tr>
                                <td style='font-weight: 600; color: #1e293b;'>📄 {$name}</td>
                                <td style='color: #64748b;'>{$size}</td>
                                <td>{$date}</td>
                                <td>
                                    <div class='action-group'>
                                        <a href='{$filePath}' target='_blank' class='btn-action btn-edit-blue'>
                                            <span>👁️</span> View
                                        </a>
                                        <button class='btn-action btn-archive-red' onclick='if(confirm(\"Delete this file?\")) window.location.href=\"delete_file.php?id={$id}\"'>
                                            <span>🗑️</span> Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' class='empty-row'>No files found in your storage.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- ✉️ Send Section -->
        <div class="card send-card">
            <h2><span>✉️</span> Send File to Account</h2>
            <form action="send_handler.php" method="POST" class="send-file-grid">
                <div class="form-input-group">
                    <label>Recipient Account</label>
                    <select name="receiver_id" required>
                        <option value="" disabled selected>Select user...</option>
                        <?php
                        $users = $conn->query("SELECT id, full_name, role FROM users WHERE status='active'");
                        while($u = $users->fetch_assoc()) {
                            echo "<option value='{$u['id']}'>{$u['full_name']} (" . ucfirst($u['role']) . ")</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-input-group">
                    <label>Select Document</label>
                    <select name="file_id" required>
                        <option value="" disabled selected>Select file...</option>
                        <?php
                        $files = $conn->query("SELECT id, filename FROM files");
                        while($f = $files->fetch_assoc()) {
                            echo "<option value='{$f['id']}'>{$f['filename']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <button type="submit" class="btn-save send-btn">
                    🚀 Send File Now
                </button>
            </form>
        </div>
    </div>
</main>

    <script src="/scripts/main.js"></script>
    <script>
        const actualBtn = document.getElementById('actual-btn');
        const fileChosen = document.getElementById('file-chosen');
        if(actualBtn) {
            actualBtn.addEventListener('change', function(){
                fileChosen.textContent = this.files[0] ? this.files[0].name : "No file chosen";
            });
        }
    </script>
</body>
</html>