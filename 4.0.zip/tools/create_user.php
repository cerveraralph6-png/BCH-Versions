<?php
// 1. ADD THIS FOR DEBUGGING - This stops the 500 screen and shows the real error
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Unauthorized access.");
}

// 2. Check path. If create_user.php is in /tools/, ../db.php looks in root.
include '../db.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName   = trim($_POST['full_name']);
    $employeeId = trim($_POST['employee_id']);
    $passkey    = trim($_POST['passkey']); 
    $role       = $_POST['role'];

    // 3. Prepare the duplicate check
    $check = $conn->prepare("SELECT id FROM users WHERE employee_id = ? OR passkey = ?");
    if (!$check) {
        die("SQL Error (Check): " . $conn->error); // This will tell us if columns are missing
    }
    
    $check->bind_param("ss", $employeeId, $passkey);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Error: ID Number or Passkey already exists!'); window.location.href='manage-accounts.php';</script>";
        exit();
    }

    // 4. Prepare the Insert
    $stmt = $conn->prepare("INSERT INTO users (employee_id, full_name, passkey, role) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("SQL Error (Insert): " . $conn->error); // This will tell us if 'full_name' column is missing
    }
    
    $stmt->bind_param("ssss", $employeeId, $fullName, $passkey, $role);

    if ($stmt->execute()) {
        header("Location: manage-accounts.php?success=1");
        exit();
    } else {
        echo "Execute Error: " . $stmt->error;
    }
}
?>