<?php
// 1. Enable error reporting so we can see what's wrong
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['my_file'])) {
    
    // 2. Define folder path relative to this script
    $folder = "../uploads/"; 

    // 3. Create folder if it doesn't exist
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }

    $filename = $_FILES['my_file']['name'];
    $tempname = $_FILES['my_file']['tmp_name'];
    $error    = $_FILES['my_file']['error'];
    
    // Check if there was an upload error
    if ($error !== UPLOAD_ERR_OK) {
        die("Upload failed with error code: " . $error);
    }

    // Calculate size in MB
    $size = round($_FILES['my_file']['size'] / 1024 / 1024, 2) . " MB";
    
    // Ensure the filename is safe (removes spaces/special chars)
    $safe_filename = preg_replace("/[^a-zA-Z0-9\._-]/", "_", $filename);
    $target_path = $folder . $safe_filename;

    // 4. Move file to the folder
    if (move_uploaded_file($tempname, $target_path)) {
        // Path to store in database (relative to the site root)
        $db_path = "uploads/" . $safe_filename;

        $stmt = $conn->prepare("INSERT INTO files (filename, file_path, file_size) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $safe_filename, $db_path, $size);

        if ($stmt->execute()) {
            header("Location: files.php?success=1");
            exit();
        } else {
            echo "Database Error: " . $stmt->error;
        }
    } else {
        echo "Error: Could not move file to " . $target_path . ". Check folder permissions (CHMOD 777).";
    }
} else {
    echo "No file detected in the request.";
}
?>