<?php
session_start();
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $file_id = $_POST['file_id'];
    $receiver_id = $_POST['receiver_id'];
    
    // We assume sender is current user. For now, we just insert.
    $stmt = $conn->prepare("INSERT INTO file_transfers (file_id, receiver_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $file_id, $receiver_id);
    
    if ($stmt->execute()) {
        header("Location: files.php?msg=sent");
    }
}
?>