// --- PAGE LOAD HANDLER ---
window.addEventListener('load', () => {
    const loader = document.getElementById('page-loader');
    if (loader) {
        // Add the hidden class
        loader.classList.add('loader-hidden');
        
        // Remove from DOM after transition to save resources
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500); 
    }
});

// ... rest of your existing logic (login, trackOrdinance, clearTrackSearch) ...

document.addEventListener('DOMContentLoaded', () => {
    console.log("BCH System Active...");

    // --- 1. AJAX LOGIN ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault(); 
            const errorDiv = document.getElementById('error-msg');
            const formData = new FormData(this);
            fetch('login_process.php', { method: 'POST', body: formData })
            .then(res => res.json()).then(data => {
                if (data.status === 'success') { window.location.href = data.redirect; } 
                else { errorDiv.innerText = data.message || "Invalid Passkey!"; }
            }).catch(err => console.error("Login Error:", err));
        });
    }

    // --- 2. GLOBAL NAV ---
    /*const dashboardBtn = document.getElementById("Dashboard");
    if (dashboardBtn) { 
        dashboardBtn.addEventListener("click", () => { window.location.href = "/admin/admin.php"; }); 
    }*/

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) { logoutBtn.addEventListener('click', () => { window.location.href = '/logout.php'; }); }

    // --- 3. CSV UPLOAD LOADER ---
    const importForm = document.querySelector('#modal-import form');
    if (importForm) {
        importForm.addEventListener('submit', () => { document.getElementById('upload-loader').style.display = 'flex'; });
    }

    // --- 4. SELECTIVE DOWNLOAD ---
    const selectAll = document.getElementById('select-all-rows');
    const exportBtn = document.getElementById('btn-export-selected');
    const countDisplay = document.getElementById('selected-count');
    if (selectAll) {
        selectAll.addEventListener('change', function() {
            document.querySelectorAll('.record-checkbox').forEach(cb => cb.checked = this.checked);
            updateExportButtonState();
        });
        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('record-checkbox')) updateExportButtonState();
        });
        function updateExportButtonState() {
            const checkedCount = document.querySelectorAll('.record-checkbox:checked').length;
            if(countDisplay) countDisplay.innerText = checkedCount;
            if (exportBtn) {
                exportBtn.style.setProperty('opacity', checkedCount > 0 ? '1' : '0.5', 'important');
                exportBtn.style.setProperty('pointer-events', checkedCount > 0 ? 'auto' : 'none', 'important');
            }
        }
    }

    // --- 5. SMART REAL-TIME SYNC (Safety Mode) ---
    const pagePath = window.location.pathname;
    let moduleName = "";
    
    if (pagePath.includes('table.php')) moduleName = "records";
    else if (pagePath.includes('events.php')) moduleName = "events";

    if (moduleName !== "") {
        let lastSyncTime = Math.floor(Date.now() / 1000);
        
        setInterval(() => {
            // Safety 1: Stop request if user is not looking at the tab
            if (document.hidden) return;

            // Safety 2: Use Absolute Path
            const root = window.location.origin;
            const syncUrl = `${root}/tools/sync_check.php`;

            fetch(`${syncUrl}?module=${moduleName}&last_sync=${lastSyncTime}&v=${Date.now()}`, {
                method: 'GET',
                credentials: 'include', // Sends security cookies
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(res => res.json())
            .then(data => {
                if (data.update_needed) {
                    console.log("Changes detected. Syncing UI...");
                    refreshPageFragments();
                    lastSyncTime = data.server_time;
                }
            })
            .catch(err => console.log("Sync standby..."));
        }, 5000); // 30 seconds is the stable threshold for zya.me
    }
});
function parseTimeline(text) {
    if (!text || text === "-none-") return "<p class='none-text'>No history recorded.</p>";
    
    // Split by line breaks
    const lines = text.split('\n').filter(line => line.trim() !== "");
    
    let html = '<div class="timeline-container">';
    
    lines.forEach(line => {
        // This regex extracts the [Date | Time] and the Message
        const match = line.match(/\[(.*?)\] (.*)/);
        if (match) {
            html += `
                <div class="timeline-item">
                    <span class="timeline-meta">${match[1]}</span>
                    <p class="timeline-text">${match[2]}</p>
                </div>`;
        } else {
            // Fallback for old data without the [ ] format
            html += `
                <div class="timeline-item">
                    <p class="timeline-text">${line}</p>
                </div>`;
        }
    });
    
    html += '</div>';
    return html;
}
/**
 * Background Fragment Swapping
 */
function refreshPageFragments() {
    fetch(window.location.href, { credentials: 'include' })
    .then(response => response.text())
    .then(html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const containers = ['tbody', '.table-pagination', '.pagination', '.stats-badges', '.badge-row', '.stats-info'];

        containers.forEach(selector => {
            const newData = doc.querySelector(selector);
            const currentArea = document.querySelector(selector);
            if (newData && currentArea) {
                currentArea.innerHTML = newData.innerHTML;
            }
        });
    })
    .catch(err => console.warn("Refresh delayed due to server load."));
}

// ... Keep all your popup functions (openDetailByIndex, navRecord, renderDetails, etc.) exactly as they were ...
// --- GLOBAL POPUP FUNCTIONS ---

let currentRecordIndex = -1;
let allPageRecords = [];
let currentRecordData = null;

function openDetailByIndex(index) {
    const stores = document.querySelectorAll('.json-store');
    allPageRecords = Array.from(stores).map(s => JSON.parse(s.innerText));
    currentRecordIndex = index;
    const modal = document.getElementById('modal-view-details');
    if (modal) { updateModalContent(allPageRecords[index]); modal.showModal(); }
}

function navRecord(step) {
    let nextIdx = currentRecordIndex + step;
    if (nextIdx >= 0 && nextIdx < allPageRecords.length) {
        currentRecordIndex = nextIdx;
        const editBtn = document.getElementById('btn-enable-edit');
        const saveBtn = document.getElementById('btn-trigger-verify');
        if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
        if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
        updateModalContent(allPageRecords[currentRecordIndex]);
    } else {
        alert(step > 0 ? "Last record." : "First record.");
    }
}

function updateModalContent(data) {
    currentRecordData = data;
    const title = document.getElementById('view-subject-title');
    if(title) title.innerText = data.Subject || "Details";
    const idField = document.getElementById('view-record-id');
    if(idField) idField.value = data.id;
    renderDetails(false); 
}

function renderDetails(isEditMode) {
    const content = document.getElementById('details-content');
    const data = currentRecordData;

    const fields = {
        "Date_Received": "Date Received", "Time_Received": "Time Received", "Ref_No": "Ref No.", 
        "Type": "Type", "Proponent": "Proponent", "Subject": "Subject", 
        "Subject_Description": "Description", "Subject_Notation": "Notation", 
        "Committee_Referred": "Committee Referred", "Indorsement1": "Indorsement 1", 
        "Date_Indorsed1": "Date Indorsed 1", "Action_Taken": "Action History Tracking", // THE TRACKER
        "Indorsement2": "Indorsement 2", "Indorsement2_Date": "Date Ind 2", 
        "Remarks": "Remarks", "Folder": "Folder"
    };

    let html = '';
    for (const [key, label] of Object.entries(fields)) {
        let value = data[key] || "";
        const isLong = label.includes("Description") || label.includes("Indorsement") || label.includes("History") || label.includes("Action") || label.includes("Remarks") || label.includes("Notation") || label === "Subject" || label === "Proponent";
        const containerClass = isLong ? "detail-item full-width" : "detail-item";

if (isEditMode) {
    if (key === "Action_Taken") {
        html += `
            <div class="${containerClass}" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius:12px; padding:20px;">
                <label class="detail-label" style="color:var(--primary)">📝 Post New Update</label>
                <textarea name="new_history_entry" placeholder="What is the latest status?" rows="2" style="margin-bottom:15px; border:2px solid var(--primary);"></textarea>
                
                <label class="detail-label">Timeline History</label>
                <div style="max-height:200px; overflow-y:auto;">${parseTimeline(value)}</div>
                <input type="hidden" name="Action_Taken" value="${value}">
            </div>`;
    } else {
                let inputField = isLong ? `<textarea name="${key}" rows="2">${value}</textarea>` : `<input type="text" name="${key}" value="${value}">`;
                if(key.includes('Date')) inputField = `<input type="date" name="${key}" value="${value}">`;
                if(key.includes('Time')) inputField = `<input type="time" name="${key}" value="${value}">`;
                html += `<div class="${containerClass}"><label class="detail-label">${label}</label>${inputField}</div>`;
            }
        } else {
    // VIEW MODE
    html += `
        <div class="${containerClass}">
            <label class="detail-label">${label}</label>
            <div class="detail-value">${key === "Action_Taken" ? parseTimeline(value) : displayVal}</div>
        </div>`;
}
    }
    content.innerHTML = html;
}


function enableEditMode() {
    renderDetails(true);
    const label = document.getElementById('modal-mode-label');
    if(label) { label.innerText = "⚠️ EDITING MODE"; label.style.color = "#ef4444"; }
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if (editBtn) editBtn.style.setProperty('display', 'none', 'important');
    if (saveBtn) saveBtn.style.setProperty('display', 'inline-flex', 'important');
}

function openVerifyModal() { document.getElementById('modal-verify-passkey').showModal(); }

function submitEditWithPasskey() {
    const passInput = document.getElementById('popup-passkey-input');
    const hiddenPasskey = document.getElementById('hidden-passkey');
    const editForm = document.getElementById('edit-detail-form');
    
    if (!passInput.value) { 
        alert("Please enter your passkey."); 
        return; 
    }

    // 1. Prepare the data
    hiddenPasskey.value = passInput.value;
    const formData = new FormData(editForm);

    // 2. Visual feedback
    const submitBtn = document.querySelector('.btn-verify-submit');
    const originalText = submitBtn.innerText;
    submitBtn.innerText = "Verifying...";
    submitBtn.disabled = true;

    // 3. Send via AJAX (Fetch) to bypass zya.me security redirect
    fetch('edit_record_logic.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            // Close both modals
            document.getElementById('modal-verify-passkey').close();
            closeDetailModal();
            
            // Clear input
            passInput.value = "";
            
            // Refresh the table data instantly using our fragment logic
            refreshPageFragments();
            alert("Record updated successfully!");
        } else {
            alert("Error: " + data.message);
        }
    })
    .catch(err => {
        console.error("Update Error:", err);
        alert("Authorization failed or server is busy.");
    })
    .finally(() => {
        submitBtn.innerText = originalText;
        submitBtn.disabled = false;
    });
}

function closeDetailModal() {
    document.getElementById('modal-view-details').close();
    const editBtn = document.getElementById('btn-enable-edit');
    const saveBtn = document.getElementById('btn-trigger-verify');
    if(editBtn) editBtn.style.setProperty('display', 'inline-flex', 'important');
    if(saveBtn) saveBtn.style.setProperty('display', 'none', 'important');
}

function exportSelectedRecords() {
    const ids = Array.from(document.querySelectorAll('.record-checkbox:checked')).map(cb => cb.value);
    if (ids.length > 0) window.location.href = `export_selected_csv.php?ids=${ids.join(',')}`;
}

function forgotPassword() { document.getElementById('modal-forgot').showModal(); }
function closeForgotModal() { document.getElementById('modal-forgot').close(); }
function verifyAndReveal() {
    const inputId = document.getElementById('verify-id').value;
    const display = document.getElementById('result-display');
    if(!inputId) return;
    let formData = new FormData();
    formData.append('employee_id', inputId);
    fetch('check_id.php', { method: 'POST', body: formData })
    .then(res => res.text()).then(data => {
        display.style.color = (data.includes("Passkey")) ? "#3b82f6" : "#ef4444";
        display.innerText = data;
    });
}

// --- Add this to your existing main.js ---

function trackOrdinance() {
    const query = document.getElementById('public-search-query').value;
    const statusFilter = document.getElementById('public-status-filter').value;
    const resultContainer = document.getElementById('ordinance-result-container');
    
    if (!query && statusFilter === "All") {
        alert("Please enter keywords or select a status.");
        return;
    }

    resultContainer.innerHTML = "<p class='loader-text'>Searching city registry...</p>";

    fetch(`tools/public_track.php?query=${encodeURIComponent(query)}&status=${statusFilter}`)
    .then(res => res.json())
    .then(data => {
        resultContainer.innerHTML = ""; 

        if (data.found) {
            data.results.forEach(item => {
                let statusClass = "status-pending";
                let statusText = "Pending Review";
                
                // Content cleanup
                const actionRaw = item.Action_Taken || "";
                const actionClean = actionRaw.toLowerCase();
                const folderClean = (item.Folder || "").toLowerCase();

                // Determine Status Pill
                if (actionClean.includes("approved") || folderClean.includes("approved") || actionClean.includes("passed")) {
                    statusClass = "status-approved";
                    statusText = "Approved";
                } else if (actionClean.includes("disapproved") || actionClean.includes("dropped") || actionClean.includes("denied")) {
                    statusClass = "status-disapproved";
                    statusText = "Rejected / Dropped";
                }

                // Format the Action Taken display
                const historyContent = (actionRaw === "" || actionRaw === "-none-") 
                    ? "No specific updates recorded yet." 
                    : actionRaw;

// Inside your trackOrdinance result loop:
resultContainer.innerHTML += `
    <div class="result-box ${statusClass}-border">
        <div class="result-header">
            <span class="status-pill ${statusClass}">${statusText}</span>
            <small class="result-meta">Rec: ${item.Date_Received}</small>
        </div>
        
        <h3 class="result-subject">${item.Subject}</h3>
        
<div class="result-history-box">
    <label>Progress Timeline</label>
    <div>${parseTimeline(item.Action_Taken)}</div>
</div>

        <div class="result-footer">
            <div class="footer-item"><strong>Ref No:</strong> ${item.Ref_No || '-none-'}</div>
            <div class="footer-item"><strong>Proponent:</strong> ${item.Proponent || 'N/A'}</div>
        </div>
    </div>
`;
            });
        } else {
            resultContainer.innerHTML = `<div class="result-empty">No results found for "${query}". Try different keywords.</div>`;
        }
    })
    .catch(err => {
        resultContainer.innerHTML = "<p class='error-text'>Connection error. Please try again.</p>";
    });
}

// --- PUBLIC SEARCH CLEAR FUNCTION ---
function clearTrackSearch() {
    // 1. Get the elements
    const queryInput = document.getElementById('public-search-query');
    const filterSelect = document.getElementById('public-filter-by');
    const resultContainer = document.getElementById('ordinance-result-container');

    // 2. Clear the search text
    if (queryInput) {
        queryInput.value = "";
    }

    // 3. Clear the displayed results
    if (resultContainer) {
        resultContainer.innerHTML = "";
    }

    // 4. Reset the filter dropdown to the first option (Subject)
    if (filterSelect) {
        filterSelect.selectedIndex = 0;
    }

    // 5. Put the typing cursor back in the box for convenience
    if (queryInput) {
        queryInput.focus();
    }

    console.log("Search engine reset.");
}