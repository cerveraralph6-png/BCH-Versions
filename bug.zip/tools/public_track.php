<?php
include '../db.php';
header('Content-Type: application/json');

$query = $_GET['query'] ?? '';
$status = $_GET['status'] ?? 'All';

$where_clauses = ["(Subject LIKE ? OR Ref_No LIKE ? OR Proponent LIKE ?)"];
$params = ["%$query%", "%$query%", "%$query%"];
$types = "sss";

// --- Logic to map "Status" to Database Keywords ---
if ($status === 'Approved') {
    $where_clauses[] = "(Action_Taken LIKE '%approved%' OR Folder LIKE '%approved%')";
} 
elseif ($status === 'Rejected') {
    $where_clauses[] = "(Action_Taken LIKE '%disapproved%' OR Action_Taken LIKE '%dropped%' OR Action_Taken LIKE '%denied%')";
} 
elseif ($status === 'Pending') {
    $where_clauses[] = "(Action_Taken NOT LIKE '%approved%' 
                        AND Action_Taken NOT LIKE '%disapproved%' 
                        AND Action_Taken NOT LIKE '%dropped%' 
                        AND Action_Taken NOT LIKE '%denied%' 
                        AND Folder NOT LIKE '%approved%')";
}

$sql = "SELECT Subject, Ref_No, Folder, Action_Taken, Date_Received, Proponent 
        FROM city_records 
        WHERE " . implode(" AND ", $where_clauses) . " 
        ORDER BY Date_Received DESC LIMIT 15";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

$results = [];
while ($row = $res->fetch_assoc()) {
    $results[] = $row;
}

echo json_encode([
    'found' => (count($results) > 0),
    'results' => $results
]);