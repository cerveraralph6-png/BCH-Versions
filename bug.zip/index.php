<?php
session_start();
if (isset($_SESSION['role'])) {
    $redirect = ($_SESSION['role'] == 'admin') ? 'admin/admin.php' : 'user/user.php';
    header("Location: $redirect");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
    <link rel="icon" href="../Imag3s/baguio-logo-gov.png" type="image/png">
    <link rel="stylesheet" href="CSS/index.css?v=<?php echo filemtime('CSS/index.css'); ?>">
    <title>Baguio City Hall | Ordinance Tracker</title>
    
    <script>
        window.history.pushState(null, null, window.location.href);
        window.onpopstate = function () { window.history.go(1); };
    </script>
</head>
<body class="public-bg">

    <!-- Page Loader -->
    <div id="page-loader">
        <div class="loader-wrapper">
            <img src="Imag3s/baguio-logo-gov.png" alt="BCH" class="loader-logo">
            <div class="loader-circle"></div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="public-nav">
        <div class="nav-brand">
            <img src="Imag3s/baguio-logo-gov.png" alt="Logo">
            <div class="brand-text">
                <h1>Baguio City hall</h1>
                <span>Sangguniang Panlungsod Portal</span>
            </div>
        </div>
        <button class="btn-login-trigger" onclick="document.getElementById('modal-login').showModal()">
            Administrative Login
        </button>
    </nav>

<!-- Inside index.php -->
<main class="public-main">
    <div class="search-card fade-in">
        <header class="card-header">
            <img src="Imag3s/baguio-logo-gov.png" alt="City Seal">
            <h1>Ordinance & Resolution Tracker</h1>
            <p>Search by <strong>Title Keywords</strong>, <strong>Reference No.</strong>, or <strong>Proponent Name</strong>.</p>
        </header>

        <div class="search-engine">
            <div class="search-box-group">
                <div class="filter-field">
                    <select id="public-status-filter">
                        <option value="All">All Status</option>
                        <option value="Approved">Approved Only</option>
                        <option value="Pending">Pending Only</option>
                        <option value="Rejected">Rejected Only</option>
                    </select>
                </div>
                <div class="search-input-box">
                    <span class="search-icon">🔍</span>
                    <input type="text" id="public-search-query" placeholder="Try 'Zoning', '2024-001', or 'Hon. Tabanda'..." onkeyup="if(event.key === 'Enter') trackOrdinance()">
                </div>
                <div class="button-group">
                    <button class="btn-track" onclick="trackOrdinance()">Search</button>
                    <button class="btn-clear" onclick="clearTrackSearch()">Clear</button>
                </div>
            </div>
        </div>

        <div id="ordinance-result-container"></div>
    </div>
</main>

    <!-- Modal: Administrative Login -->
    <dialog id="modal-login" class="login-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="document.getElementById('modal-login').close()">&times;</button>
            <div class="modal-header">
                <h2>Administrative Access</h2>
                <p>Authorized Personnel Only</p>
            </div>
            
            <form id="login-form" method="POST">
                <div class="input-box">
                    <label for="passkey">System Passkey</label>
                    <input type="password" name="passkey" id="passkey" placeholder="••••••••" required>
                </div>
                <div id="error-msg"></div>
                <button type="submit" class="btn-submit-login">Enter Dashboard</button>
            </form>

            <div class="forgot-link">
                <a href="#" onclick="forgotPassword()">Request Passkey Recovery</a>
            </div>
        </div>
    </dialog>

    <!-- Modal: Password Recovery -->
    <dialog id="modal-forgot" class="recovery-modal">
        <div class="modal-content">
            <button class="close-modal" onclick="closeForgotModal()">&times;</button>
            <h2>Identity Verification</h2>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:20px;">Provide your Employee ID Number to verify your identity.</p>
            
            <div class="input-box">
                <label>Employee ID</label>
                <input type="text" id="verify-id" placeholder="Ex: 2024-001" required>
            </div>
            
            <div id="result-display"></div>
            
            <div class="modal-actions">
                <button type="button" class="btn-cancel" onclick="closeForgotModal()">Cancel</button>
                <button type="button" class="btn-save" onclick="verifyAndReveal()">Verify</button>
            </div>
        </div>
    </dialog>

    <script src="scripts/main.js"></script>
</body>
</html>