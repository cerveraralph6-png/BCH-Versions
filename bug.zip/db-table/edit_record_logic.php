<?php
session_start();
include '../db.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['record_id'];
    
    // Fields matching your database columns
    $fields = [
        'Date_Received', 'Time_Received', 'Ref_No', 'Type', 'Proponent', 
        'Subject', 'Subject_Description', 'Subject_Notation', 'Committee_Referred', 
        'Indorsement1', 'Date_Indorsed1', 'Com_Rep_Nr', 'Com_Rep', 
        'Com_Rep_Date_Received', 'Item_Nr', 'Agenda_Date', 'Action_Taken', 
        'Indorsement2', 'Indorsement2_Date', 'Remarks', 'Folder'
    ];

    $updates = [];
    $params = [];
    $types = "";

    foreach($fields as $f) {
        $val = isset($_POST[$f]) ? trim($_POST[$f]) : "";

        // CRUCIAL: DATABASE HISTORY TRACKING LOGIC
// Find the Action History logic in edit_record_logic.php and update it to this:
// Find the Action History logic in edit_record_logic.php and update it:
if ($f === 'Action_Taken' && !empty($_POST['new_history_entry'])) {
    $currentDate = date('M d, Y | h:i A');
    
    // Save in a clean format: [Date | Time] Content
    $newEntry = "[" . $currentDate . "] " . trim($_POST['new_history_entry']);
    
    if (!empty($val) && $val !== "-none-") {
        // Prepend with a newline
        $val = $newEntry . "\n" . $val;
    } else {
        $val = $newEntry;
    }
}

        $updates[] = "$f = ?";
        $params[] = $val;
        $types .= "s";
    }

    $sql = "UPDATE city_records SET " . implode(', ', $updates) . " WHERE id = ?";
    $params[] = $id;
    $types .= "i";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        // Update the Sync Table so public index.php and other staff see it
        $conn->query("UPDATE system_sync SET last_update = CURRENT_TIMESTAMP WHERE module_name = 'records'");
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }
}

?>