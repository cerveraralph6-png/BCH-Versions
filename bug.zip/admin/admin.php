<?php 
include_once '../auth_check.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="../Imag3s/baguio-logo-gov.webp" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>BCH | Admin Dashboard</title>
    <link rel="stylesheet" href="../CSS/admin.css">
</head>
<body class="dashboard-bg">
    
<!-- For subfolder pages (table.php, events.php, etc.) -->
<div id="page-loader">
    <div class="loader-wrapper">
        <img src="../Imag3s/baguio-logo-gov.webp" alt="BCH" class="loader-logo">
        <div class="loader-circle"></div>
    </div>
</div>
    <nav class="glass-nav">
        <div class="nav-left">
            <img src="../Imag3s/baguio-logo-gov.png" alt="logo" class="nav-logo">
            <div class="nav-titles">
                <h1>Sangguniang Panlungsod</h1>
                <span>City Council (Baguio City)</span>
            </div>
        </div>
        <div class="nav-actions">
            <button class="btn-icon" title="Notifications">🔔</button>
            <button class="btn-nav logout" id="logout">Logout</button>
        </div>
    </nav>

    <main class="fade-in">
        <section class="welcome-section">
            <div class="greetings">
                <h1>Welcome back, <span class="admin-name">Admin!</span></h1>
                <p>System Overview & Control Panel</p>
            </div>
            <div class="date-display">
                <span id="current-date"><?php echo date('F d, Y'); ?></span>
            </div>
        </section>

        <h2 class="section-label">Management Tools</h2>
        
        <div class="card-grid">
            <a href="../tools/events.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/events.webp" alt="events">
                    </div>
                    <div class="tool-info">
                        <h3>Events</h3>
                        <p>Seminars & Trainings</p>
                    </div>
                </div>
            </a>

            <a href="../db-table/table.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/database.webp" alt="database">
                    </div>
                    <div class="tool-info">
                        <h3>Registry</h3>
                        <p>Central Database</p>
                    </div>
                </div>
            </a>

            <a href="../tools/files.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/Files.webp" alt="files">
                    </div>
                    <div class="tool-info">
                        <h3>Cloud Files</h3>
                        <p>Storage & Transfer</p>
                    </div>
                </div>
            </a>

            <a href="../tools/manage-accounts.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/accounts.webp" alt="accounts">
                    </div>
                    <div class="tool-info">
                        <h3>Accounts</h3>
                        <p>User Management</p>
                    </div>
                </div>
            </a>
            
            <a href="../admin/security_logs.php" class="card-link">
                <div class="tool-card">
                    <div class="icon-wrapper">
                        <img src="../Imag3s/security.webp" alt="security">
                    </div>
                    <div class="tool-info">
                        <h3>Security</h3>
                        <p>Login & IP Logs</p>
                    </div>
                </div>
            </a>
        </div>
    </main>

    <script src="../scripts/main.js"></script>
</body>
</html>